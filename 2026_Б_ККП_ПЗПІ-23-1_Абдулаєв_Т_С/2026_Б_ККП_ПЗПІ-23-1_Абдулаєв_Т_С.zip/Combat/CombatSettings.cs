using System;
using UnityEngine;

namespace CombatGrid
{
    [CreateAssetMenu(fileName = "CombatSettings", menuName = "CombatGrid/Combat Settings")]
    public class CombatSettings : ScriptableObject
    {
        [Header("Cover Evasion Bonuses")]
        [Tooltip("Extra evasion granted to the defender when they have Half Cover " +
                 "against the attacker's direction.")]
        [Range(0f, 1f)] public float HalfCoverEvasionBonus = 0.20f;

        [Tooltip("Extra evasion granted to the defender when they have Full Cover " +
                 "against the attacker's direction.")]
        [Range(0f, 1f)] public float FullCoverEvasionBonus = 0.40f;

        [Header("Hit Chance Clamping")]
        [Tooltip("Minimum guaranteed hit chance regardless of evasion / cover (e.g. 0.05 = 5%).")]
        [Range(0f, 1f)] public float MinHitChance = 0.05f;

        [Tooltip("Maximum hit chance cap even if attacker stats are extremely high.")]
        [Range(0f, 1f)] public float MaxHitChance = 0.95f;

        [Header("Action Costs")]
        [Tooltip("Action points consumed per basic attack.")]
        [Min(1)] public int AttackActionCost = 1;
    }
}