using UnityEngine;
using TMPro;

namespace CombatGrid
{
    [RequireComponent(typeof(CanvasGroup))]
    public class DamagePopup : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private TextMeshProUGUI _textMesh;
        [SerializeField] private GlitchTextEffect _glitchEffect;

        [Header("Movement Options")]
        [SerializeField] private Vector2 _baseDirection = new Vector2(0f, 1f);
        [SerializeField] private float _directionRandomness = 25f;
        [SerializeField] private float _moveSpeed = 4f;
        [SerializeField] private float _drag = 3f;

        [Header("Scale Options (The 'Pop')")]
        [SerializeField] private float _startScale = 0.55f;
        [SerializeField] private float _peakScale = 1.35f;
        [SerializeField] private float _settleScale = 0.85f;
        [SerializeField] private float _endScale = 0.40f;
        [SerializeField] private float _timeToPeak = 0.08f;
        [SerializeField] private float _timeToSettle = 0.25f;

        [Header("Lifespan, Glitch, & Fading")]
        [SerializeField] private float _lifetime = 1.4f;
        [SerializeField] private float _fadeDuration = 0.35f;
        [SerializeField] private float _glitchSustainDuration = 0.45f;

        private CanvasGroup _canvasGroup;
        private Vector3 _worldPosition;
        private Vector3 _velocity;
        private Camera _cam;
        private Camera _uiCam;
        private RectTransform _canvasRect;

        private float _elapsed;
        private Vector3 _baseScale;

        private void Awake()
        {
            _canvasGroup = GetComponent<CanvasGroup>();
            if (_glitchEffect == null) _glitchEffect = GetComponentInChildren<GlitchTextEffect>();
        }

        public void Setup(string text, Color color, Vector3 startWorldPos, Camera cam, Canvas parentCanvas, float scaleMultiplier = 1f, Vector2? customDirection = null)
        {
            _textMesh.text = text;
            _textMesh.color = color;

            _worldPosition = startWorldPos;
            _cam = cam;
            _canvasRect = parentCanvas.GetComponent<RectTransform>();
            _uiCam = parentCanvas.renderMode != RenderMode.ScreenSpaceOverlay ? parentCanvas.worldCamera : null;

            _elapsed = 0f;
            _baseScale = Vector3.one * scaleMultiplier;

            if (_glitchEffect != null)
            {
                _glitchEffect.SetThemeColor(color);
                _glitchEffect.Initialize(startVisible: true);
                _glitchEffect.UpdateValue(text, immediate: true);
            }

            Vector2 dirToUse = customDirection ?? _baseDirection;
            float randomAngle = Random.Range(-_directionRandomness, _directionRandomness);
            Quaternion rotation = Quaternion.Euler(0, 0, randomAngle);
            Vector2 screenDir = rotation * dirToUse.normalized;

            Vector3 worldDir = (_cam.transform.right * screenDir.x) + (_cam.transform.up * screenDir.y);
            _velocity = worldDir.normalized * _moveSpeed;
        }

        public bool Tick(float deltaTime)
        {
            _elapsed += deltaTime;
            if (_elapsed >= _lifetime) return false;

            float timeRemaining = _lifetime - _elapsed;

            _worldPosition += _velocity * deltaTime;
            _velocity = Vector3.Lerp(_velocity, Vector3.zero, deltaTime * _drag);

            Vector3 screenPos = _cam.WorldToScreenPoint(_worldPosition);
            if (screenPos.z > 0 && RectTransformUtility.ScreenPointToLocalPointInRectangle(_canvasRect, screenPos, _uiCam, out Vector2 localPos))
            {
                ((RectTransform)transform).anchoredPosition = localPos;
            }

            float currentScale = _settleScale;
            if (_elapsed < _timeToPeak)
            {
                currentScale = Mathf.Lerp(_startScale, _peakScale, Mathf.Sin((_elapsed / _timeToPeak) * Mathf.PI * 0.5f));
            }
            else if (_elapsed < _timeToPeak + _timeToSettle)
            {
                float t = (_elapsed - _timeToPeak) / _timeToSettle;
                currentScale = Mathf.Lerp(_peakScale, _settleScale, t * t * (3f - 2f * t));
            }
            else if (timeRemaining <= _fadeDuration)
            {
                float t = 1f - (timeRemaining / _fadeDuration);
                currentScale = Mathf.Lerp(_settleScale, _endScale, t * t * (3f - 2f * t));
            }

            transform.localScale = _baseScale * currentScale;

            if (_glitchEffect != null && _elapsed <= _glitchSustainDuration)
            {
                _glitchEffect.TriggerDamage(Mathf.Lerp(1.0f, 0f, _elapsed / _glitchSustainDuration));
            }

            float alpha = timeRemaining <= _fadeDuration ? timeRemaining / _fadeDuration : 1f;
            _canvasGroup.alpha = alpha;
            if (_glitchEffect != null) _glitchEffect.SetEffectAlpha(alpha);

            return true;
        }
    }
}