using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace CombatGrid
{
    [CreateAssetMenu(fileName = "TurnSettings", menuName = "CombatGrid/Turn Settings")]
    public class TurnSettings : ScriptableObject
    {
        [Header("Phase Order")]
        [Tooltip("The order in which teams take their phase each round. " +
                 "Add, remove, or reorder entries freely. " +
                 "Teams with no living units are skipped automatically.")]
        public List<UnitTeam> TeamOrder = new()
        {
            UnitTeam.Player,
            UnitTeam.Enemy,
            UnitTeam.Neutral
        };

        [Header("Timing")]
        [Tooltip("Seconds to wait before the very first round begins (gives scene time to settle).")]
        [Min(0f)] public float CombatStartDelay = 0.5f;

        [Tooltip("Seconds to pause between one team's phase ending and the next beginning. " +
                 "Useful for UI transitions.")]
        [Min(0f)] public float PhaseTransitionDelay = 0.25f;

        [Header("Round Behaviour")]
        [Tooltip("If true, reaction points are replenished at the START of each round " +
                 "for ALL units (not just the active team). " +
                 "If false, they are replenished individually when a team's phase begins.")]
        public bool RefreshReactionPointsEachRound = true;

        [Tooltip("If true, the combat loop runs indefinitely until StopCombat() is called. " +
                 "If false, the loop stops after all teams pass a round with no living units on " +
                 "one side (use OnCombatEnded to handle the result in your own logic).")]
        public bool AutoCheckVictory = true;

        [Header("Auto-End Phase")]
        [Tooltip("Teams listed here will have their phase ended automatically as soon as every " +
                 "unit has exhausted their MP and AP - no manual EndPhase() call needed. " +
                 "Leave Player out of this list so the player always presses End Turn themselves. " +
                 "Add Enemy and Neutral here for AI teams that don't have a full AI controller yet.")]
        public List<UnitTeam> AutoEndWhenExhausted = new()
        {
            UnitTeam.Enemy,
            UnitTeam.Neutral
        };
        public bool IsValidTeam(UnitTeam team) => TeamOrder.Contains(team);
    }
}