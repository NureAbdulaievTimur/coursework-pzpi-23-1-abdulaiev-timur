using System;
using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    public class GridCell
    {
        public GridCoord Coord { get; }
        public Vector3 WorldPos { get; }
        public bool IsWalkable { get; private set; } = true;

        private int _obstructionCount;
        public bool IsObstructed => _obstructionCount > 0;

        public void AddObstruction()
        {
            _obstructionCount++;
            OnCellStateChanged?.Invoke(this);
        }

        public void RemoveObstruction()
        {
            _obstructionCount = Mathf.Max(0, _obstructionCount - 1);
            OnCellStateChanged?.Invoke(this);
        }

        public bool IsBlocking => !IsWalkable || IsObstructed;
        public bool IsAvailable => IsWalkable && !IsObstructed && !IsOccupied;

        public Unit Occupant { get; private set; }
        public bool IsOccupied => Occupant != null;

        private readonly Dictionary<GridCoord, CoverType> _coverSlots = new();
        public IReadOnlyDictionary<GridCoord, CoverType> CoverSlots => _coverSlots;

        public bool HasAnyCover => _coverSlots.Count > 0;

        public void AddCoverSlot(GridCoord dirToObstacle, CoverType type)
        {
            if (_coverSlots.TryGetValue(dirToObstacle, out var existing))
            {
                if (type > existing) _coverSlots[dirToObstacle] = type;
            }
            else _coverSlots[dirToObstacle] = type;

            OnCellStateChanged?.Invoke(this);
        }

        public void RemoveCoverSlot(GridCoord dirToObstacle)
        {
            if (_coverSlots.Remove(dirToObstacle))
                OnCellStateChanged?.Invoke(this);
        }

        public CoverType GetCoverAgainst(GridCoord dirToAttacker)
        {
            GridCoord norm = new(
                dirToAttacker.X == 0 ? 0 : (dirToAttacker.X > 0 ? 1 : -1),
                dirToAttacker.Z == 0 ? 0 : (dirToAttacker.Z > 0 ? 1 : -1));
            return _coverSlots.TryGetValue(norm, out var t) ? t : CoverType.None;
        }

        public float MoveCostModifier { get; set; } = 1f;

        public bool IsHighlightedAsReachable { get; set; }
        public bool IsHighlightedAsPath { get; set; }
        public bool IsSelected { get; set; }

        public event Action<GridCell> OnCellStateChanged;

        public GridCell(GridCoord coord, Vector3 worldPos)
        {
            Coord = coord;
            WorldPos = worldPos;
        }

        public void SetOccupant(Unit unit)
        {
            Occupant = unit;
            OnCellStateChanged?.Invoke(this);
        }

        public void ClearOccupant()
        {
            Occupant = null;
            OnCellStateChanged?.Invoke(this);
        }

        public void SetWalkable(bool walkable)
        {
            IsWalkable = walkable;
            OnCellStateChanged?.Invoke(this);
        }

        public void ClearHighlights()
        {
            IsHighlightedAsReachable = false;
            IsHighlightedAsPath = false;
            IsSelected = false;
            OnCellStateChanged?.Invoke(this);
        }

        public override string ToString()
            => $"Cell{Coord} [Walk={IsWalkable} Obstr={IsObstructed} Occ={IsOccupied}]";
    }

    public enum CoverType { None, Half, Full }
}