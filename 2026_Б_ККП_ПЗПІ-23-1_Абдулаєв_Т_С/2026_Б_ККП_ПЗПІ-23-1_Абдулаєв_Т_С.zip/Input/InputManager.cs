using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class InputManager : MonoBehaviour
{
    private static InputManager instance;

    private InputActions inputActions;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }

        inputActions = new InputActions();
    }

    public event Action<Vector2> onMove;
    public event Action onSprintPerformed;
    public event Action onFirePerformed;
    public event Action onRunToggled;
    public event Action onAimPerformed;
    public event Action onAimCanceled;
    public event Action onReloadPerformed;
    public event Action onEquipGunPerformed;
    public event Action onKickPerformed;
    public event Action onCrouchPerformed;
    public event Action onGrabPerformed;
    public event Action<float> onScrollPerformed;

    private void OnEnable()
    {
        inputActions.Enable();
        inputActions.Player.Move.performed += ctx => onMove?.Invoke(ctx.ReadValue<Vector2>());
        inputActions.Player.Move.canceled += ctx => onMove?.Invoke(Vector2.zero);
        inputActions.Player.Sprint.performed += ctx => onSprintPerformed?.Invoke();
        inputActions.Player.Fire.performed += ctx => onFirePerformed?.Invoke();
        inputActions.Player.Run.performed += ctx => onRunToggled?.Invoke();
        inputActions.Player.Aim.performed += ctx => onAimPerformed?.Invoke();
        inputActions.Player.Aim.canceled += ctx => onAimCanceled?.Invoke();
        inputActions.Player.Reload.performed += ctx => onReloadPerformed?.Invoke();
        inputActions.Player.EquipGun.performed += ctx => onEquipGunPerformed?.Invoke();
        inputActions.Player.Kick.performed += ctx => onKickPerformed?.Invoke();
        inputActions.Player.Crouch.performed += ctx => onCrouchPerformed?.Invoke();
        inputActions.Player.Scroll.performed += ctx => onScrollPerformed?.Invoke(ctx.ReadValue<float>());
    }

    private void OnDisable()
    {
        inputActions.Disable();
        inputActions.Player.Move.performed -= ctx => onMove?.Invoke(ctx.ReadValue<Vector2>());
        inputActions.Player.Move.canceled -= ctx => onMove?.Invoke(Vector2.zero);
        inputActions.Player.Sprint.performed -= ctx => onSprintPerformed?.Invoke();
        inputActions.Player.Fire.performed -= ctx => onFirePerformed?.Invoke();
        inputActions.Player.Run.performed -= ctx => onRunToggled?.Invoke();
        inputActions.Player.Aim.performed -= ctx => onAimPerformed?.Invoke();
        inputActions.Player.Aim.canceled -= ctx => onAimCanceled?.Invoke();
        inputActions.Player.Reload.performed -= ctx => onReloadPerformed?.Invoke();
        inputActions.Player.EquipGun.performed -= ctx => onEquipGunPerformed?.Invoke();
        inputActions.Player.Kick.performed -= ctx => onKickPerformed?.Invoke();
        inputActions.Player.Crouch.performed -= ctx => onCrouchPerformed?.Invoke();
        inputActions.Player.Scroll.performed -= ctx => onScrollPerformed?.Invoke(ctx.ReadValue<float>());
    }


    public Vector2 GetPlayerMovement()
    {
        return inputActions.Player.Move.ReadValue<Vector2>();
    }

    public Vector2 GetMouseDelta()
    {
        return inputActions.Player.Look.ReadValue<Vector2>();
    }

    public bool PlayerSprinted()
    {
        return inputActions.Player.Sprint.triggered;
    }

    public bool PlayerInteracted()
    {
        return inputActions.Player.Interact.triggered;
    }

    public bool PlayerFired()
    {
        return inputActions.Player.Fire.triggered;
    }

    public bool PlayerSwitchedToRunning()
    {
        return inputActions.Player.Run.triggered;
    }

    public bool PlayerToggledEquip()
    {
        return inputActions.Player.EquipGun.triggered;
    }

    public static InputManager GetInstance()
    {
        return instance;
    }

}
