using System.Collections;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class SceneTransitionManager : MonoBehaviour
{
    public static SceneTransitionManager Instance;

    [Header("Transition Settings")]
    public float transitionDuration = 0.8f;
    public AnimationCurve transitionCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

    public enum SlideDirection { RightToLeft, LeftToRight, TopToBottom, BottomToTop }
    public SlideDirection slideDirection = SlideDirection.RightToLeft;

    [Header("UI References")]
    public RectTransform transitionPanel;

    private bool isTransitioning = false;
    private Canvas parentCanvas;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
            parentCanvas = transitionPanel.GetComponentInParent<Canvas>();
        }
        else
        {
            Destroy(gameObject);
        }
    }

    private void Start()
    {
        MovePanel(1f);
    }

    private void Update()
    {
        if (isTransitioning) return;

        if (Input.GetKeyDown(KeyCode.Escape))
        {
            QuitGameWithTransition();
        }

        if (Input.GetKeyDown(KeyCode.R))
        {
            RestartCurrentScene();
        }
    }

    public void RestartCurrentScene()
    {
        if (!isTransitioning)
        {
            string currentSceneName = SceneManager.GetActiveScene().name;

            if (currentSceneName == "MainMenu") return; 

            StartCoroutine(TransitionCoroutine(currentSceneName));
        }
    }

    public void LoadScene(string sceneName)
    {
        if (!isTransitioning)
        {
            StartCoroutine(TransitionCoroutine(sceneName));
        }
    }

    public void QuitGameWithTransition()
    {
        if (!isTransitioning)
        {
            StartCoroutine(QuitCoroutine());
        }
    }

    private IEnumerator TransitionCoroutine(string sceneName)
    {
        isTransitioning = true;

        float elapsed = 0f;
        while (elapsed < transitionDuration)
        {
            elapsed += Time.deltaTime;
            float t = transitionCurve.Evaluate(elapsed / transitionDuration);
            MovePanel(1f - t);
            yield return null;
        }
        MovePanel(0f);

        AsyncOperation asyncLoad = SceneManager.LoadSceneAsync(sceneName);
        while (!asyncLoad.isDone)
        {
            yield return null;
        }

        elapsed = 0f;
        while (elapsed < transitionDuration)
        {
            elapsed += Time.deltaTime;
            float t = transitionCurve.Evaluate(elapsed / transitionDuration);
            MovePanel(-t);
            yield return null;
        }
        MovePanel(-1f);

        isTransitioning = false;
    }

    private IEnumerator QuitCoroutine()
    {
        isTransitioning = true;

        float elapsed = 0f;
        while (elapsed < transitionDuration)
        {
            elapsed += Time.deltaTime;
            float t = transitionCurve.Evaluate(elapsed / transitionDuration);
            MovePanel(1f - t);
            yield return null;
        }

        Debug.Log("Game Quitting!");
        Application.Quit();
    }

    private void MovePanel(float offsetMultiplier)
    {
        float width = parentCanvas.GetComponent<RectTransform>().rect.width;
        float height = parentCanvas.GetComponent<RectTransform>().rect.height;

        switch (slideDirection)
        {
            case SlideDirection.RightToLeft:
                transitionPanel.anchoredPosition = new Vector2(width * offsetMultiplier, 0);
                break;
            case SlideDirection.LeftToRight:
                transitionPanel.anchoredPosition = new Vector2(-width * offsetMultiplier, 0);
                break;
            case SlideDirection.TopToBottom:
                transitionPanel.anchoredPosition = new Vector2(0, height * offsetMultiplier);
                break;
            case SlideDirection.BottomToTop:
                transitionPanel.anchoredPosition = new Vector2(0, -height * offsetMultiplier);
                break;
        }
    }
}