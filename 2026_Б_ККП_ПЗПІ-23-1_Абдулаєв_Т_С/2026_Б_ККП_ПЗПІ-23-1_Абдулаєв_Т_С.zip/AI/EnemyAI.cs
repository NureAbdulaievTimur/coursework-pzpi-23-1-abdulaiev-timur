using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    public class EnemyAI : MonoBehaviour
    {
        [Header("Team")]
        [Tooltip("This controller manages the phase for this team.")]
        [SerializeField] private UnitTeam _controlledTeam = UnitTeam.Enemy;
        public UnitTeam ControlledTeam => _controlledTeam;

        [Header("Fallback Behavior")]
        [Tooltip("Profile used for units that have no AIBehaviorProfile assigned.")]
        [SerializeField] private AIBehaviorProfile _fallbackProfile;
        public AIBehaviorProfile FallbackProfile
        {
            get => _fallbackProfile;
            set { _fallbackProfile = value; _fallbackProfile?.ResetOverrides(); }
        }

        [Header("Debug")]
        [SerializeField] private bool _verboseLog = false;
        [SerializeField, Min(1)] private int _logTopN = 3;

        public delegate List<AbilityAction> AbilityProvider(Unit actor, AIWeights weights);
        private readonly List<AbilityProvider> _abilityProviders = new();

        public void RegisterAbilityProvider(AbilityProvider provider)
        {
            if (provider != null && !_abilityProviders.Contains(provider))
                _abilityProviders.Add(provider);
        }

        public void UnregisterAbilityProvider(AbilityProvider provider)
            => _abilityProviders.Remove(provider);

        public event Action<Unit, int> OnUnitTurnStarted;
        public event Action<Unit, int> OnUnitTurnEnded;
        public event Action<CombatAction, Unit> OnActionExecuted;

        private Coroutine _aiCoroutine;
        private Coroutine _activeExecuteCoroutine;
        public bool IsThinking { get; private set; }

        private void Start()
        {
            if (TurnManager.Instance != null)
                TurnManager.Instance.OnPhaseStarted += OnPhaseStarted;
            else
                Debug.LogWarning($"[EnemyAI ({_controlledTeam})] No TurnManager found.", this);

            _fallbackProfile?.ResetOverrides();
        }

        private void OnDestroy()
        {
            if (TurnManager.Instance != null)
                TurnManager.Instance.OnPhaseStarted -= OnPhaseStarted;
        }

        private void OnDisable()
        {
            if (IsThinking && TurnManager.Instance != null)
            {
                TurnManager.Instance.RemovePhaseHold();
                IsThinking = false;
            }
        }

        private void OnPhaseStarted(UnitTeam team, int round)
        {
            if (team != _controlledTeam) return;

            if (IsThinking && TurnManager.Instance != null)
            {
                TurnManager.Instance.RemovePhaseHold();
                IsThinking = false;
            }

            if (_activeExecuteCoroutine != null)
            {
                StopCoroutine(_activeExecuteCoroutine);
                _activeExecuteCoroutine = null;
            }
            if (_aiCoroutine != null) StopCoroutine(_aiCoroutine);
            _aiCoroutine = StartCoroutine(RunPhase(round));
        }

        private IEnumerator RunPhase(int round)
        {
            IsThinking = true;

            if (TurnManager.Instance != null)
                TurnManager.Instance.AddPhaseHold();

            var units = new List<Unit>(TurnManager.Instance.GetUnits(_controlledTeam));

            if (_verboseLog)
                Debug.Log($"[EnemyAI ({_controlledTeam})] Round {round}: {units.Count} unit(s).");

            foreach (var unit in units)
            {
                if (!unit.IsAlive) continue;

                OnUnitTurnStarted?.Invoke(unit, round);
                yield return StartCoroutine(RunUnitTurn(unit, round));
                OnUnitTurnEnded?.Invoke(unit, round);

                yield return new WaitUntil(() => !unit.Movement.IsMoving);

                float gap = GetProfile(unit)?.DelayBetweenUnitActions ?? 0f;
                if (gap > 0f) yield return new WaitForSeconds(gap);
            }

            IsThinking = false;

            if (TurnManager.Instance != null &&
                TurnManager.Instance.IsCombatActive &&
                TurnManager.Instance.ActiveTeam == _controlledTeam)
            {
                if (_verboseLog)
                    Debug.Log($"[EnemyAI ({_controlledTeam})] Round {round}: EndPhase.");
                TurnManager.Instance.EndPhase();
            }

            if (TurnManager.Instance != null)
                TurnManager.Instance.RemovePhaseHold();
        }

        private IEnumerator RunUnitTurn(Unit unit, int round)
        {
            const int SafetyLimit = 30;
            int iterations = 0;

            AIBehaviorProfile profile = GetProfile(unit);
            profile?.ResetOverrides();

            while (unit.IsAlive && (unit.CanMove || unit.CanAct) && iterations < SafetyLimit)
            {
                iterations++;

                yield return new WaitUntil(() => !unit.Movement.IsMoving);

                if (!unit.IsAlive || (!unit.CanMove && !unit.CanAct)) break;

                AIWeights weights = profile != null
                    ? profile.EvaluateOverrides(unit, _controlledTeam)
                    : (_fallbackProfile != null
                        ? _fallbackProfile.EvaluateOverrides(unit, _controlledTeam)
                        : new AIWeights());

                var abilities = GatherAbilities(unit, weights);

                List<CombatAction> scored = AIActionScorer.GenerateScoredActions(
                    unit, weights, abilities);

                if (_verboseLog) LogTopActions(unit, scored);

                CombatAction best = scored.Count > 0 ? scored[0] : null;
                if (best == null || best is WaitAction) break;

                bool done = false;
                _activeExecuteCoroutine = StartCoroutine(best.Execute(unit, () => done = true));
                yield return _activeExecuteCoroutine;
                _activeExecuteCoroutine = null;
                yield return new WaitUntil(() => done);

                OnActionExecuted?.Invoke(best, unit);

                if (best is MoveAction && unit.RemainingMovePoints > 0)
                    unit.TrySpendMovePoints(unit.RemainingMovePoints);

                if (_verboseLog)
                    Debug.Log($"[EnemyAI]   {unit.Stats?.UnitName} -> {best.Description} (score {best.Score:F1})");

                float stepDelay = profile?.DelayBetweenSteps ?? 0f;
                if (stepDelay > 0f)
                    yield return new WaitForSeconds(stepDelay);
            }

            if (iterations >= SafetyLimit)
                Debug.LogWarning($"[EnemyAI] Safety limit hit for {unit.Stats?.UnitName}.");
        }

        private AIBehaviorProfile GetProfile(Unit unit)
            => unit.AIProfile != null ? unit.AIProfile : _fallbackProfile;

        private List<AbilityAction> GatherAbilities(Unit unit, AIWeights weights)
        {
            var result = new List<AbilityAction>();
            foreach (var provider in _abilityProviders)
            {
                try
                {
                    var list = provider(unit, weights);
                    if (list != null) result.AddRange(list);
                }
                catch (Exception ex)
                {
                    Debug.LogError($"[EnemyAI] AbilityProvider threw: {ex}");
                }
            }
            return result;
        }

        private void LogTopActions(Unit unit, List<CombatAction> sorted)
        {
            int n = Mathf.Min(_logTopN, sorted.Count);
            var sb = new System.Text.StringBuilder();
            sb.Append($"[EnemyAI] {unit.Stats?.UnitName} -- top {n} candidates:\n");
            for (int i = 0; i < n; i++)
                sb.Append($"    #{i + 1}  {sorted[i].Description,-40}  score {sorted[i].Score:F2}\n");
            Debug.Log(sb.ToString());
        }

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (!IsThinking || TurnManager.Instance == null) return;
            Gizmos.color = new Color(1f, 0.3f, 0.3f, 0.5f);
            foreach (var unit in TurnManager.Instance.GetUnits(_controlledTeam))
            {
                if (!unit.IsAlive) continue;
                Unit nearest = null;
                int minDist = int.MaxValue;
                foreach (var e in AIActionScorer.GetEnemiesOf(unit))
                {
                    int d = GridCoord.ChebyshevDistance(unit.CurrentCoord, e.CurrentCoord);
                    if (d < minDist) { minDist = d; nearest = e; }
                }
                if (nearest != null)
                    Gizmos.DrawLine(unit.transform.position + Vector3.up * 0.5f,
                                    nearest.transform.position + Vector3.up * 0.5f);
            }
        }
#endif
    }
}