using System;
using UnityEngine;

namespace CombatGrid
{
    public readonly struct AttackResult
    {
        public readonly bool WasValid;
        public readonly bool DidHit;
        public readonly float FinalHitChance;
        public readonly float Roll;
        public readonly int ShieldDamageDealt;
        public readonly int HPDamageDealt;
        public readonly CoverType DefenderCoverType;
        public readonly string InvalidReason;

        public readonly bool WasAttackerPerfect;
        public readonly bool WasDefenderPerfect;

        public bool Evaded => WasValid && !DidHit;

        public static AttackResult Invalid(string reason) =>
            new(false, false, 0, 0, 0, 0, CoverType.None, reason, false, false);

        public AttackResult(bool wasValid, bool didHit, float finalHitChance,
                            float roll, int shieldDmg, int hpDmg,
                            CoverType coverType, string invalidReason = "",
                            bool attackerPerfect = false, bool defenderPerfect = false)
        {
            WasValid = wasValid;
            DidHit = didHit;
            FinalHitChance = finalHitChance;
            Roll = roll;
            ShieldDamageDealt = shieldDmg;
            HPDamageDealt = hpDmg;
            DefenderCoverType = coverType;
            InvalidReason = invalidReason;
            WasAttackerPerfect = attackerPerfect;
            WasDefenderPerfect = defenderPerfect;
        }

        public override string ToString()
        {
            if (!WasValid) return $"[INVALID] {InvalidReason}";
            if (WasDefenderPerfect) return $"[PERFECT DODGE] (Cover:{DefenderCoverType})";
            if (WasAttackerPerfect) return $"[PERFECT HIT] Shield:{ShieldDamageDealt} HP:{HPDamageDealt} (Cover:{DefenderCoverType})";

            if (!DidHit) return $"[MISS] Roll:{Roll:P0} vs {FinalHitChance:P0} (Cover:{DefenderCoverType})";
            return $"[HIT] Shield:{ShieldDamageDealt} HP:{HPDamageDealt} " +
                   $"Roll:{Roll:P2} vs {FinalHitChance:P0} (Cover:{DefenderCoverType})";
        }
    }

    public class CombatManager : MonoBehaviour
    {
        public static CombatManager Instance { get; private set; }

        [Header("Settings")]
        [SerializeField] private CombatSettings _settings;
        public CombatSettings Settings => _settings;

        [Header("Line of Sight")]
        [Tooltip("Layers that block Line of Sight (e.g., Environment, Walls). Do NOT include the Units layer!")]
        [SerializeField] private LayerMask _losObstacleMask;
        [Tooltip("Height offset from the unit's base to check LoS from (simulates standing chest/head height).")]
        [SerializeField] private float _losHeightOffset = 1.4f;

        public event Action<AttackResult, Unit, Unit> OnAttackResolved;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Destroy(gameObject);
                return;
            }
            Instance = this;

            if (_settings == null)
                Debug.LogWarning("[CombatManager] No CombatSettings assigned - using defaults.", this);
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public bool HasLineOfSight(Vector3 fromWorldPos, Vector3 toWorldPos)
        {
            Vector3 start = fromWorldPos + Vector3.up * _losHeightOffset;
            Vector3 end = toWorldPos + Vector3.up * _losHeightOffset;
            Vector3 dir = end - start;
            return !Physics.Raycast(start, dir.normalized, dir.magnitude, _losObstacleMask);
        }

        public bool HasLineOfSight(Unit attacker, Unit defender)
        {
            if (attacker == null || defender == null) return false;

            return HasLineOfSight(attacker.transform.position, defender.transform.position);
        }

        public AttackResult TryAttack(Unit attacker, Unit defender, float bonusHitChance = 0f, float bonusEvasion = 0f, bool attackerPerfect = false, bool defenderPerfect = false)
        {
            if (attacker == null || !attacker.IsAlive) return Fail("Attacker is null or dead.");
            if (defender == null || !defender.IsAlive) return Fail("Defender is null or dead.");
            if (attacker == defender) return Fail("Unit cannot attack itself.");
            if (!attacker.CanAct) return Fail($"{attacker.Stats?.UnitName} has no action points remaining.");
            if (attacker.Movement.IsMoving) return Fail($"{attacker.Stats?.UnitName} cannot attack while moving.");

            float range = GetCircularDistance(attacker.CurrentCoord, defender.CurrentCoord);

            if (range > attacker.Stats.AttackRange + 0.5f)
                return Fail($"Target out of range (distance {range:F1}, max {attacker.Stats.AttackRange}).");

            if (!HasLineOfSight(attacker, defender))
                return Fail($"No Line of Sight between {attacker.Stats?.UnitName} and {defender.Stats?.UnitName}.");

            CoverType coverType = GridManager.Instance != null
                ? GridManager.Instance.GetCoverBetween(defender.CurrentCoord, attacker.CurrentCoord)
                : CoverType.None;

            float coverEvasion = GetCoverEvasionBonus(coverType);

            float baseHit = attacker.Stats.BaseHitChance - defender.Stats.Evasion - coverEvasion;

            float minHit = _settings != null ? _settings.MinHitChance : 0.05f;
            float maxHit = _settings != null ? _settings.MaxHitChance : 0.95f;

            float finalHitChance;
            bool didHit;
            float roll = UnityEngine.Random.value;

            if (defenderPerfect)
            {
                finalHitChance = 0f;
                didHit = false;
            }
            else if (attackerPerfect)
            {
                finalHitChance = 1f;
                didHit = true;
            }
            else
            {
                float modifiedHit = baseHit + bonusHitChance - bonusEvasion;
                finalHitChance = Mathf.Clamp(modifiedHit, minHit, maxHit);
                didHit = roll <= finalHitChance;
            }

            Debug.Log($"[CombatManager] {attacker.Stats?.UnitName} attacks {defender.Stats?.UnitName} | " +
                  $"Hit%:{finalHitChance:P0} (baseHit:{baseHit:P0} qteHitMod:{bonusHitChance:P0} qteEvMod:{bonusEvasion:P0}) " +
                  $"Roll:{roll:P2} -> {(didHit ? "HIT" : "MISS")} | PerfAtt:{attackerPerfect} PerfDef:{defenderPerfect}");

            int actionCost = _settings != null ? _settings.AttackActionCost : 1;
            attacker.TrySpendActionPoints(actionCost);

            int shieldDmg = 0;
            int hpDmg = 0;

            if (didHit)
            {
                int rawDamage = attacker.Stats.AttackDamage;
                int remaining = rawDamage;

                if (defender.CurrentEnergyShield > 0)
                {
                    shieldDmg = Mathf.Min(defender.CurrentEnergyShield, remaining);
                    remaining -= shieldDmg;
                }

                if (remaining > 0)
                {
                    int armorDR = defender.Stats?.Armor ?? 0;
                    hpDmg = Mathf.Max(0, remaining - armorDR);
                    hpDmg = Mathf.Min(hpDmg, defender.CurrentHP);
                }

                defender.TakeDamage(rawDamage);
            }
            else
            {
                defender.NotifyEvaded();
            }

            var result = new AttackResult(true, didHit, finalHitChance, roll, shieldDmg, hpDmg, coverType, "", attackerPerfect, defenderPerfect);
            OnAttackResolved?.Invoke(result, attacker, defender);
            return result;
        }

        private float GetCircularDistance(GridCoord a, GridCoord b)
        {
            float dx = a.X - b.X;
            float dy = a.Z - b.Z;

            return Mathf.Sqrt((dx * dx) + (dy * dy));
        }

        public float GetCoverEvasionBonus(CoverType cover)
        {
            return cover switch
            {
                CoverType.Half => _settings != null ? _settings.HalfCoverEvasionBonus : 0.20f,
                CoverType.Full => _settings != null ? _settings.FullCoverEvasionBonus : 0.40f,
                _ => 0f
            };
        }

        public float PreviewHitChance(Unit attacker, Unit defender)
        {
            if (attacker == null || defender == null) return 0f;

            CoverType cover = GridManager.Instance != null
                ? GridManager.Instance.GetCoverBetween(defender.CurrentCoord, attacker.CurrentCoord)
                : CoverType.None;

            float raw = attacker.Stats.BaseHitChance
                        - defender.Stats.Evasion
                        - GetCoverEvasionBonus(cover);

            float minHit = _settings != null ? _settings.MinHitChance : 0.05f;
            float maxHit = _settings != null ? _settings.MaxHitChance : 0.95f;
            return Mathf.Clamp(raw, minHit, maxHit);
        }

        public void PreviewDamage(Unit attacker, Unit defender, out int shieldDmg, out int hpDmg)
        {
            shieldDmg = 0;
            hpDmg = 0;
            if (attacker == null || defender == null) return;

            int rawDamage = attacker.Stats.AttackDamage;
            int remaining = rawDamage;

            if (defender.CurrentEnergyShield > 0)
            {
                shieldDmg = Mathf.Min(defender.CurrentEnergyShield, remaining);
                remaining -= shieldDmg;
            }

            if (remaining > 0)
            {
                int armorDR = defender.Stats?.Armor ?? 0;
                hpDmg = Mathf.Max(0, remaining - armorDR);
                hpDmg = Mathf.Min(hpDmg, defender.CurrentHP);
            }
        }

        private AttackResult Fail(string reason)
        {
            Debug.LogWarning($"[CombatManager] Invalid attack: {reason}");
            return AttackResult.Invalid(reason);
        }
    }
}