using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    [CreateAssetMenu(fileName = "CoverIconSettings", menuName = "CombatGrid/Cover Icon Settings")]
    public class CoverIconSettings : ScriptableObject
    {
        [Header("Material")]
        public Material IconMaterial;

        [Header("Size")]
        [Min(0.05f)] public float Width = 0.45f;
        [Min(0.05f)] public float Height = 0.65f;
        [Min(0f)] public float GroundOffset = 1f;
        [Min(0f)] public float ForwardBias = 0.1f;

        [Header("Shield Base Color")]
        public Color ShieldColor = new(0.15f, 0.85f, 1.0f, 1f);
        public Color GlowColor = new(0.4f, 1.0f, 1.0f, 1f);
        [Range(0, 20)] public float HDRMultiplier = 4f;

        [Header("Direct Hover State")]
        [Tooltip("Color when the mouse is exactly over the cell this shield protects.")]
        public Color HighlightColor = new(0.2f, 1.0f, 0.3f, 1f);
        [Tooltip("Scale multiplier when hovering exact cell.")]
        [Range(1f, 2f)] public float HighlightScale = 1.45f;
        [Tooltip("Distance threshold for highlighting. (Usually ~0.8)")]
        [Range(0.1f, 2f)] public float HighlightRadius = 1.6f;

        [Header("Animation")]
        [Range(0, 5)] public float PulseSpeed = 0.5f;
        [Range(0, 1)] public float PulseDepth = 0.45f;
    }
}