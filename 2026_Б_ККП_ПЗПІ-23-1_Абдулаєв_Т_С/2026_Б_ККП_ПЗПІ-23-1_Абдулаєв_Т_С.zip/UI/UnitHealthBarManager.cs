using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    public class UnitHealthBarManager : MonoBehaviour
    {
        public static UnitHealthBarManager Instance { get; private set; }

        [Header("References")]
        [SerializeField] private UnitHealthBar _barPrefab;
        [SerializeField] private Canvas _canvas;
        [SerializeField] private Camera _camera;

        [Header("Options")]
        [SerializeField] private bool _showOnlyActivePhaseBars = false;
        [SerializeField] private bool _showPlayerBars = true;
        [SerializeField] private bool _showEnemyBars = true;
        [SerializeField] private bool _showNeutralBars = false;

        [Header("Hide when at full HP")]
        [SerializeField] private bool _hideAtFullHealth = false;

        private readonly Dictionary<Unit, UnitHealthBar> _bars
            = new Dictionary<Unit, UnitHealthBar>();

        private Unit _hoveredUnit = null;

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;

            if (_camera == null) _camera = Camera.main;
        }

        private void Start()
        {
            ValidateSetup();

            if (TurnManager.Instance != null)
            {
                foreach (UnitTeam team in System.Enum.GetValues(typeof(UnitTeam)))
                    foreach (var unit in TurnManager.Instance.GetUnits(team))
                        TrySpawnBar(unit);
            }
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        private void LateUpdate()
        {
            if (_hideAtFullHealth) UpdateFullHealthVisibility();
        }

        public void NotifyHoveredUnit(Unit unit)
        {
            if (_hoveredUnit == unit) return;

            if (_hoveredUnit != null && _bars.TryGetValue(_hoveredUnit, out var old))
                old.SetHovered(false);

            _hoveredUnit = unit;

            if (_hoveredUnit != null && _bars.TryGetValue(_hoveredUnit, out var bar))
                bar.SetHovered(true);
        }

        public void RegisterUnit(Unit unit) => TrySpawnBar(unit);

        public void UnregisterUnit(Unit unit)
        {
            if (unit != null) unit.OnUnitDied -= HandleUnitDied_Manager;

            if (!_bars.TryGetValue(unit, out var bar)) return;

            if (bar != null) Destroy(bar.gameObject);

            _bars.Remove(unit);
        }

        public void ShowDamagePreview(Unit unit, int hpDamage, int shieldDamage,
                                       float hitChance = 0f,
                                       int minTotal = -1, int maxTotal = -1)
        {
            if (unit == null) return;

            if (_bars.TryGetValue(unit, out var bar))
                bar.SetDamagePreview(hpDamage, shieldDamage);

            int total = hpDamage + shieldDamage;
            if (minTotal < 0) minTotal = total;
            if (maxTotal < 0) maxTotal = total;
            CrosshairWorldUI.Instance?.Show(unit, hitChance, minTotal, maxTotal);
        }

        public void ClearDamagePreview(Unit unit)
        {
            if (unit != null && _bars.TryGetValue(unit, out var bar))
                bar.ClearDamagePreview();

            CrosshairWorldUI.Instance?.Hide();
        }

        private void TrySpawnBar(Unit unit)
        {
            if (unit == null || _bars.ContainsKey(unit)) return;
            if (!ShouldShowForTeam(unit.Team)) return;

            if (_barPrefab == null)
            {
                Debug.LogError("[UnitHealthBarManager] _barPrefab is not assigned!", this);
                return;
            }

            var barGO = Instantiate(_barPrefab.gameObject, _canvas.transform);
            var bar = barGO.GetComponent<UnitHealthBar>();
            bar.Initialize(unit, _camera);

            unit.OnUnitDied += HandleUnitDied_Manager;

            _bars[unit] = bar;
        }

        private void HandleUnitDied_Manager(Unit unit)
        {
            if (unit != null) unit.OnUnitDied -= HandleUnitDied_Manager;
            if (_bars.TryGetValue(unit, out var bar))
            {
                _bars.Remove(unit);
            }
        }

        private bool ShouldShowForTeam(UnitTeam team) => team switch
        {
            UnitTeam.Player => _showPlayerBars,
            UnitTeam.Enemy => _showEnemyBars,
            UnitTeam.Neutral => _showNeutralBars,
            _ => false
        };

        private void UpdateFullHealthVisibility()
        {
            foreach (var kvp in _bars)
            {
                Unit unit = kvp.Key;
                UnitHealthBar bar = kvp.Value;
                if (bar == null) continue;

                bool fullHP = unit.CurrentHP >= unit.Stats.MaxHP;
                bool fullShield = !unit.HasEnergyShield ||
                                  unit.CurrentEnergyShield >= unit.Stats.MaxEnergyShield;

                bool hide = _hideAtFullHealth && fullHP && fullShield && !bar.IsHovered;
                bar.SetHiddenByManager(hide);
            }
        }

        private void ValidateSetup()
        {
            if (_barPrefab == null) Debug.LogError("[UnitHealthBarManager] _barPrefab is null. Assign a prefab.", this);
            if (_canvas == null) Debug.LogError("[UnitHealthBarManager] _canvas is null. Assign a Canvas.", this);
            if (_camera == null) Debug.LogError("[UnitHealthBarManager] _camera is null.", this);
        }
    }
}