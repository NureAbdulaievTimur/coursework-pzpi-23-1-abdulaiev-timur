using System.Collections;
using TMPro;
using UnityEngine;

namespace CombatGrid
{
    public enum SweepDirection
    {
        LeftToRight,
        RightToLeft,
        BottomToTop,
        TopToBottom,
        TopLeftToBottomRight,
        BottomLeftToTopRight
    }

    [RequireComponent(typeof(TMP_Text))]
    public class GlitchTextEffect : MonoBehaviour
    {

        [Header("Unified Fade & Glitch Timings")]
        [Tooltip("Exact time taken to scramble text into place on GlitchIn.")]
        [SerializeField] private float _glitchInDuration = 0.35f;
        [Tooltip("Exact time taken to scramble text chaotically on GlitchOut.")]
        [SerializeField] private float _glitchOutDuration = 0.25f;

        [Tooltip("Scramble duration when the value changes natively while the label is fully visible")]
        [SerializeField] private float _transitionDuration = 0.13f;
        [Tooltip("Duration to smoothly fade in/out when the text becomes empty (e.g. shield breaks) or appears from empty.")]
        [SerializeField] private float _fadeDuration = 0.35f;

        [Header("Directional Sweep Glow (Vertex Effect)")]
        [Tooltip("Runs a localized band of light/glow across the text geometry at set intervals.")]
        [SerializeField] private bool _sweepEnabled = true;
        [SerializeField] private SweepDirection _sweepDirection = SweepDirection.LeftToRight;
        [Tooltip("How long it takes the band to cross the text completely.")]
        [SerializeField] private float _sweepDuration = 1.2f;
        [Tooltip("How long to wait before the next sweep.")]
        [SerializeField] private float _sweepPause = 2.5f;
        [Tooltip("Offsets the timeline. Give different UI elements different offsets so they don't sweep synchronously.")]
        [SerializeField] private float _sweepTimeOffset = 0f;
        [Tooltip("Width of the band relative to the text's bounding box. 0.3 = 30% of the text width.")]
        [SerializeField, Range(0.05f, 2f)] private float _sweepWidth = 0.3f;
        [Tooltip("Intensity/Opacity of the passing glow band.")]
        [SerializeField, Range(0f, 1f)] private float _sweepIntensity = 0.85f;
        [Tooltip("If true, uses the dynamic Theme Color. If false, uses the Custom Sweep Color below.")]
        [SerializeField] private bool _sweepUsesThemeColor = false;
        [SerializeField] private Color _sweepColor = Color.white;

        [Header("Scramble Logic")]
        [Tooltip("If true, scrambles text randomly as it fades in/out on hover.")]
        [SerializeField] private bool _scrambleOnHover = true;
        [Tooltip("If true, scrambles text when its value updates (e.g., HP changes).")]
        [SerializeField] private bool _scrambleOnChange = true;
        [SerializeField] private string _glitchChars = "!#%@&*<>?/|\\[]{}0123456789ABCDEFabcdef$+-";
        [SerializeField, Range(0.01f, 0.12f)] private float _scrambleTickRate = 0.032f;

        [Header("Vertex Shake (damage impulse)")]
        [SerializeField] private float _shakePixels = 3.5f;
        [SerializeField] private float _shakeDecay = 10f;
        [SerializeField] private float _shakeTickRate = 0.028f;

        [Header("Wave Distortion (damage impulse)")]
        [SerializeField] private float _waveAmt = 2.8f;
        [SerializeField] private float _waveFreq = 4.0f;
        [SerializeField] private float _waveSpeed = 13f;
        [SerializeField] private float _waveDecay = 5f;

        [Header("Flicker (damage impulse)")]
        [SerializeField] private float _flickerFreq = 32f;
        [SerializeField] private float _flickerDepth = 0.55f;
        [SerializeField] private float _flickerDecay = 7f;

        [Header("Block Glitch (damage impulse)")]
        [SerializeField] private float _blockDisplace = 5.0f;
        [SerializeField] private float _blockDecay = 8f;
        [SerializeField] private float _blockTickRate = 0.04f;
        [SerializeField, Range(0f, 1f)] private float _blockThresh = 0.78f;

        [Header("Chromatic Fringe (damage impulse)")]
        [SerializeField] private float _chromIntensityPeak = 60f;
        [SerializeField] private float _chromDecay = 8f;

        [Header("Scanlines (always-on when visible)")]
        [SerializeField] private bool _scanlineEnabled = true;
        [SerializeField] private float _scanlineFreq = 11f;
        [SerializeField] private float _scanlineDepth = 0.50f;
        [SerializeField] private float _scanlineSpeed = 16f;

        [Header("Ambient Sci-Fi Shimmer (always-on when visible)")]
        [SerializeField] private bool _ambientEnabled = true;
        [SerializeField] private float _ambientWaveAmt = 0.45f;
        [SerializeField] private float _ambientWaveFreq = 3.8f;
        [SerializeField] private float _ambientWaveSpeed = 5.5f;
        [SerializeField] private float _ambientFlickerDepth = 0.07f;
        [SerializeField] private float _ambientFlickerFreq = 2.3f;


        private TMP_Text _text;

        private float _lastEffectAlpha = -1f;

        private Color _themeColor = Color.white;

        private string _displayedValue = "";
        private string _pendingValue = "";

        private bool _isVisible = false;
        private float _effectAlpha = 0f;
        private float _elementAlpha = 1f;

        private float _shakeI = 0f;
        private float _waveI = 0f;
        private float _flickI = 0f;
        private float _blockI = 0f;
        private float _chromI = 0f;

        private Vector2[] _shakeOffsets = System.Array.Empty<Vector2>();
        private float[] _blockOffsets = System.Array.Empty<float>();
        private float _nextShakeTick;
        private float _nextBlockTick;

        private float _sweepLocalStartTime = 0f;

        private Coroutine _scrambleCo;
        private bool _meshDirty;

        public bool IsVisible => _isVisible;

        public void SetEffectAlpha(float alpha) => _effectAlpha = alpha;

        public void SetScrambleOnChange(bool enabled) => _scrambleOnChange = enabled;
        public void ResetSweepTimer() => _sweepLocalStartTime = Time.time;

        public void SetThemeColor(Color color)
        {
            _themeColor = color;
        }

        public void Initialize(bool startVisible = false)
        {
            _text = GetComponent<TMP_Text>();

            _displayedValue = _text.text;
            _pendingValue = _displayedValue;
            _isVisible = startVisible;
            _effectAlpha = startVisible ? 1f : 0f;
            _elementAlpha = string.IsNullOrEmpty(_displayedValue) ? 0f : 1f;

            ResetSweepTimer();
            _text.alpha = 1f;

            _meshDirty = true;
            ApplyVertexEffects();
        }

        public void UpdateValue(string newValue, bool immediate = false)
        {
            if (_pendingValue == newValue) return;
            _pendingValue = newValue;

            if (immediate || !_isVisible || !_scrambleOnChange)
            {
                _displayedValue = newValue;
                _text.SetText(newValue);
                _elementAlpha = string.IsNullOrEmpty(newValue) ? 0f : 1f;
                _meshDirty = true;

                if (!immediate && _isVisible && !string.IsNullOrEmpty(newValue))
                {
                    _shakeI = Mathf.Max(_shakeI, 0.9f);
                    _blockI = Mathf.Max(_blockI, 0.7f);
                    _flickI = Mathf.Max(_flickI, 0.5f);
                }

                return;
            }

            KillScramble();
            _scrambleCo = StartCoroutine(TransitionRoutine(newValue));
        }

        public void GlitchIn()
        {
            if (_isVisible) return;
            _isVisible = true;

            ResetSweepTimer();
            KillScramble();

            _elementAlpha = string.IsNullOrEmpty(_displayedValue) ? 0f : 1f;

            if (_scrambleOnHover)
            {
                _shakeI = 1f;
                _waveI = 0.9f;
                _blockI = 0.7f;
                _flickI = 0.6f;
            }

            _scrambleCo = StartCoroutine(ScrambleInRoutine());
        }

        public void GlitchOut()
        {
            if (!_isVisible) return;
            _isVisible = false;

            KillScramble();

            if (_scrambleOnHover)
            {
                _shakeI = 0.8f;
                _blockI = 0.6f;
            }

            _scrambleCo = StartCoroutine(ScrambleOutRoutine());
        }

        public void TriggerDamage(float intensity)
        {
            _shakeI = Mathf.Max(_shakeI, intensity);
            _flickI = Mathf.Max(_flickI, intensity * 0.85f);
            _waveI = Mathf.Max(_waveI, intensity * 0.65f);
            _blockI = Mathf.Max(_blockI, intensity * 0.55f);
            _chromI = Mathf.Max(_chromI, intensity * 0.70f);
        }


        private void Update()
        {
            float dt = Time.deltaTime;
            float now = Time.time;

            _shakeI = Mathf.MoveTowards(_shakeI, 0f, dt * _shakeDecay);
            _waveI = Mathf.MoveTowards(_waveI, 0f, dt * _waveDecay);
            _flickI = Mathf.MoveTowards(_flickI, 0f, dt * _flickerDecay);
            _blockI = Mathf.MoveTowards(_blockI, 0f, dt * _blockDecay);
            _chromI = Mathf.MoveTowards(_chromI, 0f, dt * _chromDecay);

            if (_shakeI > 0.01f && now >= _nextShakeTick)
            {
                _nextShakeTick = now + _shakeTickRate;
                RebuildShakeOffsets();
            }
            if (_blockI > 0.01f && now >= _nextBlockTick)
            {
                _nextBlockTick = now + _blockTickRate;
                RebuildBlockOffsets();
            }

            if (!Mathf.Approximately(_effectAlpha, _lastEffectAlpha))
            {
                _meshDirty = true;
                _lastEffectAlpha = _effectAlpha;
            }

            bool needsAnim = (_effectAlpha > 0.001f && _elementAlpha > 0.001f)
                             && (_shakeI > 0.01f || _waveI > 0.01f
                             || _flickI > 0.01f || _chromI > 0.01f
                             || _scanlineEnabled || _ambientEnabled || _sweepEnabled);

            if (_meshDirty || needsAnim)
            {
                ApplyVertexEffects();
                _meshDirty = false;
            }
        }

        private IEnumerator TransitionRoutine(string newValue)
        {
            _shakeI = Mathf.Max(_shakeI, 0.9f);
            _blockI = Mathf.Max(_blockI, 0.7f);
            _flickI = Mathf.Max(_flickI, 0.5f);

            float elapsed = 0f;
            float nextTick = Time.time;

            bool isFadingOut = string.IsNullOrEmpty(newValue) && !string.IsNullOrEmpty(_displayedValue);
            bool isFadingIn = !string.IsNullOrEmpty(newValue) && string.IsNullOrEmpty(_displayedValue);
            float routineDuration = (isFadingOut || isFadingIn) ? _fadeDuration : _transitionDuration;
            string sourceText = string.IsNullOrEmpty(_displayedValue) ? newValue : _displayedValue;

            while (elapsed < routineDuration)
            {
                elapsed += Time.deltaTime;
                float t = elapsed / routineDuration;

                if (isFadingOut) _elementAlpha = Mathf.Lerp(1f, 0f, t);
                else if (isFadingIn) _elementAlpha = Mathf.Lerp(0f, 1f, t);
                else _elementAlpha = 1f;

                if (Time.time >= nextTick)
                {
                    nextTick = Time.time + _scrambleTickRate;
                    _text.SetText(Scramble(sourceText, 1f));
                    _meshDirty = true;
                }
                yield return null;
            }

            _elementAlpha = isFadingOut ? 0f : 1f;
            _displayedValue = newValue;
            _text.SetText(newValue);
            _meshDirty = true;
            _scrambleCo = null;
        }

        private IEnumerator ScrambleInRoutine()
        {
            float elapsed = 0f;
            float nextTick = Time.time;

            while (elapsed < _glitchInDuration)
            {
                elapsed += Time.deltaTime;

                if (_scrambleOnHover)
                {
                    float t = elapsed / _glitchInDuration;
                    float scrambleAmt = Mathf.Lerp(1f, 0f, Mathf.Pow(t, 0.65f));

                    if (Time.time >= nextTick)
                    {
                        nextTick = Time.time + _scrambleTickRate;
                        _text.SetText(Scramble(_displayedValue, scrambleAmt));
                        _meshDirty = true;
                    }
                }
                yield return null;
            }

            _text.SetText(_displayedValue);
            _meshDirty = true;
            _scrambleCo = null;
        }

        private IEnumerator ScrambleOutRoutine()
        {
            float elapsed = 0f;
            float nextTick = Time.time;

            while (elapsed < _glitchOutDuration)
            {
                elapsed += Time.deltaTime;

                if (_scrambleOnHover)
                {
                    float t = elapsed / _glitchOutDuration;
                    float scrambleAmt = Mathf.Pow(t, 0.4f);

                    if (Time.time >= nextTick)
                    {
                        nextTick = Time.time + _scrambleTickRate;
                        _text.SetText(Scramble(_displayedValue, scrambleAmt));
                        _meshDirty = true;
                    }
                }
                yield return null;
            }

            _text.SetText(_displayedValue);
            _meshDirty = true;
            _scrambleCo = null;
        }

        private string Scramble(string source, float intensity)
        {
            if (string.IsNullOrEmpty(source) || _glitchChars.Length == 0) return source;

            char[] chars = source.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                if (chars[i] == ' ') continue;
                if (Random.value < intensity)
                    chars[i] = _glitchChars[Random.Range(0, _glitchChars.Length)];
            }
            return new string(chars);
        }

        private void RebuildShakeOffsets()
        {
            int count = _text.textInfo?.characterCount ?? 0;
            if (_shakeOffsets.Length != count) _shakeOffsets = new Vector2[count];

            for (int i = 0; i < count; i++)
                _shakeOffsets[i] = new Vector2(
                    (Random.value - 0.5f) * 2f * _shakePixels,
                    (Random.value - 0.5f) * 2f * _shakePixels);
        }

        private void RebuildBlockOffsets()
        {
            int count = _text.textInfo?.characterCount ?? 0;
            if (_blockOffsets.Length != count) _blockOffsets = new float[count];

            for (int i = 0; i < count; i++)
                _blockOffsets[i] = (Random.value > _blockThresh)
                    ? (Random.value - 0.5f) * 2f * _blockDisplace : 0f;
        }

        private void ApplyVertexEffects()
        {
            if (_text == null) return;
            _text.ForceMeshUpdate();

            var info = _text.textInfo;
            if (info == null || info.characterCount == 0) return;

            float t = Time.time;
            Color32 themeC32 = _themeColor;
            float currentAlpha = _effectAlpha * _elementAlpha;

            bool doSweep = _sweepEnabled && currentAlpha > 0.01f;
            Vector2 sweepDir = Vector2.right;
            float currentSweepCenter = 0f;
            float invSweepWidth = 1f;
            Color32 sweepC32 = _sweepUsesThemeColor ? _themeColor : _sweepColor;

            if (doSweep)
            {
                switch (_sweepDirection)
                {
                    case SweepDirection.LeftToRight: sweepDir = new Vector2(1, 0); break;
                    case SweepDirection.RightToLeft: sweepDir = new Vector2(-1, 0); break;
                    case SweepDirection.BottomToTop: sweepDir = new Vector2(0, 1); break;
                    case SweepDirection.TopToBottom: sweepDir = new Vector2(0, -1); break;
                    case SweepDirection.TopLeftToBottomRight: sweepDir = new Vector2(1, -1).normalized; break;
                    case SweepDirection.BottomLeftToTopRight: sweepDir = new Vector2(1, 1).normalized; break;
                }

                float sweepMinProj = float.MaxValue;
                float sweepMaxProj = float.MinValue;

                for (int ci = 0; ci < info.characterCount; ci++)
                {
                    var ch = info.characterInfo[ci];
                    if (!ch.isVisible) continue;
                    int mi = ch.materialReferenceIndex;
                    int vi = ch.vertexIndex;
                    if (vi + 3 >= info.meshInfo[mi].vertices.Length) continue;

                    for (int v = 0; v < 4; v++)
                    {
                        float p = info.meshInfo[mi].vertices[vi + v].x * sweepDir.x + info.meshInfo[mi].vertices[vi + v].y * sweepDir.y;
                        if (p < sweepMinProj) sweepMinProj = p;
                        if (p > sweepMaxProj) sweepMaxProj = p;
                    }
                }

                float totalSpan = sweepMaxProj - sweepMinProj;

                if (sweepMinProj == float.MaxValue)
                {
                    doSweep = false;
                    totalSpan = 1f;
                }
                else if (totalSpan < 0.001f)
                {
                    totalSpan = 1f;
                }

                float bandSize = totalSpan * _sweepWidth;
                invSweepWidth = 1f / (bandSize + 0.001f);

                float safeDuration = Mathf.Max(0.01f, _sweepDuration);
                float totalCycle = safeDuration + _sweepPause;

                float sweepT = t - _sweepLocalStartTime;
                float cycleT = Mathf.Repeat(sweepT + _sweepTimeOffset, totalCycle);
                float progress = cycleT / safeDuration;

                if (progress > 1f)
                {
                    doSweep = false;
                }
                else
                {
                    float edgeBuffer = bandSize + (totalSpan * 0.1f) + 0.5f;
                    float startPos = sweepMinProj - edgeBuffer;
                    float endPos = sweepMaxProj + edgeBuffer;
                    currentSweepCenter = Mathf.Lerp(startPos, endPos, progress);
                }
            }

            for (int ci = 0; ci < info.characterCount; ci++)
            {
                var ch = info.characterInfo[ci];
                if (!ch.isVisible) continue;

                int mi = ch.materialReferenceIndex;
                int vi = ch.vertexIndex;

                if (vi + 3 >= info.meshInfo[mi].vertices.Length) continue;

                Vector3[] verts = info.meshInfo[mi].vertices;
                Color32[] colors = info.meshInfo[mi].colors32;

                float midY = (verts[vi].y + verts[vi + 2].y) * 0.5f;

                float waveOff = 0f;
                if (_waveI > 0.01f)
                    waveOff = Mathf.Sin(t * _waveSpeed + ci * _waveFreq) * _waveAmt * _waveI;

                float ambientWaveOff = 0f;
                if (_ambientEnabled && currentAlpha > 0.01f)
                    ambientWaveOff = Mathf.Sin(t * _ambientWaveSpeed + ci * _ambientWaveFreq)
                                   * _ambientWaveAmt * currentAlpha;

                float shkX = 0f, shkY = 0f;
                if (_shakeI > 0.01f && ci < _shakeOffsets.Length)
                {
                    shkX = _shakeOffsets[ci].x * _shakeI;
                    shkY = _shakeOffsets[ci].y * _shakeI;
                }

                float blkX = 0f;
                if (_blockI > 0.01f && ci < _blockOffsets.Length)
                    blkX = _blockOffsets[ci] * _blockI;

                var vertOffset = new Vector3(shkX + blkX, shkY + waveOff + ambientWaveOff, 0f);
                for (int v = 0; v < 4; v++)
                    verts[vi + v] += vertOffset;

                float flicker = 1f;
                if (_flickI > 0.01f)
                    flicker -= _flickI * _flickerDepth
                             * (0.5f + 0.5f * Mathf.Sin(t * _flickerFreq + ci * 3.719f));

                float ambFlicker = 1f;
                if (_ambientEnabled && currentAlpha > 0.01f)
                    ambFlicker -= _ambientFlickerDepth
                                * (0.5f + 0.5f * Mathf.Sin(t * _ambientFlickerFreq + ci * 7.391f));

                float scanMask = 0f;
                if (_scanlineEnabled && currentAlpha > 0.01f)
                {
                    float scanPhase = midY * _scanlineFreq + t * _scanlineSpeed;
                    scanMask = 0.5f + 0.5f * Mathf.Sin(scanPhase);
                }

                byte finalAlpha = (byte)Mathf.RoundToInt(
                    Mathf.Clamp01(flicker * ambFlicker * (1f - scanMask * _scanlineDepth * 0.5f) * currentAlpha) * 255f);

                for (int v = 0; v < 4; v++)
                {
                    Color32 col = colors[vi + v];

                    if (_scanlineEnabled && currentAlpha > 0.01f)
                    {
                        float tintAmount = scanMask * _scanlineDepth;
                        col.r = (byte)Mathf.Lerp(col.r, themeC32.r, tintAmount);
                        col.g = (byte)Mathf.Lerp(col.g, themeC32.g, tintAmount);
                        col.b = (byte)Mathf.Lerp(col.b, themeC32.b, tintAmount);
                    }

                    byte vertAlpha = finalAlpha;

                    if (doSweep)
                    {
                        Vector3 origPos = verts[vi + v] - vertOffset;

                        float p = origPos.x * sweepDir.x + origPos.y * sweepDir.y;
                        float dist = Mathf.Abs(p - currentSweepCenter);
                        float sweepFactor = Mathf.Clamp01(1f - (dist * invSweepWidth));

                        sweepFactor = sweepFactor * sweepFactor * (3f - 2f * sweepFactor);

                        if (sweepFactor > 0f)
                        {
                            float strength = sweepFactor * _sweepIntensity;

                            col.r = (byte)Mathf.Lerp(col.r, sweepC32.r, strength);
                            col.g = (byte)Mathf.Lerp(col.g, sweepC32.g, strength);
                            col.b = (byte)Mathf.Lerp(col.b, sweepC32.b, strength);
                        }
                    }

                    if (_chromI > 0.01f)
                    {
                        int rShift = (int)(_chromI * _chromIntensityPeak);
                        int bShift = rShift;
                        if (v >= 2) col.r = (byte)Mathf.Min(255, col.r + rShift);
                        else col.b = (byte)Mathf.Min(255, col.b + bShift);
                    }

                    col.a = vertAlpha;
                    colors[vi + v] = col;
                }
            }

            _text.UpdateVertexData(
                TMP_VertexDataUpdateFlags.Vertices | TMP_VertexDataUpdateFlags.Colors32);
        }

        private void KillScramble()
        {
            if (_scrambleCo == null) return;
            StopCoroutine(_scrambleCo);
            _scrambleCo = null;
        }
    }
}