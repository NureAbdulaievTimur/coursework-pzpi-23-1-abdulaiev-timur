using UnityEngine;
using CombatGrid;

public class ShieldVisuals : MonoBehaviour
{
    [SerializeField] private MeshRenderer _shieldRenderer;

    private Material _mat;
    private Unit _unit;
    private Vector4[] _hitData = new Vector4[6];
    private int _hitIndex = 0;

    private float _lastShatterTime = -1000f;

    private void Awake()
    {
        if (_shieldRenderer == null) _shieldRenderer = GetComponent<MeshRenderer>();

        _mat = _shieldRenderer.material;
        _unit = GetComponentInParent<Unit>();

        _mat.SetVector("_ShatterData", new Vector4(0f, 0f, 0f, -1000f));
        _mat.SetFloat("_RegenTime", -1000f);
        _mat.SetVectorArray("_HitData", _hitData);
    }

    public Bounds GetShieldBounds() =>
        _shieldRenderer != null
            ? _shieldRenderer.bounds
            : new Bounds(transform.position, Vector3.one);

    private void OnEnable()
    {
        if (_unit != null) _unit.OnShieldRestored += HandleShieldRestored;
    }

    private void OnDisable()
    {
        if (_unit != null) _unit.OnShieldRestored -= HandleShieldRestored;
    }

    private void Update()
    {
        if (_unit.CurrentEnergyShield <= 0 && Time.time > _lastShatterTime + 2.5f)
        {
            if (_shieldRenderer.enabled) _shieldRenderer.enabled = false;
        }
    }

    public void RegisterHit(Vector3 worldHitPos, Vector3 bulletDir, bool brokeShield)
    {
        _shieldRenderer.enabled = true;

        Vector3 centerToHit = (worldHitPos - _shieldRenderer.bounds.center).normalized;

        Vector3 worldImpactDir = (centerToHit - bulletDir).normalized;

        Vector3 localDir = transform.InverseTransformDirection(worldImpactDir).normalized;

        if (brokeShield)
        {
            _lastShatterTime = Time.time;
            _mat.SetVector("_ShatterData", new Vector4(localDir.x, localDir.y, localDir.z, Time.time));
        }
        else
        {
            _hitData[_hitIndex] = new Vector4(localDir.x, localDir.y, localDir.z, Time.time);
            _mat.SetVectorArray("_HitData", _hitData);
            _hitIndex = (_hitIndex + 1) % 6;
        }
    }

    private void HandleShieldRestored(Unit unit)
    {
        _shieldRenderer.enabled = true;
        _mat.SetFloat("_RegenTime", Time.time);
    }
}