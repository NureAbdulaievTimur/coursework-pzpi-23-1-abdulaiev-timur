using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    [RequireComponent(typeof(GridManager))]
    public class CombatGridShaderBridge : MonoBehaviour
    {
        [Header("Materials")]
        [SerializeField] private Material _overlayMaterial;
        [SerializeField] private Material _scannerMaterial;

        [Header("Grid Fades")]
        [SerializeField, Min(0.01f)] private float _globalFadeSpeed = 2.5f;
        [SerializeField, Min(0.01f)] private float _selectionFadeInSpeed = 5.0f;
        [SerializeField, Min(0.01f)] private float _selectionFadeOutSpeed = 3.5f;
        [SerializeField, Min(0.01f)] private float _hoverFadeInSpeed = 8.0f;
        [SerializeField, Min(0.01f)] private float _hoverFadeOutSpeed = 4.0f;
        [SerializeField, Min(0.01f)] private float _unitIndicatorFadeSpeed = 4.0f;
        [SerializeField, Min(1f)] private float _hoverMoveSpeed = 12f;
        [SerializeField] private bool _disableScannerGridInCombat = true;

        [Header("Cover Icon Fades")]
        [SerializeField, Min(0.01f)] private float _coverIconFadeInSpeed = 15f;
        [SerializeField, Min(0.01f)] private float _coverIconFadeOutSpeed = 10f;
        [SerializeField, Min(0.01f)] private float _coverIconMoveSpeed = 20f;

        [Header("Unit Glow")]
        [SerializeField, Range(0, 3)] private int _unitGlowRadius = 1;
        [SerializeField, Min(0.1f)] private float _unitGlowDecaySpeed = 3f;

        [Header("Unit Hover Glow")]
        [SerializeField] private Color _friendlyHoverGlowColor = new Color(0.1f, 0.9f, 0.4f, 1f);
        [SerializeField] private Color _enemyHoverGlowColor = new Color(1.0f, 0.15f, 0.1f, 1f);
        [SerializeField] private Color _neutralHoverGlowColor = new Color(0.8f, 0.7f, 0.1f, 1f);
        [SerializeField, Min(0f)] private float _unitHoverGlowHeight = 2.5f;
        [SerializeField, Min(0f)] private float _unitHoverGlowRadius = 0.8f;
        [SerializeField, Min(0f)] private float _unitHoverGlowIntensity = 1.2f;
        [SerializeField, Range(1f, 20f)] private float _unitHoverGlowHDR = 3.0f;

        private static readonly int StateTex_ID = Shader.PropertyToID("_CombatGridStateTex");
        private static readonly int Origin_ID = Shader.PropertyToID("_CombatGridOrigin");
        private static readonly int CellSize_ID = Shader.PropertyToID("_CombatGridCellSize");
        private static readonly int Width_ID = Shader.PropertyToID("_CombatGridWidth");
        private static readonly int Height_ID = Shader.PropertyToID("_CombatGridHeight");
        private static readonly int GlobalAlpha_ID = Shader.PropertyToID("_CombatGridGlobalAlpha");
        private static readonly int SelectionFade_ID = Shader.PropertyToID("_SelectionFade");
        private static readonly int HoverFade_ID = Shader.PropertyToID("_HoverFade");
        private static readonly int PathFade_ID = Shader.PropertyToID("_PathFade");
        private static readonly int HoveredCell_ID = Shader.PropertyToID("_HoveredCell");
        private static readonly int HoverTargetXY_ID = Shader.PropertyToID("_HoverTargetXY");
        private static readonly int SelectedCellXY_ID = Shader.PropertyToID("_SelectedCellXY");
        private static readonly int HoveredWorldPos_ID = Shader.PropertyToID("_HoveredWorldPos");

        private static readonly int HoverUnitWorldPos_ID = Shader.PropertyToID("_HoverUnitWorldPos");
        private static readonly int HoverUnitColor_ID = Shader.PropertyToID("_HoverUnitColor");

        private static readonly int AttackMode_ID = Shader.PropertyToID("_CombatGridAttackMode");
        private static readonly int AttackRange_ID = Shader.PropertyToID("_SelectedUnitAttackRange");

        private static readonly int SelectedUnitWorldPos_ID = Shader.PropertyToID("_SelectedUnitWorldPos");
        private static readonly int SelectedUnitColor_ID = Shader.PropertyToID("_SelectedUnitColor");

        private static readonly int HoverUnitGlowHeight_ID = Shader.PropertyToID("_HoverUnitGlowHeight");
        private static readonly int HoverUnitGlowRadius_ID = Shader.PropertyToID("_HoverUnitGlowRadius");
        private static readonly int HoverUnitGlowIntensity_ID = Shader.PropertyToID("_HoverUnitGlowIntensity");
        private static readonly int HoverUnitGlowHDR_ID = Shader.PropertyToID("_HoverUnitGlowHDR");

        private const string ScannerFloorGridKeyword = "ENABLE_FLOOR_GRID";

        private const float CT_INACTIVE = 0f / 8f;
        private const float CT_WALKABLE = 1f / 8f;
        private const float CT_REACHABLE = 2f / 8f;
        private const float CT_PATH = 3f / 8f;
        private const float CT_SELECTED = 4f / 8f;
        private const float CT_FRIENDLY = 5f / 8f;
        private const float CT_ENEMY = 6f / 8f;
        private const float CT_NEUTRAL = 8f / 8f;
        private const float CT_UNWALKABLE = 7f / 8f;

        private static readonly Dictionary<GridCoord, int> DirToIndex = new()
        {
            { new GridCoord( 0,  1), 1 }, { new GridCoord( 1,  1), 2 },
            { new GridCoord( 1,  0), 3 }, { new GridCoord( 1, -1), 4 },
            { new GridCoord( 0, -1), 5 }, { new GridCoord(-1, -1), 6 },
            { new GridCoord(-1,  0), 7 }, { new GridCoord(-1,  1), 8 },
        };

        private GridManager _grid;
        private GridSettings _settings;
        private Texture2D _stateTex;
        private Color[] _statePixels;

        private bool _combatModeActive;

        private float _currentGlobalAlpha;
        private float _currentSelectionFade;
        private float _currentHoverFade;
        private float _currentPathFade;

        private Vector3 _currentCoverHoverPos;
        private float _currentCoverHoverAlpha;
        private GridCell _targetCoverHoverCell;

        private float _currentUnitHoverFade;
        private bool _hasUnitHover;
        private Color _lastUnitHoverColor;
        private Vector3 _lastUnitFootPos;

        private float _currentUnitSelectedFade;
        private bool _hasUnitSelected;
        private Color _lastUnitSelectedColor;
        private Vector3 _lastUnitSelectedFootPos;

        private bool _hasSelection;
        private bool _hasHover;
        private bool _hasPath;
        private bool _suppressSelectionVisuals;
        private bool _selectionWithoutReachable;
        private Vector2 _smoothHoveredPos;
        private Vector2 _targetHoveredPos;

        private bool _queuedAttackMode;
        private int _queuedAttackRange;
        private bool _hasQueuedAttackMode;

        private bool _wantsSelectionClear;
        private bool _wantsHoverClear;
        private bool _wantsPathClear;

        private List<GridCell> _queuedReachableCells;
        private GridCoord _queuedSelectedCoord;
        private bool _hasQueuedSelection;

        private List<GridCell> _queuedPath;
        private bool _hasQueuedPath;

        private Dictionary<Unit, float> _unitStandFades = new();
        private Dictionary<GridCoord, float> _glowMap = new();
        private HashSet<GridCoord> _reachableSet = new();
        private List<GridCell> _currentPath = new();
        private HashSet<GridCoord> _hoveredPathSet = new();
        private GridCoord _selectedCoord = GridCoord.Zero;
        private GridCoord _hoveredCoord;
        private bool _reachableSetActive;

        private void Awake()
        {
            _grid = GetComponent<GridManager>();
            _settings = _grid.Settings;
        }

        private void OnEnable()
        {
            _grid.OnGridInitialized += OnGridInitialized;
            if (_grid.IsInitialized) OnGridInitialized();
        }

        private void OnDisable() => _grid.OnGridInitialized -= OnGridInitialized;

        private void OnDestroy()
        {
            if (_stateTex != null) Destroy(_stateTex);
        }

        private void Update()
        {
            if (_stateTex == null) return;

            float targetGlobal = _combatModeActive ? 1f : 0f;
            _currentGlobalAlpha = Mathf.MoveTowards(_currentGlobalAlpha, targetGlobal, _globalFadeSpeed * Time.deltaTime);

            float targetSelection = (_hasSelection && (_reachableSetActive || _selectionWithoutReachable) && !_suppressSelectionVisuals) ? 1f : 0f;
            float selSpeed = targetSelection > 0f ? _selectionFadeInSpeed : _selectionFadeOutSpeed;

            if (_hasQueuedSelection) selSpeed = _selectionFadeOutSpeed * 1.5f;

            _currentSelectionFade = Mathf.MoveTowards(_currentSelectionFade, targetSelection, selSpeed * Time.deltaTime);

            if (_currentSelectionFade <= 0f)
            {
                if (_wantsSelectionClear)
                {
                    _reachableSet.Clear();
                    _reachableSetActive = false;
                    _wantsSelectionClear = false;
                    _selectedCoord = GridCoord.Zero;
                }

                if (_hasQueuedAttackMode)
                {
                    ApplyAttackMode(_queuedAttackMode, _queuedAttackRange);
                }

                if (_hasQueuedSelection)
                {
                    _currentPath.Clear();
                    _hoveredPathSet.Clear();
                    _currentPathFade = 0f;

                    if (_queuedReachableCells == null)
                        ApplySelectedOnly(_queuedSelectedCoord);
                    else
                        ApplySelection(_queuedSelectedCoord, _queuedReachableCells);

                    _hasQueuedSelection = false;
                    _queuedReachableCells = null;
                }

                if (_hasQueuedPath)
                {
                    ApplyHoveredPath(_queuedPath);
                    _queuedPath = null;
                }
            }

            float targetPath = _hasPath ? 1f : 0f;
            float pathSpeed = targetPath > 0f ? _selectionFadeInSpeed : _selectionFadeOutSpeed;

            if (_hasQueuedSelection) pathSpeed = _selectionFadeOutSpeed * 1.5f;

            _currentPathFade = Mathf.MoveTowards(_currentPathFade, targetPath, pathSpeed * Time.deltaTime);

            if (_currentPathFade <= 0f && _wantsPathClear)
            {
                _currentPath.Clear();
                _hoveredPathSet.Clear();
                _wantsPathClear = false;
            }

            float targetHover = _hasHover ? 1f : 0f;
            float hovSpeed = targetHover > 0f ? _hoverFadeInSpeed : _hoverFadeOutSpeed;
            _currentHoverFade = Mathf.MoveTowards(_currentHoverFade, targetHover, hovSpeed * Time.deltaTime);

            if (_hasHover)
                _smoothHoveredPos = Vector2.Lerp(_smoothHoveredPos, _targetHoveredPos, _hoverMoveSpeed * Time.deltaTime);

            UpdateCoverIconHover();

            var unitKeys = new List<Unit>(_unitStandFades.Keys);
            foreach (var u in unitKeys)
            {
                if (u == null || !u.IsAlive)
                {
                    _unitStandFades.Remove(u);
                    continue;
                }
                float unitTarget = u.Movement.IsMoving ? 0f : 1f;
                _unitStandFades[u] = Mathf.MoveTowards(_unitStandFades[u], unitTarget, _unitIndicatorFadeSpeed * Time.deltaTime);
            }

            if (_overlayMaterial != null)
            {
                _overlayMaterial.SetFloat(GlobalAlpha_ID, _currentGlobalAlpha);
                _overlayMaterial.SetFloat(SelectionFade_ID, _currentSelectionFade);
                _overlayMaterial.SetFloat(PathFade_ID, _currentPathFade);
                _overlayMaterial.SetFloat(HoverFade_ID, _currentHoverFade);
                _overlayMaterial.SetVector(HoveredCell_ID, new Vector4(_smoothHoveredPos.x, _smoothHoveredPos.y, _currentHoverFade > 0.001f ? 1f : 0f, 0f));
                _overlayMaterial.SetVector(HoverTargetXY_ID, new Vector4(_targetHoveredPos.x, _targetHoveredPos.y, 0, 0));
                _overlayMaterial.SetVector(SelectedCellXY_ID, new Vector4(_selectedCoord.X, _selectedCoord.Z, 0, 0));
            }

            DecayGlows();
            UpdateUnitHoverGlow();
            UpdateUnitSelectedGlow();

            if (_currentGlobalAlpha > 0.001f)
                BuildAndUploadStateTexture();
        }

        private void UpdateCoverIconHover()
        {
            Vector3 targetPos = _currentCoverHoverPos;
            float targetAlpha = 0f;

            if (_targetCoverHoverCell != null)
            {
                targetPos = _grid.CoordToWorld(_targetCoverHoverCell.Coord);
                targetAlpha = 1f;

                if (_currentCoverHoverAlpha <= 0.01f) _currentCoverHoverPos = targetPos;
            }

            _currentCoverHoverPos = Vector3.Lerp(_currentCoverHoverPos, targetPos, Time.deltaTime * _coverIconMoveSpeed);

            float covSpeed = targetAlpha > 0f ? _coverIconFadeInSpeed : _coverIconFadeOutSpeed;
            _currentCoverHoverAlpha = Mathf.MoveTowards(_currentCoverHoverAlpha, targetAlpha, Time.deltaTime * covSpeed);

            Shader.SetGlobalVector(HoveredWorldPos_ID, new Vector4(_currentCoverHoverPos.x, _currentCoverHoverPos.y, _currentCoverHoverPos.z, _currentCoverHoverAlpha));
        }

        private void UpdateUnitHoverGlow()
        {
            GridCell hoveredCell = _hasHover ? _grid.GetCell(_hoveredCoord) : null;
            bool unitPresent = hoveredCell != null && hoveredCell.IsOccupied
                                                       && hoveredCell.Occupant != null
                                                       && hoveredCell.Occupant.IsAlive;

            if (unitPresent)
            {
                Unit occupant = hoveredCell.Occupant;
                _lastUnitHoverColor = occupant.Team switch
                {
                    UnitTeam.Player => _friendlyHoverGlowColor,
                    UnitTeam.Enemy => _enemyHoverGlowColor,
                    _ => _neutralHoverGlowColor,
                };
                _lastUnitFootPos = _grid.CoordToWorld(_hoveredCoord);
                _hasUnitHover = true;
            }
            else
            {
                _hasUnitHover = false;
            }

            float targetUnitFade = _hasUnitHover ? 1f : 0f;
            float unitFadeSpeed = targetUnitFade > 0f ? _hoverFadeInSpeed : _hoverFadeOutSpeed;
            _currentUnitHoverFade = Mathf.MoveTowards(
                _currentUnitHoverFade, targetUnitFade, unitFadeSpeed * Time.deltaTime);

            bool glowActive = _currentUnitHoverFade > 0.001f;

            Shader.SetGlobalVector(HoverUnitWorldPos_ID, glowActive
                ? new Vector4(_lastUnitFootPos.x, _lastUnitFootPos.y, _lastUnitFootPos.z, 1f)
                : Vector4.zero);

            Shader.SetGlobalVector(HoverUnitColor_ID, new Vector4(
                _lastUnitHoverColor.r,
                _lastUnitHoverColor.g,
                _lastUnitHoverColor.b,
                _currentUnitHoverFade));

            Shader.SetGlobalFloat(HoverUnitGlowHeight_ID, _unitHoverGlowHeight);
            Shader.SetGlobalFloat(HoverUnitGlowRadius_ID, _unitHoverGlowRadius);
            Shader.SetGlobalFloat(HoverUnitGlowIntensity_ID, _unitHoverGlowIntensity);
            Shader.SetGlobalFloat(HoverUnitGlowHDR_ID, _unitHoverGlowHDR);
        }

        private void UpdateUnitSelectedGlow()
        {
            bool isSelectionVisible = (_hasSelection || _hasQueuedSelection) && !_suppressSelectionVisuals;
            GridCell selectedCell = isSelectionVisible ? _grid.GetCell(_selectedCoord) : null;

            bool unitPresent = selectedCell != null && selectedCell.IsOccupied
                                                       && selectedCell.Occupant != null
                                                       && selectedCell.Occupant.IsAlive;

            if (unitPresent)
            {
                Unit occupant = selectedCell.Occupant;
                _lastUnitSelectedColor = occupant.Team switch
                {
                    UnitTeam.Player => _friendlyHoverGlowColor,
                    UnitTeam.Enemy => _enemyHoverGlowColor,
                    _ => _neutralHoverGlowColor,
                };
                _lastUnitSelectedFootPos = _grid.CoordToWorld(_selectedCoord);
                _hasUnitSelected = true;
            }
            else
            {
                _hasUnitSelected = false;
            }

            float targetUnitFade = _hasUnitSelected ? 1f : 0f;
            float unitFadeSpeed = targetUnitFade > 0f ? _selectionFadeInSpeed : _selectionFadeOutSpeed;
            _currentUnitSelectedFade = Mathf.MoveTowards(
                _currentUnitSelectedFade, targetUnitFade, unitFadeSpeed * Time.deltaTime);

            bool glowActive = _currentUnitSelectedFade > 0.001f;

            Shader.SetGlobalVector(SelectedUnitWorldPos_ID, glowActive
                ? new Vector4(_lastUnitSelectedFootPos.x, _lastUnitSelectedFootPos.y, _lastUnitSelectedFootPos.z, 1f)
                : Vector4.zero);

            Shader.SetGlobalVector(SelectedUnitColor_ID, new Vector4(
                _lastUnitSelectedColor.r,
                _lastUnitSelectedColor.g,
                _lastUnitSelectedColor.b,
                _currentUnitSelectedFade));
        }

        private void OnGridInitialized()
        {
            int w = _settings.Width;
            int h = _settings.Height;

            if (_stateTex != null) Destroy(_stateTex);

            _stateTex = new Texture2D(w, h, TextureFormat.RGBAHalf, false, true)
            {
                filterMode = FilterMode.Point,
                wrapMode = TextureWrapMode.Clamp,
                name = "CombatGridState"
            };
            _statePixels = new Color[w * h];

            if (_overlayMaterial == null) return;

            _overlayMaterial.SetVector(Origin_ID, _settings.OriginPosition);
            _overlayMaterial.SetFloat(CellSize_ID, _settings.CellSize);
            _overlayMaterial.SetFloat(Width_ID, w);
            _overlayMaterial.SetFloat(Height_ID, h);
            _overlayMaterial.SetTexture(StateTex_ID, _stateTex);
        }

        private void BuildAndUploadStateTexture()
        {
            int w = _settings.Width;
            int h = _settings.Height;

            for (int x = 0; x < w; x++)
            {
                for (int z = 0; z < h; z++)
                {
                    var coord = new GridCoord(x, z);
                    GridCell cell = _grid.GetCell(coord);
                    if (cell == null) continue;

                    int idx = z * w + x;
                    float cellType;
                    float arrowDir = 0f;
                    float dynamicDataB = _glowMap.TryGetValue(coord, out float g) ? g : 0f;
                    float flags = 0f;

                    if (_hoveredPathSet.Contains(coord) && _currentPath.Count > 0)
                        arrowDir = EncodeArrowDir(coord);

                    if (cell.IsObstructed) cellType = CT_INACTIVE;
                    else if (!cell.IsWalkable) cellType = CT_UNWALKABLE;
                    else if (cell.IsOccupied)
                    {
                        Unit occupant = cell.Occupant;
                        cellType = occupant.Team == UnitTeam.Player ? CT_FRIENDLY
                             : occupant.Team == UnitTeam.Enemy ? CT_ENEMY
                                                                    : CT_NEUTRAL;

                        if (!_unitStandFades.ContainsKey(occupant))
                            _unitStandFades[occupant] = occupant.Movement.IsMoving ? 0f : 1f;

                        dynamicDataB = _unitStandFades[occupant];
                    }
                    else if (_hoveredPathSet.Contains(coord) && _currentPath.Count > 0) cellType = CT_PATH;
                    else if (_reachableSet.Contains(coord)) cellType = CT_REACHABLE;
                    else cellType = CT_WALKABLE;

                    bool coordIsReachable = _reachableSet.Contains(coord);
                    bool coordIsHovered = _currentHoverFade > 0.001f && coord == _hoveredCoord;

                    if (coordIsReachable && coordIsHovered) flags = 1.00f;
                    else if (coordIsReachable) flags = 0.67f;
                    else if (coordIsHovered) flags = 0.33f;
                    else if (_reachableSetActive && cellType == CT_WALKABLE) flags = 0.00f;
                    else flags = 0.10f;

                    _statePixels[idx] = new Color(cellType, arrowDir / 8f, dynamicDataB, flags);
                }
            }
            _stateTex.SetPixels(_statePixels);
            _stateTex.Apply(false);
        }

        private float EncodeArrowDir(GridCoord coord)
        {
            for (int i = 0; i < _currentPath.Count - 1; i++)
            {
                if (_currentPath[i].Coord == coord)
                {
                    GridCoord delta = _currentPath[i + 1].Coord - coord;
                    delta = new GridCoord(delta.X == 0 ? 0 : (delta.X > 0 ? 1 : -1), delta.Z == 0 ? 0 : (delta.Z > 0 ? 1 : -1));
                    if (DirToIndex.TryGetValue(delta, out int idx)) return idx;
                }
            }
            return 0f;
        }

        private void DecayGlows()
        {
            var keys = new List<GridCoord>(_glowMap.Keys);
            foreach (var k in keys)
            {
                _glowMap[k] = Mathf.Max(0f, _glowMap[k] - _unitGlowDecaySpeed * Time.deltaTime);
                if (_glowMap[k] < 0.01f) _glowMap.Remove(k);
            }
        }

        public void SetCombatMode(bool active)
        {
            if (_combatModeActive == active) return;
            _combatModeActive = active;

            if (_disableScannerGridInCombat && _scannerMaterial != null)
            {
                if (active) _scannerMaterial.DisableKeyword(ScannerFloorGridKeyword);
                else _scannerMaterial.EnableKeyword(ScannerFloorGridKeyword);
            }

            if (!active) ClearAllState();
        }

        public void SetAttackMode(bool active, int attackRange)
        {
            if (_currentSelectionFade > 0.05f)
            {
                _queuedAttackMode = active;
                _queuedAttackRange = attackRange;
                _hasQueuedAttackMode = true;
            }
            else
            {
                ApplyAttackMode(active, attackRange);
            }
        }

        private void ApplyAttackMode(bool active, int attackRange)
        {
            _hasQueuedAttackMode = false;
            if (_overlayMaterial != null)
            {
                _overlayMaterial.SetFloat(AttackMode_ID, active ? 1f : 0f);
                _overlayMaterial.SetInt(AttackRange_ID, attackRange);
            }
        }

        public bool IsCombatModeActive => _combatModeActive;

        public void SetSelectedAndReachable(GridCoord selected, List<GridCell> reachable)
        {
            if (reachable == null || reachable.Count == 0)
            {
                _hasSelection = false;
                _wantsSelectionClear = true;
                _hasQueuedSelection = false;
                _selectionWithoutReachable = false;
                return;
            }

            if (_currentSelectionFade > 0.05f)
            {
                _queuedReachableCells = new List<GridCell>(reachable);
                _queuedSelectedCoord = selected;

                _hasQueuedSelection = true;
                _hasSelection = false;
                _wantsSelectionClear = true;
            }
            else
            {
                ApplySelection(selected, reachable);
            }
        }

        public void SetSelectedOnly(GridCoord coord)
        {
            if (_currentSelectionFade > 0.05f && _reachableSetActive)
            {
                _queuedSelectedCoord = coord;
                _queuedReachableCells = null;

                _hasQueuedSelection = true;
                _hasSelection = false;
                _wantsSelectionClear = true;
            }
            else
            {
                ApplySelectedOnly(coord);
            }
        }

        private void ApplySelectedOnly(GridCoord coord)
        {
            _hasQueuedSelection = false;
            _wantsSelectionClear = false;

            _selectedCoord = coord;
            _reachableSet.Clear();
            _reachableSetActive = false;
            _hasSelection = true;
            _selectionWithoutReachable = true;

            if (_hasQueuedAttackMode)
                ApplyAttackMode(_queuedAttackMode, _queuedAttackRange);
        }

        private void ApplySelection(GridCoord selected, List<GridCell> reachable)
        {
            _reachableSetActive = true;
            _hasSelection = true;
            _wantsSelectionClear = false;
            _selectionWithoutReachable = false;

            _selectedCoord = selected;
            _reachableSet.Clear();

            foreach (var c in reachable) _reachableSet.Add(c.Coord);
        }

        public void SetHoveredPath(List<GridCell> path)
        {
            if (_hasQueuedSelection)
            {
                _queuedPath = path != null ? new List<GridCell>(path) : null;
                _hasQueuedPath = true;

                _hasPath = false;
                _wantsPathClear = true;
                return;
            }

            ApplyHoveredPath(path);
        }

        private void ApplyHoveredPath(List<GridCell> path)
        {
            _hasQueuedPath = false;
            if (path != null && path.Count > 0)
            {
                _wantsPathClear = false;
                _hasPath = true;
                _currentPath = path;

                _hoveredPathSet.Clear();
                foreach (var c in path) _hoveredPathSet.Add(c.Coord);
            }
            else
            {
                _hasPath = false;
                _wantsPathClear = true;
            }
        }

        public void SetHoveredCoord(GridCoord coord, bool active)
        {
            if (active)
            {
                _targetHoveredPos = new Vector2(coord.X, coord.Z);
                if (!_hasHover)
                    _smoothHoveredPos = _targetHoveredPos;

                _hoveredCoord = coord;
                _wantsHoverClear = false;
            }
            else
            {
                _wantsHoverClear = true;
            }

            _hasHover = active;
        }

        public void SetCoverHoverTarget(GridCell cell)
        {
            _targetCoverHoverCell = cell;
        }

        public void NotifyUnitEnteredCell(GridCoord coord)
        {
            SetGlowSpread(coord, 1.0f);
            if (_unitGlowRadius > 0)
            {
                for (int rx = -_unitGlowRadius; rx <= _unitGlowRadius; rx++)
                    for (int rz = -_unitGlowRadius; rz <= _unitGlowRadius; rz++)
                    {
                        if (rx == 0 && rz == 0) continue;
                        float dist = Mathf.Sqrt(rx * rx + rz * rz);
                        float falloff = 1f - (dist / (_unitGlowRadius + 1f));
                        SetGlowSpread(coord + new GridCoord(rx, rz), Mathf.Max(0.3f, falloff));
                    }
            }
        }

        private void SetGlowSpread(GridCoord coord, float strength)
        {
            if (!_settings.IsValidCoord(coord)) return;
            if (_glowMap.TryGetValue(coord, out float existing))
                _glowMap[coord] = Mathf.Max(existing, strength);
            else
                _glowMap[coord] = strength;
        }

        public void ClearAllState()
        {
            SetSelectedAndReachable(GridCoord.Zero, null);
            SetHoveredPath(null);
            SetHoveredCoord(GridCoord.Zero, false);
            SetCoverHoverTarget(null);
            _hasQueuedSelection = false;
            _selectionWithoutReachable = false;
            _hasQueuedPath = false;
            _queuedPath = null;
        }

        public void SetSelectionVisualsSuppressed(bool suppress)
        {
            _suppressSelectionVisuals = suppress;
        }

        private static CombatGridShaderBridge _instance;
        public static CombatGridShaderBridge Instance
        {
            get
            {
                if (_instance == null) _instance = FindObjectOfType<CombatGridShaderBridge>();
                return _instance;
            }
        }
    }
}