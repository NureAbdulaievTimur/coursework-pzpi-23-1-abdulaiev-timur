using UnityEngine;
using UnityEngine.UI;

[ExecuteAlways]
[RequireComponent(typeof(Image))]
public class SciFiButtonHelper : MonoBehaviour
{
    private Image img;
    private RectTransform rect;

    void Update()
    {
        if (img == null) img = GetComponent<Image>();
        if (rect == null) rect = GetComponent<RectTransform>();

        if (img.material != null)
        {
            float aspect = rect.rect.width / rect.rect.height;

            img.materialForRendering.SetFloat("_AspectRatio", aspect);
        }
    }
}