using UnityEngine;

public class RagdollManager : MonoBehaviour
{
    [Header("Settings")]
    public bool useRagdollOnDeath = true;

    [Header("References")]
    [SerializeField] private Animator animator;

    private Rigidbody[] _allRigidbodies;
    private Collider[] _allColliders;

    private void Awake()
    {
        if (animator == null) animator = GetComponentInChildren<Animator>();

        _allRigidbodies = GetComponentsInChildren<Rigidbody>();
        _allColliders = GetComponentsInChildren<Collider>();

        ToggleRagdoll(false);
    }

    public void ToggleRagdoll(bool isRagdoll)
    {
        if (animator != null) animator.enabled = !isRagdoll;

        foreach (var rb in _allRigidbodies)
        {
            rb.isKinematic = !isRagdoll;
            if (isRagdoll) rb.interpolation = RigidbodyInterpolation.Interpolate;
        }

        foreach (var col in _allColliders)
        {
            col.enabled = true;
        }
    }

    public void TriggerDeath(Vector3 force, Vector3 hitPoint, Rigidbody hitPart)
    {
        ToggleRagdoll(true);

        if (hitPart != null)
        {
            hitPart.AddForceAtPosition(force, hitPoint, ForceMode.Impulse);
        }
        else if (_allRigidbodies.Length > 0)
        {
            _allRigidbodies[0].AddForce(force, ForceMode.Impulse);
        }
    }
}