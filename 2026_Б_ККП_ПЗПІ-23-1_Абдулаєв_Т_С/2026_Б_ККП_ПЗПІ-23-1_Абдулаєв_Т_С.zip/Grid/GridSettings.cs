using UnityEngine;

namespace CombatGrid
{
    [CreateAssetMenu(fileName = "GridSettings", menuName = "CombatGrid/Grid Settings")]
    public class GridSettings : ScriptableObject
    {
        [Header("Dimensions")]
        [Tooltip("Number of columns (X axis).")]
        [Min(1)] public int Width = 20;

        [Tooltip("Number of rows (Z axis).")]
        [Min(1)] public int Height = 20;

        [Tooltip("World-space size of each cell (the cell is a square: cellSize x cellSize).")]
        [Min(0.1f)] public float CellSize = 1f;

        [Header("Origin")]
        [Tooltip("World position of the bottom-left corner of the grid (cell 0,0).")]
        public Vector3 OriginPosition = Vector3.zero;

        [Tooltip("Y-offset applied to all cell world positions (useful if grid sits on terrain).")]
        public float CellHeightOffset = 0f;

        [Header("Movement Costs")]
        [Tooltip("Action-point cost for a straight (cardinal) move.")]
        [Min(1)] public int StraightMoveCost = 1;

        [Tooltip("Action-point cost for a diagonal move.")]
        [Min(1)] public int DiagonalMoveCost = 2;

        [Header("Pathfinding")]
        [Tooltip("Allow units to move diagonally.")]
        public bool AllowDiagonalMovement = true;

        [Tooltip("Diagonal moves are blocked if both adjacent cardinal cells are unwalkable (prevents corner-cutting).")]
        public bool BlockDiagonalCornering = true;

        [Header("Visualization")]
        public Color GridLineColor = new Color(1f, 1f, 1f, 0.2f);
        public Color WalkableColor = new Color(0f, 1f, 0f, 0.15f);
        public Color UnwalkableColor = new Color(1f, 0f, 0f, 0.3f);
        public Color ReachableHighlight = new Color(0f, 0.6f, 1f, 0.35f);
        public Color PathHighlight = new Color(1f, 0.85f, 0f, 0.5f);
        public Color SelectedCellColor = new Color(1f, 1f, 0f, 0.6f);
        public Color OccupiedColor = new Color(1f, 0.4f, 0f, 0.4f);

        [Tooltip("Show grid in Edit Mode via OnDrawGizmos.")]
        public bool ShowGridGizmos = true;
        public int TotalCells => Width * Height;

        public bool IsValidCoord(GridCoord coord)
            => coord.X >= 0 && coord.X < Width && coord.Z >= 0 && coord.Z < Height;

        public Vector3 CoordToWorld(GridCoord coord)
            => OriginPosition
               + new Vector3(coord.X * CellSize + CellSize * 0.5f,
                             CellHeightOffset,
                             coord.Z * CellSize + CellSize * 0.5f);

        public GridCoord WorldToCoord(Vector3 worldPos)
        {
            Vector3 local = worldPos - OriginPosition;
            int x = Mathf.FloorToInt(local.x / CellSize);
            int z = Mathf.FloorToInt(local.z / CellSize);
            return new GridCoord(x, z);
        }
    }
}