using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CombatGrid
{
    [Serializable]
    public struct CalloutSegment
    {
        [Tooltip("Length of the line segment in Canvas pixels.")]
        public float length;
        [Tooltip("Angle in degrees. 0 = right, 90 = up.")]
        public float angleDeg;
    }

    public class CrosshairWorldUI : MonoBehaviour
    {
        public static CrosshairWorldUI Instance { get; private set; }

        [Header("Scene References")]
        [SerializeField] private Camera _cam;
        [SerializeField] private Canvas _canvas;
        [SerializeField] private CanvasGroup _canvasGroup;

        [Header("Crosshair")]
        [SerializeField] private RawImage _crosshairImage;
        [SerializeField] private TextMeshProUGUI _hitChanceLabel;
        [SerializeField] private Vector3 _crosshairWorldOffset = new Vector3(0f, 0.9f, 0f);
        [SerializeField] private float _crosshairSize = 80f;

        [Header("Hit Chance Label")]
        [SerializeField] private Color _hitChanceColor = new Color(1f, 0.60f, 0.08f, 1f);
        [SerializeField] private float _hitChanceFontSize = 13f;

        [Header("Unified Callout Shape")]
        [Tooltip("A single RawImage using the SciFiCalloutUnified material.")]
        [SerializeField] private RawImage _calloutImage;

        [Tooltip("Offset of the dot's centre from the crosshair centre.")]
        [SerializeField] private Vector2 _dotOffset = new Vector2(40f, 0f);

        [Tooltip("Radius of the outer ring (pixels). Matches perfectly with shader calculations.")]
        [SerializeField] private float _ringRadius = 14f;

        [Tooltip("Thickness of the lines and ring (pixels).")]
        [SerializeField] private float _lineThickness = 2.5f;

        [Tooltip("Padding added to the bounds to make room for glow (pixels).")]
        [SerializeField] private float _glowPadding = 40f;

        [Header("Callout Segments (Max 4)")]
        [SerializeField]
        private CalloutSegment[] _segments = new CalloutSegment[]
        {
            new CalloutSegment { length = 15f, angleDeg = 0f },
            new CalloutSegment { length = 52f, angleDeg = 40f },
            new CalloutSegment { length = 90f, angleDeg = 0f }
        };

        [Tooltip("How many pixels at the tail end of the last line should fade out?")]
        [SerializeField] private float _fadeTailLength = 30f;

        [Header("Callout Label")]
        [SerializeField] private TextMeshProUGUI _calloutLabel;
        [SerializeField] private string _labelPrefix = "EST. DMG  ";
        [SerializeField] private Color _calloutLabelColor = new Color(1f, 0.60f, 0.08f, 1f);
        [SerializeField] private float _calloutLabelFontSize = 13f;
        [SerializeField] private Vector2 _labelOffset = new Vector2(3f, 6f);

        [Header("Fade Speeds")]
        [SerializeField] private float _fadeInSpeed = 12f;
        [SerializeField] private float _fadeOutSpeed = 10f;

        private Unit _trackedUnit;
        private float _alphaCurrent = 0f;
        private float _alphaTarget = 0f;
        private Material _crosshairMat;
        private Material _calloutMat;
        private GlitchTextEffect _calloutGlitch;
        private string _lastCalloutText = "";
        private bool _wasHidden = true;

        private static readonly int ID_ShaderAlpha = Shader.PropertyToID("_Alpha");
        private static readonly int ID_HitChance = Shader.PropertyToID("_HitChance");

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;

            if (_cam == null) _cam = Camera.main;
            if (_canvas == null) _canvas = GetComponentInParent<Canvas>();

            _crosshairMat = CloneMat(_crosshairImage);
            _calloutMat = CloneMat(_calloutImage);

            if (_calloutMat != null)
            {
                _calloutMat.SetFloat("_RingRadius", _ringRadius);
                _calloutMat.SetFloat("_Thickness", _lineThickness);
                _calloutMat.SetFloat("_FadeTailLen", _fadeTailLength);
            }

            BootLabels();
            SetElementsActive(false);
            if (_canvasGroup != null) _canvasGroup.alpha = 0f;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
            if (_crosshairMat != null) Destroy(_crosshairMat);
            if (_calloutMat != null) Destroy(_calloutMat);
        }

        private void LateUpdate()
        {
            float speed = (_alphaTarget > _alphaCurrent) ? _fadeInSpeed : _fadeOutSpeed;
            _alphaCurrent = Mathf.MoveTowards(_alphaCurrent, _alphaTarget, Time.deltaTime * speed);

            bool visible = _alphaCurrent > 0.005f;
            if (_canvasGroup != null) _canvasGroup.alpha = _alphaCurrent;

            if (_crosshairMat != null) _crosshairMat.SetFloat(ID_ShaderAlpha, _alphaCurrent);
            if (_calloutMat != null) _calloutMat.SetFloat(ID_ShaderAlpha, _alphaCurrent);

            SetElementsActive(visible);

            if (visible && _trackedUnit != null)
                PositionAll();

            _calloutGlitch?.SetEffectAlpha(_alphaCurrent);

            if (!visible && _alphaTarget == 0f)
                _trackedUnit = null;
        }

        public void Show(Unit unit, float hitChance, int minDmg, int maxDmg)
        {
            _trackedUnit = unit;

            if (_crosshairMat != null) _crosshairMat.SetFloat(ID_HitChance, hitChance);
            if (_hitChanceLabel != null) _hitChanceLabel.SetText($"{Mathf.RoundToInt(hitChance * 100)}%");

            string dmgStr = (minDmg == maxDmg) ? minDmg.ToString() : $"{minDmg}-{maxDmg}";
            string newText = _labelPrefix + dmgStr;

            if (newText != _lastCalloutText)
            {
                _lastCalloutText = newText;
                if (_calloutGlitch != null) _calloutGlitch.UpdateValue(newText);
                else if (_calloutLabel != null) _calloutLabel.SetText(newText);
            }

            if (_wasHidden)
            {
                _calloutGlitch?.ResetSweepTimer();
                _calloutGlitch?.GlitchIn();
            }
            _wasHidden = false;
            _alphaTarget = 1f;
        }

        public void Hide()
        {
            if (_alphaTarget == 0f) return;
            _alphaTarget = 0f;
            _wasHidden = true;
            _calloutGlitch?.GlitchOut();
            _lastCalloutText = "";
        }

        private void BootLabels()
        {
            if (_hitChanceLabel != null)
            {
                _hitChanceLabel.fontSize = _hitChanceFontSize;
                _hitChanceLabel.alignment = TextAlignmentOptions.Center;
                _hitChanceLabel.color = _hitChanceColor;
                _hitChanceLabel.text = "";
            }

            if (_calloutLabel != null)
            {
                _calloutLabel.fontSize = _calloutLabelFontSize;
                _calloutLabel.alignment = TextAlignmentOptions.Left;
                _calloutLabel.color = _calloutLabelColor;
                _calloutLabel.text = "";

                _calloutGlitch = _calloutLabel.GetComponent<GlitchTextEffect>();
                if (_calloutGlitch != null)
                {
                    _calloutGlitch.SetScrambleOnChange(false);
                    _calloutGlitch.Initialize(startVisible: false);
                    _calloutGlitch.SetThemeColor(_calloutLabelColor);
                }
            }
        }

        private void SetElementsActive(bool active)
        {
            if (_crosshairImage != null) _crosshairImage.enabled = active;
            if (_calloutImage != null) _calloutImage.enabled = active;
        }

        private void PositionAll()
        {
            if (_cam == null || _canvas == null) return;

            Vector3 worldPos = _trackedUnit.transform.position + _crosshairWorldOffset;
            Vector3 screenPos = _cam.WorldToScreenPoint(worldPos);
            if (screenPos.z < 0f) return;

            Camera uiCam = (_canvas.renderMode != RenderMode.ScreenSpaceOverlay) ? _canvas.worldCamera : null;
            if (!RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    (RectTransform)transform, screenPos, uiCam, out Vector2 crosshairPos)) return;

            if (_crosshairImage != null)
            {
                var rt = (RectTransform)_crosshairImage.transform;
                rt.anchoredPosition = crosshairPos;
                rt.sizeDelta = new Vector2(_crosshairSize, _crosshairSize);
            }
            if (_hitChanceLabel != null)
                ((RectTransform)_hitChanceLabel.transform).anchoredPosition = crosshairPos;

            int count = Mathf.Min(_segments.Length, 4);
            Vector2[] pts = new Vector2[count + 1];

            pts[0] = Vector2.zero;

            if (count > 0)
                pts[0] = AngleToDir(_segments[0].angleDeg) * _ringRadius;

            float totalLength = 0f;
            for (int i = 0; i < count; i++)
            {
                Vector2 dir = AngleToDir(_segments[i].angleDeg);
                pts[i + 1] = pts[i] + dir * _segments[i].length;
                totalLength += _segments[i].length;
            }

            Vector2 min = Vector2.zero;
            Vector2 max = Vector2.zero;
            foreach (var p in pts)
            {
                min.x = Mathf.Min(min.x, p.x); min.y = Mathf.Min(min.y, p.y);
                max.x = Mathf.Max(max.x, p.x); max.y = Mathf.Max(max.y, p.y);
            }

            min -= new Vector2(_glowPadding, _glowPadding);
            max += new Vector2(_glowPadding, _glowPadding);

            Vector2 dotPos = crosshairPos + _dotOffset;

            if (_calloutImage != null && _calloutMat != null)
            {
                var rt = (RectTransform)_calloutImage.transform;

                Vector2 centerOffset = (min + max) * 0.5f;
                rt.anchoredPosition = dotPos + centerOffset;
                rt.sizeDelta = max - min;

                _calloutMat.SetVector("_BoundsMin", min);
                _calloutMat.SetVector("_BoundsMax", max);
                _calloutMat.SetFloat("_SegCount", count);
                _calloutMat.SetFloat("_TotalLength", totalLength);

                for (int i = 0; i < pts.Length; i++)
                    _calloutMat.SetVector($"_P{i}", pts[i]);
            }

            if (_calloutLabel != null)
            {
                Vector2 finalPos = dotPos + pts[count];
                ((RectTransform)_calloutLabel.transform).anchoredPosition = finalPos + _labelOffset;
            }
        }

        private static Vector2 AngleToDir(float degrees)
        {
            float r = degrees * Mathf.Deg2Rad;
            return new Vector2(Mathf.Cos(r), Mathf.Sin(r));
        }

        private static Material CloneMat(RawImage img)
        {
            if (img == null || img.material == null) return null;
            var m = new Material(img.material);
            img.material = m;
            return m;
        }
    }
}