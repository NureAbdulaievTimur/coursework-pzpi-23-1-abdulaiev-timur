using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "SurfaceEffectConfig", menuName = "Combat/Surface Effect Config")]
public class SurfaceEffectConfig : ScriptableObject
{
    [System.Serializable]
    public class SurfaceEffectEntry
    {
        public SurfaceType surfaceType;
        [Tooltip("If false, the bullet stops here. No exit wound calculations will run.")]
        public bool isPenetrable = true;
        [Header("Entry Effects")]
        public GameObject entryImpactParticles;
        public GameObject entryHolePrefab;

        [Header("Exit Effects")]
        public GameObject exitImpactParticles;
        public GameObject exitHolePrefab;
    }

    [SerializeField] private List<SurfaceEffectEntry> effects = new List<SurfaceEffectEntry>();

    public SurfaceEffectEntry GetEffect(SurfaceType type)
    {
        var entry = effects.Find(x => x.surfaceType == type);
        if (entry == null) entry = effects.Find(x => x.surfaceType == SurfaceType.Default);
        return entry;
    }
}