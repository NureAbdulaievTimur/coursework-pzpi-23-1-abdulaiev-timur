using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    public class GridObstacle : MonoBehaviour
    {
        [Header("Footprint")]
        [Tooltip("Footprint width in grid cells (X axis).")]
        [SerializeField, Min(1)] protected int _footprintWidth = 1;

        [Tooltip("Footprint depth in grid cells (Z axis).")]
        [SerializeField, Min(1)] protected int _footprintHeight = 1;

        [Tooltip("Where on the footprint the object's pivot sits.")]
        [SerializeField] private PivotAlignment _pivot = PivotAlignment.Centre;

        [Header("Snapping")]
        [Tooltip("Snap position to grid on Start.")]
        [SerializeField] private bool _snapOnStart = true;

        [Tooltip("Offset applied after snapping (useful for centring a wide mesh).")]
        [SerializeField] private Vector3 _snapOffset = Vector3.zero;

        public GridCoord PivotCoord { get; private set; }

        public IReadOnlyList<GridCoord> OccupiedCoords => _occupiedCoords;

        private readonly List<GridCoord> _occupiedCoords = new();
        private bool _registered;

        protected virtual void Start()
        {
            if (GridManager.Instance == null)
            {
                Debug.LogError($"[GridObstacle] {name}: No GridManager found in scene.", this);
                return;
            }

            if (_snapOnStart) SnapToGrid();
            Register();
        }

        protected virtual void OnDestroy()
        {
            Unregister();
        }

        public void SnapToGrid()
        {
            if (GridManager.Instance == null) return;

            GridSettings s = GridManager.Instance.Settings;
            PivotCoord = s.WorldToCoord(transform.position);
            PivotCoord = ClampCoord(PivotCoord, s);

            Vector3 snapped = s.CoordToWorld(PivotCoord) + _snapOffset;
            snapped.y = transform.position.y; 
            transform.position = snapped;
        }

        private void Register()
        {
            if (_registered || GridManager.Instance == null) return;

            _occupiedCoords.Clear();
            BuildFootprint();

            GridManager.Instance.RegisterObstruction(_occupiedCoords);
            _registered = true;
        }

        private void Unregister()
        {
            if (!_registered || GridManager.Instance == null) return;
            GridManager.Instance.UnregisterObstruction(_occupiedCoords);
            _occupiedCoords.Clear();
            _registered = false;
        }

        private void BuildFootprint()
        {
            GridSettings s = GridManager.Instance.Settings;

            int offsetX = PivotOffset(_footprintWidth, _pivot, axis: 0);
            int offsetZ = PivotOffset(_footprintHeight, _pivot, axis: 1);

            for (int x = 0; x < _footprintWidth; x++)
                for (int z = 0; z < _footprintHeight; z++)
                {
                    var coord = new GridCoord(
                        PivotCoord.X + x + offsetX,
                        PivotCoord.Z + z + offsetZ);

                    if (s.IsValidCoord(coord))
                        _occupiedCoords.Add(coord);
                }
        }

        private static int PivotOffset(int size, PivotAlignment pivot, int axis)
        {
            return pivot switch
            {
                PivotAlignment.BottomLeft => 0,
                PivotAlignment.BottomRight => axis == 0 ? -(size - 1) : 0,
                PivotAlignment.TopLeft => axis == 1 ? -(size - 1) : 0,
                PivotAlignment.TopRight => -(size - 1),
                PivotAlignment.Centre => -(size / 2),
                _ => 0
            };
        }

        private static GridCoord ClampCoord(GridCoord c, GridSettings s)
            => new(Mathf.Clamp(c.X, 0, s.Width - 1),
                   Mathf.Clamp(c.Z, 0, s.Height - 1));

        public void MoveToCoord(GridCoord newPivotCoord)
        {
            Unregister();
            PivotCoord = ClampCoord(newPivotCoord, GridManager.Instance.Settings);
            transform.position = GridManager.Instance.CoordToWorld(PivotCoord) + _snapOffset;
            Register();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (!Application.isPlaying && GridManager.Instance != null)
                SnapToGrid();
        }

        private void OnDrawGizmosSelected()
        {
            if (GridManager.Instance == null) return;
            GridSettings s = GridManager.Instance.Settings;

            int offX = PivotOffset(_footprintWidth, _pivot, 0);
            int offZ = PivotOffset(_footprintHeight, _pivot, 1);
            GridCoord snapCoord = s.WorldToCoord(transform.position);

            for (int x = 0; x < _footprintWidth; x++)
                for (int z = 0; z < _footprintHeight; z++)
                {
                    var coord = new GridCoord(snapCoord.X + x + offX, snapCoord.Z + z + offZ);
                    if (!s.IsValidCoord(coord)) continue;
                    Vector3 center = s.CoordToWorld(coord);
                    Gizmos.color = new Color(1f, 0.4f, 0f, 0.4f);
                    Gizmos.DrawCube(center, new Vector3(s.CellSize * 0.9f, 0.05f, s.CellSize * 0.9f));
                    Gizmos.color = new Color(1f, 0.6f, 0.1f, 0.9f);
                    Gizmos.DrawWireCube(center, new Vector3(s.CellSize, 0.06f, s.CellSize));
                }
        }
#endif
    }

    public enum PivotAlignment
    {
        Centre,
        BottomLeft,
        BottomRight,
        TopLeft,
        TopRight
    }
}