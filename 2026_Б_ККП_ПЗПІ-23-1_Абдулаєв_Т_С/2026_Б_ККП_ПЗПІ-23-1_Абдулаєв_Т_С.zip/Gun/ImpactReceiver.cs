using UnityEngine;

public class ImpactReceiver : MonoBehaviour
{
    public enum TransferMode { Standard, CopyLocalResult }

    [Header("Reaction Settings")]
    [Tooltip("How much the bone moves backwards when hit.")]
    [SerializeField] private float positionStrength = 0.05f;
    [Tooltip("How much the bone rotates/snaps back when hit.")]
    [SerializeField] private float rotationStrength = 15.0f;
    [Tooltip("How fast the limb returns to normal.")]
    [SerializeField] private float recoverySpeed = 10f;

    [Header("Direction Settings")]
    [Tooltip("If TRUE, bone moves and rotates AWAY from bullet direction. If FALSE, bone moves and rotates WITH bullet direction.")]
    [SerializeField] private bool invertDirection = true;

    [Header("Impact Transfer")]
    [SerializeField] private bool transferImpact = false;
    [SerializeField] private ImpactReceiver targetReceiver;

    [Tooltip("Standard: Trigger the target using Target's settings.\nCopyLocalResult: Calculate using THIS bone's settings, then force that result onto the target.")]
    [SerializeField] private TransferMode transferMode = TransferMode.Standard;

    [Tooltip("1.0 = Same Force. -1.0 = Inverse Direction.")]
    [SerializeField] private float transferMultiplier = 1.0f;

    [Tooltip("If true, THIS bone will not move, but it will still send the calculated movement to the target.")]
    [SerializeField] private bool absorbImpactLocally = false;

    private Vector3 _currentPosOffset;
    private Vector3 _targetPosOffset;

    private Vector3 _currentRotAxis;
    private float _currentRotMag;
    private float _targetRotMag;

    private void LateUpdate()
    {
        _targetPosOffset = Vector3.Lerp(_targetPosOffset, Vector3.zero, Time.deltaTime * recoverySpeed);
        _targetRotMag = Mathf.Lerp(_targetRotMag, 0f, Time.deltaTime * recoverySpeed);

        _currentPosOffset = Vector3.Lerp(_currentPosOffset, _targetPosOffset, Time.deltaTime * 25f);
        _currentRotMag = Mathf.Lerp(_currentRotMag, _targetRotMag, Time.deltaTime * 25f);

        if (_currentPosOffset.sqrMagnitude > 0.00001f || Mathf.Abs(_currentRotMag) > 0.01f)
        {
            transform.position += _currentPosOffset;

            if (_currentRotAxis.sqrMagnitude > 0.1f)
            {
                transform.rotation = Quaternion.AngleAxis(_currentRotMag, _currentRotAxis) * transform.rotation;
            }
        }
    }

    public void AddImpact(Vector3 bulletDirection, float force)
    {
        CalculateReaction(bulletDirection, force, out Vector3 calcPos, out float calcRotMag, out Vector3 calcRotAxis);

        if (!absorbImpactLocally)
        {
            _targetPosOffset += calcPos;
            _currentRotAxis = calcRotAxis;
            _targetRotMag += calcRotMag;
        }

        if (transferImpact && targetReceiver != null)
        {
            if (transferMode == TransferMode.Standard)
            {
                targetReceiver.AddImpact(bulletDirection, force * transferMultiplier);
            }
            else if (transferMode == TransferMode.CopyLocalResult)
            {
                targetReceiver.ApplyDirectImpact(calcPos * transferMultiplier, calcRotMag * transferMultiplier, calcRotAxis);
            }
        }
    }

    private void CalculateReaction(Vector3 bulletDir, float force, out Vector3 posOffset, out float rotMag, out Vector3 rotAxis)
    {
        bulletDir.Normalize();

        float pushFactor = Mathf.Clamp(force * 0.01f, 0.5f, 2.0f);

        float dirMod = invertDirection ? 1f : -1f;

        posOffset = bulletDir * (positionStrength * pushFactor * dirMod);

        Vector3 primaryAxis = transform.up;
        rotAxis = Vector3.Cross(bulletDir, primaryAxis).normalized;

        if (rotAxis.sqrMagnitude < 0.1f)
        {
            primaryAxis = transform.forward;
            rotAxis = Vector3.Cross(bulletDir, primaryAxis).normalized;
        }

        rotMag = (rotationStrength * pushFactor * dirMod) * UnityEngine.Random.Range(0.8f, 1.2f);
    }

    public void ApplyDirectImpact(Vector3 posOffset, float rotMag, Vector3 rotAxis)
    {
        _targetPosOffset += posOffset;
        _currentRotAxis = rotAxis;
        _targetRotMag += rotMag;
    }
}