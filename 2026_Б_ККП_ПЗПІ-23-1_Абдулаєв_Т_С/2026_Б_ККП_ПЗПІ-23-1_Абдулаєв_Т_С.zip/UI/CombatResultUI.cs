using System.Collections;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace CombatGrid
{
    public class CombatResultUI : MonoBehaviour
    {
        [SerializeField] private CanvasGroup _uiCanvasGroup;
        [SerializeField] private TextMeshProUGUI _resultText;
        [SerializeField] private RawImage _borderGlowImage;

        [SerializeField] private float _fadeInDuration = 1.0f;
        [SerializeField] private float _displayDuration = 3.5f;

        [Header("Vignette Shape")]
        [Tooltip("0 = vignette starts at center, 1 = vignette only at corners")]
        [Range(0f, 1f)][SerializeField] private float _vignetteInnerRadius = 0.55f;

        [Tooltip("Higher = sharper edge between transparent and opaque")]
        [Range(0.5f, 8f)][SerializeField] private float _vignetteFalloffPower = 2f;

        [ColorUsage(true, true)] public Color VictoryColor = new Color(0.04f, 1.0f, 0.18f, 1f);
        [ColorUsage(true, true)] public Color DefeatColor = new Color(1.0f, 0.07f, 0.02f, 1f);
        [ColorUsage(true, true)] public Color DrawColor = new Color(1.0f, 0.9f, 0.0f, 1f);

        private Texture2D _vignetteTexture;

        private void Start()
        {
            if (_uiCanvasGroup != null)
            {
                _uiCanvasGroup.alpha = 0f;
                _uiCanvasGroup.interactable = false;
                _uiCanvasGroup.blocksRaycasts = false;
            }

            GenerateVignetteTexture();

            if (TurnManager.Instance != null)
                TurnManager.Instance.OnCombatEnded += HandleCombatEnded;
        }

        private void OnDestroy()
        {
            if (TurnManager.Instance != null)
                TurnManager.Instance.OnCombatEnded -= HandleCombatEnded;

            if (_vignetteTexture != null)
                Destroy(_vignetteTexture);
        }

        private void OnValidate()
        {
            if (_borderGlowImage != null)
                GenerateVignetteTexture();
        }

        private void HandleCombatEnded(UnitTeam? winner)
        {
            StartCoroutine(ShowResultSequence(winner));
        }

        private IEnumerator ShowResultSequence(UnitTeam? winner)
        {
            bool isVictory = winner.HasValue && winner.Value == UnitTeam.Player;
            bool isDraw = !winner.HasValue;

            if (isDraw)
            {
                _resultText.text = "DRAW!";
                _resultText.color = DrawColor;
            }
            else
            {
                _resultText.text = isVictory ? "YOU WON!" : "YOU LOST!";
                _resultText.color = isVictory ? VictoryColor : DefeatColor;
            }

            Color glowBaseColor = isDraw ? DrawColor : (isVictory ? VictoryColor : DefeatColor);
            _borderGlowImage.color = new Color(glowBaseColor.r, glowBaseColor.g, glowBaseColor.b, 0f);

            _uiCanvasGroup.interactable = true;
            _uiCanvasGroup.blocksRaycasts = true;

            float maxBorderAlpha = 0.5f;
            float elapsed = 0f;

            while (elapsed < _fadeInDuration)
            {
                elapsed += Time.unscaledDeltaTime;
                float t = elapsed / _fadeInDuration;

                _uiCanvasGroup.alpha = t;
                _borderGlowImage.color = new Color(glowBaseColor.r, glowBaseColor.g, glowBaseColor.b, t * maxBorderAlpha);

                yield return null;
            }

            _uiCanvasGroup.alpha = 1f;

            elapsed = 0f;
            float pulseSpeed = 2f;
            float pulseAmplitude = 0.2f;
            float basePulseAlpha = maxBorderAlpha - pulseAmplitude;

            while (elapsed < _displayDuration)
            {
                elapsed += Time.unscaledDeltaTime;

                float breath = basePulseAlpha + (pulseAmplitude * Mathf.Cos(elapsed * pulseSpeed));
                _borderGlowImage.color = new Color(glowBaseColor.r, glowBaseColor.g, glowBaseColor.b, breath);

                yield return null;
            }

            if (SceneTransitionManager.Instance != null)
                SceneTransitionManager.Instance.RestartCurrentScene();
        }

        private void GenerateVignetteTexture()
        {
            if (_borderGlowImage == null) return;

            const int size = 256;

            if (_vignetteTexture == null)
            {
                _vignetteTexture = new Texture2D(size, size, TextureFormat.RGBA32, false);
                _vignetteTexture.wrapMode = TextureWrapMode.Clamp;
            }

            for (int y = 0; y < size; y++)
            {
                for (int x = 0; x < size; x++)
                {
                    float u = (x / (float)(size - 1)) * 2f - 1f;
                    float v = (y / (float)(size - 1)) * 2f - 1f;

                    float dist = Mathf.Sqrt(u * u + v * v) / 1.41421356f;

                    float alpha = Mathf.SmoothStep(_vignetteInnerRadius, 1f, dist);
                    alpha = Mathf.Pow(alpha, _vignetteFalloffPower);

                    _vignetteTexture.SetPixel(x, y, new Color(1f, 1f, 1f, alpha));
                }
            }

            _vignetteTexture.Apply();
            _borderGlowImage.texture = _vignetteTexture;
        }
    }
}