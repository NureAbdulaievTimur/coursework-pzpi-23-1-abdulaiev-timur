using UnityEngine;
using Unity.Cinemachine;

namespace CombatGrid
{
    public class IsometricCameraController : MonoBehaviour
    {
        [Header("References")]
        public Transform cameraTarget;
        public CinemachineCamera cinemachineCamera;

        [Header("Pan (WASD)")]
        public float panSpeed = 10f;
        public bool clampPosition = false;
        public Vector2 clampXRange = new Vector2(-50f, 50f);
        public Vector2 clampZRange = new Vector2(-50f, 50f);

        [Header("Zoom (Scroll Wheel)")]
        public float zoomStep = 8f;
        public float zoomSmoothTime = 0.12f;
        public float minDistance = 5f;
        public float maxDistance = 120f;

        [Header("Snap Rotation (Q = CCW, E = CW)")]
        public float rotationDuration = 0.25f;

        [Header("Combat Focus (QTE)")]
        public float focusSmoothTime = 0.3f;
        public float focusPaddingMultiplier = 2.5f;
        public float focusMinDistance = 30f;

        [Header("Unit Follow")]
        public float followSmoothTime = 0.4f;

        private bool _isFollowing = false;
        private Transform _followTarget;
        private Vector3 _followVelocity;

        [Header("Player Turn Centering")]
        public UnitTeam playerTeam = UnitTeam.Player;
        public float centeringSmoothTime = 0.5f;
        public float centeringStopThreshold = 0.05f;

        private bool _isCentering = false;
        private Vector3 _centeringTarget;
        private Vector3 _centeringVelocity;

        private CinemachinePositionComposer _composer;

        private float _currentYaw = 45f;
        private float _targetYaw = 45f;
        private float _rotationStart = 45f;
        private float _rotationTimer = 1f;

        private float _targetDistance;
        private float _zoomVelocity;
        private Vector3 _focusVelocity;

        private bool _isFocusing = false;
        private Vector3 _targetFocusPos;
        private float _targetFocusDistance;

        private EnemyAI[] _enemyAIs;

        private void Awake()
        {
            if (cameraTarget == null || cinemachineCamera == null) return;

            _composer = cinemachineCamera.GetComponent<CinemachinePositionComposer>();
            _currentYaw = _targetYaw = _rotationStart = cameraTarget.eulerAngles.y;
            _targetDistance = _composer.CameraDistance;
            _targetFocusDistance = _targetDistance;
        }

        private void Start()
        {
            if (TurnManager.Instance != null)
                TurnManager.Instance.OnPhaseStarted += OnPhaseStarted;
            else
                Debug.LogError("[IsometricCameraController] TurnManager instance not found in Start!");
        }

        private void OnEnable()
        {
            _enemyAIs = FindObjectsOfType<EnemyAI>();
            foreach (var ai in _enemyAIs)
            {
                ai.OnUnitTurnStarted += OnUnitTurnStarted;
                ai.OnUnitTurnEnded += OnUnitTurnEnded;
                ai.OnActionExecuted += OnActionExecuted;
            }
        }

        private void OnDisable()
        {
            if (_enemyAIs != null)
            {
                foreach (var ai in _enemyAIs)
                {
                    if (ai == null) continue;
                    ai.OnUnitTurnStarted -= OnUnitTurnStarted;
                    ai.OnUnitTurnEnded -= OnUnitTurnEnded;
                    ai.OnActionExecuted -= OnActionExecuted;
                }
            }

            if (TurnManager.Instance != null)
                TurnManager.Instance.OnPhaseStarted -= OnPhaseStarted;
        }

        private void OnUnitTurnStarted(Unit unit, int round)
        {
            if (unit != null && unit.IsAlive)
                SetFollowTarget(unit.transform);
        }

        private void OnUnitTurnEnded(Unit unit, int round)
        {
            if (_followTarget == unit.transform)
                ClearFollowTarget();
        }

        private void OnActionExecuted(CombatAction action, Unit unit)
        {
            if (_followTarget != unit.transform) return;

            if (!unit.CanAct && !unit.CanMove)
                ClearFollowTarget();
        }

        private void OnPhaseStarted(UnitTeam team, int round)
        {
            if (team != playerTeam) return;

            if (_isFocusing)
            {
                _isFocusing = false;
                _targetDistance = _targetFocusDistance;
            }

            var units = TurnManager.Instance.GetUnits(playerTeam);
            foreach (var u in units)
            {
                if (u != null && u.IsAlive)
                {
                    _centeringTarget = u.transform.position;
                    _centeringTarget.y = cameraTarget.position.y;
                    _centeringVelocity = Vector3.zero;
                    _isCentering = true;
                    break;
                }
            }
        }

        private void Update()
        {
            if (cameraTarget == null || _composer == null) return;

            HandleRotation();

            if (_isFocusing)
            {
                HandleCombatFocus();
            }
            else
            {
                float h = Input.GetAxisRaw("Horizontal");
                float v = Input.GetAxisRaw("Vertical");

                if (h != 0f || v != 0f)
                {
                    if (_isFollowing) ClearFollowTarget();
                    if (_isCentering) _isCentering = false;
                }

                if (_isCentering)
                    HandleCentering();
                else if (_isFollowing)
                    HandleUnitFollow();
                else
                    HandlePan(h, v);

                HandleZoom();
            }
        }

        public void SetFocus(Vector3 posA, Vector3 posB)
        {
            _isFocusing = true;

            Vector3 mid = (posA + posB) / 2f;

            Camera cam = Camera.main;
            if (cam != null)
            {
                float viewportYA = cam.WorldToViewportPoint(posA).y;
                float viewportYB = cam.WorldToViewportPoint(posB).y;

                Vector3 lowerPos = viewportYA < viewportYB ? posA : posB;
                mid = Vector3.Lerp(mid, lowerPos, 0.15f);
            }

            _targetFocusPos = mid;

            float distBetweenUnits = Vector3.Distance(posA, posB);
            float requiredZoomOut = distBetweenUnits * focusPaddingMultiplier;
            requiredZoomOut = Mathf.Max(requiredZoomOut, focusMinDistance);

            if (_composer.CameraDistance < requiredZoomOut)
                _targetFocusDistance = Mathf.Clamp(requiredZoomOut, minDistance, maxDistance);
            else
                _targetFocusDistance = _composer.CameraDistance;
        }

        public void ClearFocus()
        {
            _isFocusing = false;
            _targetDistance = _targetFocusDistance;

            if (_followTarget != null)
            {
                Unit followUnit = _followTarget.GetComponent<Unit>();
                if (followUnit != null && !followUnit.CanAct && !followUnit.CanMove)
                {
                    ClearFollowTarget();
                }
            }
        }

        private void HandleCombatFocus()
        {
            cameraTarget.position = Vector3.SmoothDamp(
                cameraTarget.position, _targetFocusPos, ref _focusVelocity, focusSmoothTime);

            _composer.CameraDistance = Mathf.SmoothDamp(
                _composer.CameraDistance, _targetFocusDistance, ref _zoomVelocity, focusSmoothTime);
        }

        private void HandleCentering()
        {
            cameraTarget.position = Vector3.SmoothDamp(
                cameraTarget.position, _centeringTarget,
                ref _centeringVelocity, centeringSmoothTime);

            if (Vector3.Distance(cameraTarget.position, _centeringTarget) < centeringStopThreshold)
            {
                cameraTarget.position = _centeringTarget;
                _isCentering = false;
            }
        }

        private void HandlePan(float h, float v)
        {
            if (h == 0f && v == 0f) return;

            float rad = _currentYaw * Mathf.Deg2Rad;
            Vector3 fwd = new Vector3(Mathf.Sin(rad), 0f, Mathf.Cos(rad));
            Vector3 right = new Vector3(Mathf.Cos(rad), 0f, -Mathf.Sin(rad));

            Vector3 move = (fwd * v + right * h).normalized * (panSpeed * Time.deltaTime);
            Vector3 newPos = cameraTarget.position + move;

            if (clampPosition)
            {
                newPos.x = Mathf.Clamp(newPos.x, clampXRange.x, clampXRange.y);
                newPos.z = Mathf.Clamp(newPos.z, clampZRange.x, clampZRange.y);
            }

            newPos.y = cameraTarget.position.y;
            cameraTarget.position = newPos;
        }

        private void HandleZoom()
        {
            float scroll = Input.GetAxis("Mouse ScrollWheel");
            if (scroll != 0f)
            {
                _targetDistance -= scroll * zoomStep;
            }

            _targetDistance = Mathf.Clamp(_targetDistance, minDistance, maxDistance);

            _composer.CameraDistance = Mathf.SmoothDamp(
                _composer.CameraDistance, _targetDistance, ref _zoomVelocity, zoomSmoothTime);
        }

        private void HandleRotation()
        {
            if (_rotationTimer >= 1f)
            {
                if (Input.GetKeyDown(KeyCode.E)) BeginSnap(-90f);
                else if (Input.GetKeyDown(KeyCode.Q)) BeginSnap(+90f);
            }

            if (_rotationTimer < 1f)
            {
                _rotationTimer += Time.deltaTime / Mathf.Max(rotationDuration, 0.001f);
                _rotationTimer = Mathf.Clamp01(_rotationTimer);

                _currentYaw = Mathf.LerpAngle(
                    _rotationStart, _targetYaw,
                    _rotationTimer * _rotationTimer * (3f - 2f * _rotationTimer));

                Vector3 euler = cameraTarget.eulerAngles;
                euler.y = _currentYaw;
                cameraTarget.eulerAngles = euler;
            }
        }

        private void HandleUnitFollow()
        {
            if (_followTarget == null) { ClearFollowTarget(); return; }

            cameraTarget.position = Vector3.SmoothDamp(
                cameraTarget.position,
                new Vector3(_followTarget.position.x, cameraTarget.position.y, _followTarget.position.z),
                ref _followVelocity,
                followSmoothTime);
        }

        public void SetFollowTarget(Transform target)
        {
            _followTarget = target;
            _isFollowing = target != null;
            _followVelocity = Vector3.zero;
        }

        public void ClearFollowTarget()
        {
            _followTarget = null;
            _isFollowing = false;
        }

        private void BeginSnap(float delta)
        {
            _rotationStart = _currentYaw;
            _targetYaw += delta;
            _rotationTimer = 0f;
        }
    }
}