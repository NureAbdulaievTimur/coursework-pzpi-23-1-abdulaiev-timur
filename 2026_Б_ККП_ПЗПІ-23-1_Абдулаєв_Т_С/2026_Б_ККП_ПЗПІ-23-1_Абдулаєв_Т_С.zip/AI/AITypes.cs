using System;
using UnityEngine;

namespace CombatGrid
{

    public enum AIPreset
    {
        Custom,
        Aggressive,
        Defensive,
        Flanker,
        Berserker,
        Sniper,
        Coward,
        Support,
    }

    [Serializable]
    public class AIPhaseOverride
    {
        [Tooltip("Human-readable label (for Inspector clarity only).")]
        public string Label = "Phase Override";

        [Tooltip("Condition that triggers this override.")]
        public AIPhaseCondition Condition = AIPhaseCondition.AllyBelowHPPercent;

        [Tooltip("Threshold value for the condition (0-1 for HP%, integer for unit counts, etc.)")]
        [Min(0f)] public float ConditionThreshold = 0.3f;

        [Tooltip("Preset to switch to when the condition is met.  " +
                 "Use Custom to apply the weight deltas below instead.")]
        public AIPreset SwitchToPreset = AIPreset.Aggressive;

        [Tooltip("If SwitchToPreset == Custom, these deltas are ADDED to the base weights.")]
        public AIWeights WeightDeltas = new();

        [Tooltip("Once triggered, this override stays active until combat ends " +
                 "(false = re-evaluated every unit action).")]
        public bool Persistent = true;

        [NonSerialized] public bool HasTriggered;
    }

    public enum AIPhaseCondition
    {
        AllyBelowHPPercent,
        SelfBelowHPPercent,
        AllyCountBelow,
        EnemyCountBelow,
        RoundGreaterThan,
    }

    [Serializable]
    public class AIWeights
    {
        [Header("Attack Rewards")]
        [Tooltip("Flat reward for attempting any attack.")]
        public float BaseAttackReward = 10f;

        [Tooltip("Bonus per 1% of HP the target is missing.  Higher = focus wounded.")]
        public float WoundedTargetBonusPerPct = 0.15f;

        [Tooltip("Large bonus if the attack has a chance to kill the target outright.")]
        public float KillShotBonus = 20f;

        [Tooltip("Bonus when the target has no Energy Shield remaining.")]
        public float ShieldDepletedBonus = 5f;

        [Tooltip("Penalty when the target is at full Energy Shield.")]
        public float FullShieldPenalty = -4f;

        [Tooltip("Multiply the total attack reward by the calculated hit chance (0-1).  " +
                 "1 = fully scale by accuracy; 0 = ignore accuracy in scoring.")]
        [Range(0f, 1f)] public float HitChanceInfluence = 0.8f;

        [Tooltip("Bonus when the target has NO cover against this attacker.")]
        public float TargetExposedBonus = 6f;

        [Tooltip("Penalty when the target has Half Cover.")]
        public float TargetHalfCoverPenalty = -3f;

        [Tooltip("Penalty when the target has Full Cover.")]
        public float TargetFullCoverPenalty = -8f;

        [Header("Move Rewards")]
        [Tooltip("Flat reward just for moving (keeps units active; set 0 to prefer staying).")]
        public float BaseMoveReward = 1f;

        [Tooltip("Per-enemy-direction reward for having Half Cover at the destination. " +
                 "Evaluated against EACH enemy, not just the best direction.")]
        public float HalfCoverReward = 5f;

        [Tooltip("Per-enemy-direction reward for having Full Cover at the destination. " +
                 "Evaluated against EACH enemy, not just the best direction.")]
        public float FullCoverReward = 12f;

        [Tooltip("Reward for moving to a cell that gives a flank angle on any enemy.")]
        public float FlankPositionReward = 14f;

        [Tooltip("Reward per cell CLOSER to the nearest enemy.  " +
                 "Positive = aggressive; negative = defensive.")]
        public float ProximityRewardPerCell = 1.5f;

        [Tooltip("Replaces ProximityRewardPerCell when HP drops below RetreatHPThreshold.")]
        public float RetreatProximityRewardPerCell = -3f;

        [Tooltip("HP percentage below which retreat scoring kicks in (0-1).")]
        [Range(0f, 1f)] public float RetreatHPThreshold = 0.35f;

        [Tooltip("Penalty per ally unit in the same cell cluster (radius 1).")]
        public float AllyClusterPenalty = -4f;

        [Tooltip("Reward for moving to a cell that lets this unit attack an enemy next action.")]
        public float AttackOpportunityReward = 8f;

        [Header("Survivability")]
        [Tooltip("Penalty per enemy direction where this unit has NO cover.  " +
                 "Applied per exposed angle in aggregate cover scoring.  " +
                 "Negative values punish exposed positions; 0 = old best-cover-only behavior.")]
        public float ExposurePenaltyPerThreat = -3f;

        [Tooltip("Penalty per tier of cover LOST when moving from a better-covered cell to " +
                 "a worse one. Full->None = 2 tiers, Full->Half = 1, Half->None = 1.  " +
                 "Prevents the AI from leaving good cover unless the payoff is worth it.")]
        public float CoverLossPenaltyPerTier = -6f;

        [Tooltip("Flat bonus for attacking from the current position when already in " +
                 "Half or Full Cover.  Doubled when most enemy directions are covered.  " +
                 "This is the primary weight that keeps the AI from abandoning good cover.")]
        public float StayInCoverBonus = 8f;

        [Tooltip("Penalty per (enemies-in-range * exposed-directions) at the destination.  " +
                 "Represents the danger of being shot at without protection after acting.  " +
                 "Even small values (-0.5 to -2) dramatically discourage suicidal rushes.")]
        public float PostActionExposurePenalty = -1.5f;

        [Header("Wait / Pass")]
        [Tooltip("Flat reward for doing nothing (passing).  " +
                 "Keep low so wait is only chosen when all other options score worse.")]
        public float WaitReward = -5f;

        [Header("Randomness")]
        [Tooltip("Max random noise added to every action score before selection.")]
        [Min(0f)] public float ScoreNoise = 2f;

        public static AIWeights BuildPreset(AIPreset preset) => preset switch
        {
            AIPreset.Aggressive => new AIWeights
            {
                BaseAttackReward = 14f,
                WoundedTargetBonusPerPct = 0.20f,
                KillShotBonus = 25f,
                ShieldDepletedBonus = 6f,
                FullShieldPenalty = -2f,
                HitChanceInfluence = 0.6f,
                TargetExposedBonus = 4f,
                TargetHalfCoverPenalty = -1f,
                TargetFullCoverPenalty = -4f,
                BaseMoveReward = 1f,
                HalfCoverReward = 2f,
                FullCoverReward = 4f,
                FlankPositionReward = 10f,
                ProximityRewardPerCell = 3f,
                RetreatProximityRewardPerCell = -0.5f,
                RetreatHPThreshold = 0.15f,
                AllyClusterPenalty = -2f,
                AttackOpportunityReward = 10f,
                ExposurePenaltyPerThreat = -1f,
                CoverLossPenaltyPerTier = -2f,
                StayInCoverBonus = 3f,
                PostActionExposurePenalty = -0.5f,
                WaitReward = -10f,
                ScoreNoise = 1.5f,
            },

            AIPreset.Defensive => new AIWeights
            {
                BaseAttackReward = 8f,
                WoundedTargetBonusPerPct = 0.10f,
                KillShotBonus = 18f,
                ShieldDepletedBonus = 3f,
                FullShieldPenalty = -5f,
                HitChanceInfluence = 0.95f,
                TargetExposedBonus = 8f,
                TargetHalfCoverPenalty = -5f,
                TargetFullCoverPenalty = -12f,
                BaseMoveReward = 0f,
                HalfCoverReward = 10f,
                FullCoverReward = 20f,
                FlankPositionReward = 6f,
                ProximityRewardPerCell = -1f,
                RetreatProximityRewardPerCell = -4f,
                RetreatHPThreshold = 0.5f,
                AllyClusterPenalty = -3f,
                AttackOpportunityReward = 6f,
                ExposurePenaltyPerThreat = -6f,
                CoverLossPenaltyPerTier = -12f,
                StayInCoverBonus = 16f,
                PostActionExposurePenalty = -3f,
                WaitReward = 0f,
                ScoreNoise = 1f,
            },

            AIPreset.Flanker => new AIWeights
            {
                BaseAttackReward = 10f,
                WoundedTargetBonusPerPct = 0.12f,
                KillShotBonus = 22f,
                ShieldDepletedBonus = 4f,
                FullShieldPenalty = -3f,
                HitChanceInfluence = 0.75f,
                TargetExposedBonus = 10f,
                TargetHalfCoverPenalty = -4f,
                TargetFullCoverPenalty = -10f,
                BaseMoveReward = 3f,
                HalfCoverReward = 4f,
                FullCoverReward = 7f,
                FlankPositionReward = 22f,
                ProximityRewardPerCell = 2f,
                RetreatProximityRewardPerCell = -2f,
                RetreatHPThreshold = 0.3f,
                AllyClusterPenalty = -6f,
                AttackOpportunityReward = 9f,
                ExposurePenaltyPerThreat = -2f,
                CoverLossPenaltyPerTier = -4f,
                StayInCoverBonus = 4f,
                PostActionExposurePenalty = -1f,
                WaitReward = -8f,
                ScoreNoise = 2.5f,
            },

            AIPreset.Berserker => new AIWeights
            {
                BaseAttackReward = 18f,
                WoundedTargetBonusPerPct = 0.30f,
                KillShotBonus = 30f,
                ShieldDepletedBonus = 8f,
                FullShieldPenalty = 0f,
                HitChanceInfluence = 0.3f,
                TargetExposedBonus = 2f,
                TargetHalfCoverPenalty = 0f,
                TargetFullCoverPenalty = 0f,
                BaseMoveReward = 1f,
                HalfCoverReward = 0f,
                FullCoverReward = 0f,
                FlankPositionReward = 5f,
                ProximityRewardPerCell = 4f,
                RetreatProximityRewardPerCell = 4f,
                RetreatHPThreshold = 0f,
                AllyClusterPenalty = 0f,
                AttackOpportunityReward = 12f,
                ExposurePenaltyPerThreat = 0f,
                CoverLossPenaltyPerTier = 0f,
                StayInCoverBonus = 0f,
                PostActionExposurePenalty = 0f,
                WaitReward = -20f,
                ScoreNoise = 4f,
            },

            AIPreset.Sniper => new AIWeights
            {
                BaseAttackReward = 10f,
                WoundedTargetBonusPerPct = 0.18f,
                KillShotBonus = 28f,
                ShieldDepletedBonus = 6f,
                FullShieldPenalty = -3f,
                HitChanceInfluence = 1f,
                TargetExposedBonus = 12f,
                TargetHalfCoverPenalty = -8f,
                TargetFullCoverPenalty = -16f,
                BaseMoveReward = 0f,
                HalfCoverReward = 8f,
                FullCoverReward = 14f,
                FlankPositionReward = 10f,
                ProximityRewardPerCell = -2f,
                RetreatProximityRewardPerCell = -5f,
                RetreatHPThreshold = 0.4f,
                AllyClusterPenalty = -3f,
                AttackOpportunityReward = 14f,
                ExposurePenaltyPerThreat = -5f,
                CoverLossPenaltyPerTier = -10f,
                StayInCoverBonus = 14f,
                PostActionExposurePenalty = -2.5f,
                WaitReward = -2f,
                ScoreNoise = 0.5f,
            },

            AIPreset.Coward => new AIWeights
            {
                BaseAttackReward = 5f,
                WoundedTargetBonusPerPct = 0.05f,
                KillShotBonus = 15f,
                ShieldDepletedBonus = 2f,
                FullShieldPenalty = -8f,
                HitChanceInfluence = 0.9f,
                TargetExposedBonus = 5f,
                TargetHalfCoverPenalty = -6f,
                TargetFullCoverPenalty = -14f,
                BaseMoveReward = 2f,
                HalfCoverReward = 12f,
                FullCoverReward = 24f,
                FlankPositionReward = 4f,
                ProximityRewardPerCell = -4f,
                RetreatProximityRewardPerCell = -8f,
                RetreatHPThreshold = 0.8f,
                AllyClusterPenalty = -1f,
                AttackOpportunityReward = 4f,
                ExposurePenaltyPerThreat = -8f,
                CoverLossPenaltyPerTier = -16f,
                StayInCoverBonus = 20f,
                PostActionExposurePenalty = -4f,
                WaitReward = 2f,
                ScoreNoise = 1f,
            },

            AIPreset.Support => new AIWeights
            {
                BaseAttackReward = 4f,
                WoundedTargetBonusPerPct = 0.05f,
                KillShotBonus = 10f,
                ShieldDepletedBonus = 1f,
                FullShieldPenalty = -6f,
                HitChanceInfluence = 0.9f,
                TargetExposedBonus = 3f,
                TargetHalfCoverPenalty = -4f,
                TargetFullCoverPenalty = -10f,
                BaseMoveReward = 1f,
                HalfCoverReward = 10f,
                FullCoverReward = 18f,
                FlankPositionReward = 3f,
                ProximityRewardPerCell = -2f,
                RetreatProximityRewardPerCell = -5f,
                RetreatHPThreshold = 0.6f,
                AllyClusterPenalty = 6f,
                AttackOpportunityReward = 3f,
                ExposurePenaltyPerThreat = -5f,
                CoverLossPenaltyPerTier = -8f,
                StayInCoverBonus = 12f,
                PostActionExposurePenalty = -2f,
                WaitReward = 3f,
                ScoreNoise = 1.5f,
            },

            _ => new AIWeights()
        };

        public static AIWeights operator +(AIWeights a, AIWeights b) => new()
        {
            BaseAttackReward = a.BaseAttackReward + b.BaseAttackReward,
            WoundedTargetBonusPerPct = a.WoundedTargetBonusPerPct + b.WoundedTargetBonusPerPct,
            KillShotBonus = a.KillShotBonus + b.KillShotBonus,
            ShieldDepletedBonus = a.ShieldDepletedBonus + b.ShieldDepletedBonus,
            FullShieldPenalty = a.FullShieldPenalty + b.FullShieldPenalty,
            HitChanceInfluence = Mathf.Clamp01(a.HitChanceInfluence + b.HitChanceInfluence),
            TargetExposedBonus = a.TargetExposedBonus + b.TargetExposedBonus,
            TargetHalfCoverPenalty = a.TargetHalfCoverPenalty + b.TargetHalfCoverPenalty,
            TargetFullCoverPenalty = a.TargetFullCoverPenalty + b.TargetFullCoverPenalty,
            BaseMoveReward = a.BaseMoveReward + b.BaseMoveReward,
            HalfCoverReward = a.HalfCoverReward + b.HalfCoverReward,
            FullCoverReward = a.FullCoverReward + b.FullCoverReward,
            FlankPositionReward = a.FlankPositionReward + b.FlankPositionReward,
            ProximityRewardPerCell = a.ProximityRewardPerCell + b.ProximityRewardPerCell,
            RetreatProximityRewardPerCell = a.RetreatProximityRewardPerCell + b.RetreatProximityRewardPerCell,
            RetreatHPThreshold = Mathf.Clamp01(a.RetreatHPThreshold + b.RetreatHPThreshold),
            AllyClusterPenalty = a.AllyClusterPenalty + b.AllyClusterPenalty,
            AttackOpportunityReward = a.AttackOpportunityReward + b.AttackOpportunityReward,
            ExposurePenaltyPerThreat = a.ExposurePenaltyPerThreat + b.ExposurePenaltyPerThreat,
            CoverLossPenaltyPerTier = a.CoverLossPenaltyPerTier + b.CoverLossPenaltyPerTier,
            StayInCoverBonus = a.StayInCoverBonus + b.StayInCoverBonus,
            PostActionExposurePenalty = a.PostActionExposurePenalty + b.PostActionExposurePenalty,
            WaitReward = a.WaitReward + b.WaitReward,
            ScoreNoise = Mathf.Max(0, a.ScoreNoise + b.ScoreNoise),
        };
    }
}