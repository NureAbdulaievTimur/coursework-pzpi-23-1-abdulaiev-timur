using System;
using UnityEngine;

namespace CombatGrid
{
    public enum UnitTeam { Player, Enemy, Neutral }
    public enum UnitState { Idle, Moving, Acting, Dead }

    [RequireComponent(typeof(UnitMovement))]
    public class Unit : MonoBehaviour
    {
        [Header("Unit Configuration")]
        [SerializeField] private UnitStats _stats;
        [SerializeField] private UnitTeam _team = UnitTeam.Player;

        [Header("AI")]
        [Tooltip("Per-unit AI personality. If left empty, EnemyAI uses its FallbackProfile. " +
                 "Ignored entirely for Player-team units.")]
        [SerializeField] private AIBehaviorProfile _aiProfile;

        public UnitStats Stats => _stats;
        public UnitTeam Team => _team;
        public AIBehaviorProfile AIProfile => _aiProfile;

        public GridCoord CurrentCoord { get; private set; }
        public GridCell CurrentCell => GridManager.Instance?.GetCell(CurrentCoord);
        public UnitState State { get; private set; } = UnitState.Idle;
        public bool IsAlive => State != UnitState.Dead;

        public int CurrentHP { get; private set; }
        public int CurrentEnergyShield { get; private set; }

        public float HealthPercent => _stats != null ? (float)CurrentHP / _stats.MaxHP : 0f;
        public float EnergyShieldPercent => (_stats != null && _stats.MaxEnergyShield > 0)
                                            ? (float)CurrentEnergyShield / _stats.MaxEnergyShield : 0f;
        public bool HasEnergyShield => _stats != null && _stats.MaxEnergyShield > 0;

        public int RemainingMovePoints { get; private set; }
        public int RemainingActionPoints { get; private set; }
        public bool HasActedThisTurn { get; private set; }

        public bool CanMove =>
            IsAlive &&
            !Movement.IsMoving &&
            RemainingMovePoints > 0 &&
            (!HasActedThisTurn || _stats.CanMoveAfterAction);

        public bool CanAct => IsAlive && !Movement.IsMoving && RemainingActionPoints > 0;

        public int RemainingReactionPoints { get; private set; }
        public bool CanReact => IsAlive && RemainingReactionPoints > 0;

        public UnitMovement Movement { get; private set; }

        public event Action<Unit> OnUnitDied;
        public event Action<Unit, int> OnHPDamageTaken;
        public event Action<Unit, int> OnShieldDamageTaken;
        public event Action<Unit> OnAttackEvaded;
        public event Action<Unit> OnTurnStarted;
        public event Action<UnitState> OnStateChanged;
        public event Action<Unit> OnPointsChanged;
        public event Action<Unit> OnShieldRestored;

        [SerializeField] private Transform chestTarget;
        public Transform ChestTarget => chestTarget;
        private void Awake()
        {
            Movement = GetComponent<UnitMovement>();

            if (_stats == null)
            {
                Debug.LogError($"[Unit] {name} has no UnitStats assigned!", this);
                return;
            }

            CurrentHP = _stats.MaxHP;
            CurrentEnergyShield = _stats.MaxEnergyShield;
            RemainingMovePoints = _stats.MovePointsPerTurn;
            RemainingActionPoints = _stats.ActionPointsPerTurn;
            RemainingReactionPoints = _stats.ReactionPointsPerRound;
        }

        private void Start()
        {
            RegisterOnGrid();

            if (TurnManager.Instance != null)
                TurnManager.Instance.RegisterUnit(this);
            else
                Debug.LogWarning($"[Unit] {name}: No TurnManager in scene.", this);

            if (ReactionSystem.Instance != null)
                ReactionSystem.Instance.SubscribeToUnit(this);

            if (UnitHealthBarManager.Instance != null)
                UnitHealthBarManager.Instance.RegisterUnit(this);
        }

        private void OnDestroy()
        {
            UnregisterFromGrid();
            if (TurnManager.Instance != null)
                TurnManager.Instance.UnregisterUnit(this);
        }

        public void StartTurn()
        {
            if (!IsAlive) return;

            RemainingMovePoints = _stats.MovePointsPerTurn;
            RemainingActionPoints = _stats.ActionPointsPerTurn;
            HasActedThisTurn = false;
            Movement.ResetDiagCount();

            if (_stats.ShieldRegenPerTurn > 0 && HasEnergyShield)
                ReplenishShield(_stats.ShieldRegenPerTurn);

            OnTurnStarted?.Invoke(this);
            OnPointsChanged?.Invoke(this);
        }

        public void RefreshReactionPoints()
        {
            if (!IsAlive) return;
            RemainingReactionPoints = _stats.ReactionPointsPerRound;
            OnPointsChanged?.Invoke(this);
        }

        public bool TrySpendMovePoints(int amount)
        {
            if (amount > RemainingMovePoints) return false;
            RemainingMovePoints = Mathf.Max(0, RemainingMovePoints - amount);
            OnPointsChanged?.Invoke(this);
            return true;
        }

        public bool TrySpendActionPoints(int amount = 1)
        {
            if (amount > RemainingActionPoints) return false;
            RemainingActionPoints = Mathf.Max(0, RemainingActionPoints - amount);
            HasActedThisTurn = true;

            if (!_stats.CanMoveAfterAction)
                RemainingMovePoints = 0;

            OnPointsChanged?.Invoke(this);
            return true;
        }

        public bool TrySpendReactionPoint()
        {
            if (RemainingReactionPoints <= 0) return false;
            RemainingReactionPoints = Mathf.Max(0, RemainingReactionPoints - 1);
            OnPointsChanged?.Invoke(this);
            return true;
        }


        public void RegisterOnGrid()
        {
            if (GridManager.Instance == null) return;
            PlaceOnCell(GridManager.Instance.WorldToCoord(transform.position));
        }

        public void PlaceOnCell(GridCoord coord)
        {
            if (GridManager.Instance == null) return;
            CurrentCell?.ClearOccupant();

            GridCell target = GridManager.Instance.GetCell(coord);
            if (target == null)
            {
                Debug.LogWarning($"[Unit] {name} tried to place on invalid coord {coord}.");
                return;
            }

            CurrentCoord = coord;
            target.SetOccupant(this);
            transform.position = target.WorldPos;
        }

        public void SetCurrentCoord(GridCoord coord) => CurrentCoord = coord;
        private void UnregisterFromGrid() => CurrentCell?.ClearOccupant();


        public void SetState(UnitState newState)
        {
            if (State == newState) return;
            State = newState;
            OnStateChanged?.Invoke(newState);
        }

        public void TakeDamage(int rawDamage, bool armorPiercing = false, bool shieldPiercing = false)
        {
            if (!IsAlive || rawDamage <= 0) return;

            int remaining = rawDamage;

            if (!armorPiercing && !shieldPiercing && CurrentEnergyShield > 0)
            {
                int shieldDmg = Mathf.Min(CurrentEnergyShield, remaining);
                CurrentEnergyShield -= shieldDmg;
                remaining -= shieldDmg;
                OnShieldDamageTaken?.Invoke(this, shieldDmg);
                if (remaining <= 0) return;
            }

            int armorDR = armorPiercing ? 0 : (_stats?.Armor ?? 0);
            int effective = Mathf.Max(0, remaining - armorDR);

            if (effective > 0)
            {
                CurrentHP = Mathf.Max(0, CurrentHP - effective);
                OnHPDamageTaken?.Invoke(this, effective);
            }

            if (CurrentHP <= 0) Die();
        }

        public void NotifyEvaded() => OnAttackEvaded?.Invoke(this);


        public void Heal(int amount)
        {
            if (!IsAlive) return;
            CurrentHP = Mathf.Min(_stats.MaxHP, CurrentHP + amount);
        }

        public void ReplenishShield(int amount)
        {
            if (!IsAlive || !HasEnergyShield) return;

            bool wasEmpty = CurrentEnergyShield == 0;
            CurrentEnergyShield = Mathf.Min(_stats.MaxEnergyShield, CurrentEnergyShield + amount);

            if (wasEmpty && CurrentEnergyShield > 0)
            {
                OnShieldRestored?.Invoke(this);
            }
        }

        private void Die()
        {
            SetState(UnitState.Dead);
            UnregisterFromGrid();
            OnUnitDied?.Invoke(this);
            Debug.Log($"[Unit] {name} ({_team}) died.");
        }

        public override string ToString()
            => $"[{_team}] {(_stats != null ? _stats.UnitName : name)} @ {CurrentCoord} " +
               $"HP:{CurrentHP}/{_stats?.MaxHP} Shield:{CurrentEnergyShield}/{_stats?.MaxEnergyShield} " +
               $"MP:{RemainingMovePoints} AP:{RemainingActionPoints} RP:{RemainingReactionPoints}";
    }
}