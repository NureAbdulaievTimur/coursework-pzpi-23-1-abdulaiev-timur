using UnityEngine;
using System.Collections;
using System.Collections.Generic;

namespace CombatGrid
{
    public class DamagePopupManager : MonoBehaviour
    {
        public static DamagePopupManager Instance { get; private set; }

        [Header("Setup")]
        [SerializeField] private DamagePopup _popupPrefab;
        [SerializeField] private Canvas _canvas;
        [SerializeField] private Camera _camera;

        [Header("Colors & Styling")]
        [SerializeField] private Color _hpDamageColor = new Color(1.00f, 0.50f, 0.00f, 1f);
        [SerializeField] private Color _shieldDamageColor = new Color(0.25f, 0.65f, 1f, 1f);
        [SerializeField] private Color _missColor = new Color(0.7f, 0.7f, 0.7f, 1f);

        [Header("Spacing")]
        [Tooltip("How high above the unit should the text spawn?")]
        [SerializeField] private Vector3 _worldOffset = new Vector3(0f, 1.5f, 0f);

        [Header("Multi-Damage Config (For Special Abilities)")]
        [SerializeField] private float _multiDamageSpacing = 0.6f;
        [SerializeField] private float _multiDamageAngleSplit = 0.5f;
        [SerializeField] private float _multiDamageDelay = 0.08f;

        private readonly List<DamagePopup> _activePopups = new List<DamagePopup>();

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;

            if (_camera == null) _camera = Camera.main;
        }

        private void Start()
        {
            if (CombatManager.Instance != null)
                CombatManager.Instance.OnAttackResolved += HandleAttackResolved;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
            if (CombatManager.Instance != null)
                CombatManager.Instance.OnAttackResolved -= HandleAttackResolved;
        }

        private void LateUpdate()
        {
            for (int i = _activePopups.Count - 1; i >= 0; i--)
            {
                DamagePopup popup = _activePopups[i];

                if (popup == null)
                {
                    _activePopups.RemoveAt(i);
                    continue;
                }

                if (!popup.Tick(Time.deltaTime))
                {
                    Destroy(popup.gameObject);
                    _activePopups.RemoveAt(i);
                }
            }
        }

        private void HandleAttackResolved(AttackResult result, Unit attacker, Unit defender)
        {
            if (defender == null) return;

            Vector3 spawnPos = defender.transform.position + _worldOffset;

            if (!result.DidHit)
            {
                SpawnSingleDamagePopup("Miss!", _missColor, spawnPos, 1.0f);
                return;
            }

            bool hitShield = result.ShieldDamageDealt > 0;
            bool hitHP = result.HPDamageDealt > 0;

            if (hitShield && hitHP)
            {
                SpawnMultiDamagePopups(
                    result.ShieldDamageDealt.ToString(), _shieldDamageColor,
                    result.HPDamageDealt.ToString(), _hpDamageColor,
                    spawnPos, 1.0f);
            }
            else if (hitShield)
            {
                SpawnSingleDamagePopup(result.ShieldDamageDealt.ToString(), _shieldDamageColor, spawnPos, 1.0f);
            }
            else if (hitHP)
            {
                SpawnSingleDamagePopup(result.HPDamageDealt.ToString(), _hpDamageColor, spawnPos, 1.0f);
            }
        }

        public void SpawnSingleDamagePopup(string text, Color color, Vector3 worldPos, float scaleMult = 1f, Vector2? customDir = null)
        {
            if (_popupPrefab == null || _canvas == null) return;

            DamagePopup popup = Instantiate(_popupPrefab, _canvas.transform);

            Canvas popCanvas = popup.GetComponent<Canvas>();
            if (popCanvas == null) popCanvas = popup.gameObject.AddComponent<Canvas>();

            popCanvas.overrideSorting = true;
            popCanvas.sortingOrder = 30000;

            popup.Setup(text, color, worldPos, _camera, _canvas, scaleMult, customDir);

            _activePopups.Add(popup);
        }

        public void SpawnMultiDamagePopups(string text1, Color color1, string text2, Color color2, Vector3 basePos, float scaleMult = 1f)
        {
            StartCoroutine(MultiDamageRoutine(text1, color1, text2, color2, basePos, scaleMult));
        }

        private IEnumerator MultiDamageRoutine(string text1, Color color1, string text2, Color color2, Vector3 basePos, float scaleMult)
        {
            Vector3 horizontalOffset = _camera.transform.right * (_multiDamageSpacing * 0.5f);

            Vector3 pos1 = basePos - horizontalOffset;
            Vector3 pos2 = basePos + horizontalOffset;

            Vector2 dir1 = new Vector2(-_multiDamageAngleSplit, 1f).normalized;
            Vector2 dir2 = new Vector2(_multiDamageAngleSplit, 1f).normalized;

            SpawnSingleDamagePopup(text1, color1, pos1, scaleMult, dir1);

            yield return new WaitForSeconds(_multiDamageDelay);

            SpawnSingleDamagePopup(text2, color2, pos2, scaleMult, dir2);
        }
    }
}