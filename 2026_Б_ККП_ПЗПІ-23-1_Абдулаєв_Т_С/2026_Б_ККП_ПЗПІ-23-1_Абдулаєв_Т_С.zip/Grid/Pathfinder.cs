using System;
using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    public static class Pathfinder
    {
        public static List<GridCell> FindPath(
            GridCoord start, GridCoord end,
            GridManager grid,
            bool blockOccupied = true,
            int startingDiagCount = 0)
        {
            if (grid == null) throw new ArgumentNullException(nameof(grid));

            GridCell startCell = grid.GetCell(start);
            GridCell endCell = grid.GetCell(end);

            if (startCell == null || endCell == null) return null;
            if (!endCell.IsWalkable || endCell.IsObstructed) return null;
            if (blockOccupied && endCell.IsOccupied) return null;
            if (start == end) return new List<GridCell> { startCell };

            var settings = grid.Settings;

            var openSet = new MinHeap<AStarNode>();
            var nodeMap = new Dictionary<(GridCoord, int), AStarNode>();

            int startParity = startingDiagCount % 2;
            var startNode = new AStarNode(startCell, null, 0, Heuristic(start, end, settings, startParity), startParity);

            openSet.Insert(startNode);
            nodeMap[(start, startParity)] = startNode;

            while (openSet.Count > 0)
            {
                AStarNode current = openSet.ExtractMin();

                if (current.Cell.Coord == end)
                    return ReconstructPath(current);

                foreach (GridCell neighbor in grid.GetWalkableNeighbors(
                             current.Cell,
                             settings.AllowDiagonalMovement,
                             blockOccupied: blockOccupied,
                             occupiedExemptCoord: end))
                {
                    bool isDiag = GridCoord.IsDiagonal(current.Cell.Coord, neighbor.Coord);
                    int nextParity = isDiag ? (1 - current.Parity) : current.Parity;

                    int stepBase = isDiag ? (current.Parity == 0 ? 1 : 2) : 1;
                    int stepCost = stepBase * settings.StraightMoveCost;

                    int newG = current.G + Mathf.RoundToInt(stepCost * neighbor.MoveCostModifier);

                    int newDirX = neighbor.Coord.X - current.Cell.Coord.X;
                    int newDirZ = neighbor.Coord.Z - current.Cell.Coord.Z;

                    int newTurns = current.Parent == null ? 0 :
                        current.TurnCount + ((newDirX == current.DirX && newDirZ == current.DirZ) ? 0 : 1);

                    if (nodeMap.TryGetValue((neighbor.Coord, nextParity), out AStarNode existing))
                    {
                        if (newG < existing.G || (newG == existing.G && newTurns < existing.TurnCount))
                        {
                            existing.G = newG;
                            existing.F = newG + existing.H;
                            existing.Parent = current;
                            existing.DirX = newDirX;
                            existing.DirZ = newDirZ;
                            existing.TurnCount = newTurns;
                            openSet.Update(existing);
                        }
                    }
                    else
                    {
                        int h = Heuristic(neighbor.Coord, end, settings, nextParity);
                        var node = new AStarNode(neighbor, current, newG, h, nextParity);
                        openSet.Insert(node);
                        nodeMap[(neighbor.Coord, nextParity)] = node;
                    }
                }
            }
            return null;
        }

        public static int CalculatePathCost(List<GridCell> path, GridSettings settings, int startingDiagCount = 0)
        {
            if (path == null || path.Count < 2) return 0;
            int total = 0;
            int parity = startingDiagCount % 2;

            for (int i = 1; i < path.Count; i++)
            {
                bool isDiag = GridCoord.IsDiagonal(path[i - 1].Coord, path[i].Coord);

                int stepBase = isDiag ? (parity == 0 ? 1 : 2) : 1;
                int stepCost = stepBase * settings.StraightMoveCost;

                total += Mathf.RoundToInt(stepCost * path[i].MoveCostModifier);
                if (isDiag) parity = 1 - parity;
            }
            return total;
        }

        private static int Heuristic(GridCoord from, GridCoord to, GridSettings settings, int currentParity)
        {
            int dx = Mathf.Abs(to.X - from.X);
            int dz = Mathf.Abs(to.Z - from.Z);
            int straight = Mathf.Abs(dx - dz);
            int diag = Mathf.Min(dx, dz);

            int diagCost = (diag / 2) * 3 + (diag % 2) * (currentParity == 0 ? 1 : 2);
            return settings.StraightMoveCost * (straight + diagCost);
        }

        private static List<GridCell> ReconstructPath(AStarNode endNode)
        {
            var path = new List<GridCell>();
            var current = endNode;
            while (current != null)
            {
                path.Add(current.Cell);
                current = current.Parent;
            }
            path.Reverse();
            return path;
        }

        private class AStarNode : IComparable<AStarNode>
        {
            public GridCell Cell;
            public AStarNode Parent;
            public int G, H, F;
            public int Parity;
            public int HeapIndex;

            public int DirX, DirZ;
            public int TurnCount;

            public AStarNode(GridCell cell, AStarNode parent, int g, int h, int parity)
            {
                Cell = cell; Parent = parent; G = g; H = h; F = g + h; Parity = parity;

                if (parent != null)
                {
                    DirX = cell.Coord.X - parent.Cell.Coord.X;
                    DirZ = cell.Coord.Z - parent.Cell.Coord.Z;

                    if (parent.Parent == null)
                        TurnCount = 0;
                    else
                        TurnCount = parent.TurnCount + ((DirX == parent.DirX && DirZ == parent.DirZ) ? 0 : 1);
                }
                else
                {
                    DirX = 0; DirZ = 0; TurnCount = 0;
                }
            }

            public int CompareTo(AStarNode other)
            {
                int cmp = F.CompareTo(other.F);
                if (cmp != 0) return cmp;

                int turnCmp = TurnCount.CompareTo(other.TurnCount);
                if (turnCmp != 0) return turnCmp;

                return other.G.CompareTo(G);
            }
        }

        private class MinHeap<T> where T : AStarNode
        {
            private readonly List<T> _data = new();
            public int Count => _data.Count;
            public void Insert(T node) { _data.Add(node); node.HeapIndex = _data.Count - 1; SiftUp(node.HeapIndex); }
            public T ExtractMin() { T min = _data[0]; int last = _data.Count - 1; _data[0] = _data[last]; _data[0].HeapIndex = 0; _data.RemoveAt(last); if (_data.Count > 0) SiftDown(0); return min; }
            public void Update(T node) => SiftUp(node.HeapIndex);
            private void SiftUp(int i) { while (i > 0) { int p = (i - 1) / 2; if (_data[i].CompareTo(_data[p]) < 0) Swap(i, p); else break; i = p; } }
            private void SiftDown(int i) { while (true) { int l = 2 * i + 1, r = 2 * i + 2, s = i; if (l < _data.Count && _data[l].CompareTo(_data[s]) < 0) s = l; if (r < _data.Count && _data[r].CompareTo(_data[s]) < 0) s = r; if (s == i) break; Swap(i, s); i = s; } }
            private void Swap(int a, int b) { (_data[a], _data[b]) = (_data[b], _data[a]); _data[a].HeapIndex = a; _data[b].HeapIndex = b; }
        }
    }
}