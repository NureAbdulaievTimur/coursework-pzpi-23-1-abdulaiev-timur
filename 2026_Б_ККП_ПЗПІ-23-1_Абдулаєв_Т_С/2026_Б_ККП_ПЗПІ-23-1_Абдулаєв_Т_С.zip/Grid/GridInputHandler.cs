using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

namespace CombatGrid
{
    public enum GridInputMode { Movement, Attack }

    public class GridInputHandler : MonoBehaviour
    {
        [Header("References")]
        [SerializeField] private Camera _camera;
        [SerializeField] private CombatGridShaderBridge _bridge;

        [Header("Raycast")]
        [SerializeField] private LayerMask _gridLayerMask = ~0;
        [SerializeField] private float _raycastDistance = 500f;

        [Header("Turn Controls")]
        [SerializeField] private KeyCode _endTurnKey = KeyCode.Return;
        [SerializeField] private KeyCode _toggleModeKey = KeyCode.Tab;

        [SerializeField] private MoveCostOverlay _moveCostOverlay;

        [Header("Aim Line Settings")]
        [SerializeField] private Material _aimLineMaterialTemplate;
        [ColorUsage(true, true)]
        [SerializeField] private Color _aimLineColor = new Color(5f, 2.5f, 0f, 0.8f);
        [SerializeField] private float _aimLineFadeSpeed = 8f;
        [SerializeField] private float _aimLineWidth = 0.08f;

        [Space(5)]
        [SerializeField] private float _aimLineDashScale = 3f;
        [SerializeField] private float _aimLineDashSpeed = 2f;

        [Tooltip("Higher = Shorter, punchier dashes. Lower = Longer streaks.")]
        [Range(0.1f, 5f)][SerializeField] private float _aimLineDashSize = 1.5f;

        [Tooltip("0 = Blurry soft glow. 1 = Crisp, sharp laser edge.")]
        [Range(0.01f, 0.99f)][SerializeField] private float _aimLineHardness = 0.7f;

        [Tooltip("Max distance the line fades out near units.")]
        [SerializeField] private float _aimLineEdgeFade = 1.5f;

        private LineRenderer _aimLine;
        private Material _aimMaterial;
        private float _currentAimAlpha;
        private Unit _currentAimTarget;
        private Vector3 _lastAimStartPos;
        private Vector3 _lastAimEndPos;

        private Unit _selectedUnit;
        private List<GridCell> _reachableCells = new();

        private GridInputMode _currentMode = GridInputMode.Movement;

        private GridCell _currentHoveredCell;
        private GridCoord _lastHoveredCoord;
        private bool _hasLastHover;

        private Unit _lastNotifiedHoveredUnit;
        private Unit _lastPreviewedUnit;

        private bool _isExecutingAction = false;

        public Unit SelectedUnit => _selectedUnit;

        private bool IsPlayerTurn =>
            TurnManager.Instance == null || TurnManager.Instance.IsPlayerPhase;

        private void Awake()
        {
            if (_camera == null) _camera = Camera.main;
            if (_bridge == null) _bridge = CombatGridShaderBridge.Instance;
            if (_moveCostOverlay == null) _moveCostOverlay = FindObjectOfType<MoveCostOverlay>();

            InitializeAimLine();
        }

        private void InitializeAimLine()
        {
            GameObject lineObj = new GameObject("AimLineIndicator");
            lineObj.transform.SetParent(this.transform);
            _aimLine = lineObj.AddComponent<LineRenderer>();

            _aimLine.positionCount = 2;
            _aimLine.useWorldSpace = true;
            _aimLine.textureMode = LineTextureMode.Tile;
            _aimLine.enabled = false;

            if (_aimLineMaterialTemplate != null)
            {
                _aimMaterial = new Material(_aimLineMaterialTemplate);
                _aimLine.material = _aimMaterial;
            }
            else
            {
                Debug.LogError("[GridInputHandler] Aim Line Material Template is not assigned in the Inspector!");
            }
        }

        private void UpdateAimLine()
        {
            float targetAlpha = 0f;

            if (_currentMode == GridInputMode.Attack && !_isExecutingAction && _selectedUnit != null && _currentAimTarget != null)
            {
                targetAlpha = 1f;
                _lastAimStartPos = GetUnitChestPos(_selectedUnit);
                _lastAimEndPos = GetUnitChestPos(_currentAimTarget);
            }

            _currentAimAlpha = Mathf.MoveTowards(_currentAimAlpha, targetAlpha, _aimLineFadeSpeed * Time.deltaTime);

            if (_currentAimAlpha > 0.01f)
            {
                _aimLine.enabled = true;

                _aimLine.startWidth = _aimLineWidth;
                _aimLine.endWidth = _aimLineWidth;

                _aimLine.SetPosition(0, _lastAimStartPos);
                _aimLine.SetPosition(1, _lastAimEndPos);

                if (_aimMaterial != null)
                {
                    _aimMaterial.SetFloat("_Alpha", _currentAimAlpha);
                    _aimMaterial.SetColor("_Color", _aimLineColor);
                    _aimMaterial.SetFloat("_DashScale", _aimLineDashScale);
                    _aimMaterial.SetFloat("_DashSpeed", _aimLineDashSpeed);
                    _aimMaterial.SetFloat("_DashSize", _aimLineDashSize);
                    _aimMaterial.SetFloat("_Hardness", _aimLineHardness);
                    _aimMaterial.SetFloat("_EdgeFade", _aimLineEdgeFade);

                    _aimMaterial.SetVector("_StartPos", _lastAimStartPos);
                    _aimMaterial.SetVector("_EndPos", _lastAimEndPos);
                }
            }
            else
            {
                _aimLine.enabled = false;
            }
        }

        private Vector3 GetUnitChestPos(Unit unit)
        {
            if (unit == null) return Vector3.zero;
            if (unit.ChestTarget != null) return unit.ChestTarget.position;
            return unit.transform.position + Vector3.up * 1.4f;
        }

        private void Start()
        {
            CombatGridShaderBridge.Instance.SetCombatMode(true);

            if (TurnManager.Instance != null)
            {
                TurnManager.Instance.OnPhaseStarted += OnPhaseStarted;
                TurnManager.Instance.OnPhaseEnded += OnPhaseEnded;
            }
        }

        private void OnDestroy()
        {
            if (TurnManager.Instance != null)
            {
                TurnManager.Instance.OnPhaseStarted -= OnPhaseStarted;
                TurnManager.Instance.OnPhaseEnded -= OnPhaseEnded;
            }
        }

        private void OnPhaseStarted(UnitTeam team, int round) => Deselect();
        private void OnPhaseEnded(UnitTeam team, int round) => Deselect();

        private void Update()
        {
            bool isQTEActive = QTEManager.Instance != null && QTEManager.Instance.IsSpotlightActive;
            bool isInvalidTurn = !IsPlayerTurn || (TurnManager.Instance != null && TurnManager.Instance.IsTransitioning);
            bool isPointerOverUI = EventSystem.current != null && EventSystem.current.IsPointerOverGameObject();

            if (isInvalidTurn || isPointerOverUI || isQTEActive)
            {
                ClearHoverState();
                UpdateAimLine();
                return;
            }

            HandleHover();
            UpdateAimLine();

            if (_isExecutingAction) return;

            if (Input.GetKeyDown(_toggleModeKey) && _selectedUnit != null)
            {
                ToggleInputMode();
            }

            if (Input.GetKeyDown(_endTurnKey) && IsPlayerTurn)
            {
                Deselect();
                TurnManager.Instance?.EndPhase();
                return;
            }

            if (Input.GetMouseButtonDown(0)) HandleLeftClick();
            if (Input.GetMouseButtonDown(1)) Deselect();
        }

        private void ToggleInputMode()
        {
            if (_currentMode == GridInputMode.Movement && _selectedUnit.CanAct)
            {
                _currentMode = GridInputMode.Attack;
                RefreshSelectionVisuals();
                _hasLastHover = false;
            }
            else if (_currentMode == GridInputMode.Attack)
            {
                _currentMode = GridInputMode.Movement;
                RefreshSelectionVisuals();
                _hasLastHover = false;
            }
        }
        private void ClearHoverState()
        {
            _currentHoveredCell = null;
            _currentAimTarget = null;
            UpdateCoverHoverTarget();
            NotifyHoveredUnit(null);

            if (_hasLastHover)
            {
                _hasLastHover = false;
                _lastHoveredCoord = GridCoord.Zero;
                _bridge?.SetHoveredCoord(GridCoord.Zero, false);
                _bridge?.SetHoveredPath(null);
            }

            if (!_isExecutingAction)
            {
                _bridge?.SetSelectionVisualsSuppressed(false);
            }
        }

        private void HandleLeftClick()
        {
            GridCell clickedCell = RaycastToCell();
            if (clickedCell == null) return;

            if (_currentMode == GridInputMode.Attack)
            {
                if (_selectedUnit != null && clickedCell.IsOccupied)
                {
                    Unit target = clickedCell.Occupant;
                    if (target.IsAlive && target.Team != UnitTeam.Player && _selectedUnit.CanAct)
                    {
                        if (CombatManager.Instance != null && !CombatManager.Instance.HasLineOfSight(_selectedUnit, target))
                        {
                            Debug.Log($"[GridInputHandler] Cannot attack {target.name} - No Line of Sight!");
                            return;
                        }

                        TryAttack(_selectedUnit, target);
                        return;
                    }

                    if (target.IsAlive && target.Team == UnitTeam.Player)
                    {
                        SelectUnit(target);
                        return;
                    }
                }

                Deselect();
                return;
            }
            else
            {
                if (_selectedUnit != null && _reachableCells.Contains(clickedCell) && !clickedCell.IsOccupied)
                {
                    IssueMove(clickedCell);
                    return;
                }

                if (clickedCell.IsOccupied && clickedCell.Occupant.Team == UnitTeam.Player)
                {
                    SelectUnit(clickedCell.Occupant);
                    return;
                }

                Deselect();
            }
        }
        private void SelectUnit(Unit unit)
        {
            if (unit == null || !unit.IsAlive || unit.Movement.IsMoving) return;
            if (unit.Team != UnitTeam.Player) return;

            if (_selectedUnit != null)
                _selectedUnit.Movement.OnCellEntered -= OnUnitCellEntered;

            if (_selectedUnit != unit)
                _currentMode = GridInputMode.Movement;

            _selectedUnit = unit;
            _selectedUnit.Movement.OnCellEntered += OnUnitCellEntered;

            RefreshSelectionVisuals();
        }

        private float GetCircularDistance(GridCoord a, GridCoord b)
        {
            float dx = a.X - b.X;
            float dz = a.Z - b.Z;
            return Mathf.Sqrt((dx * dx) + (dz * dz));
        }

        private void RefreshSelectionVisuals()
        {
            if (_selectedUnit == null) return;

            if (_currentMode == GridInputMode.Attack && !_selectedUnit.CanAct)
            {
                _currentMode = GridInputMode.Movement;
            }

            _reachableCells.Clear();

            if (_selectedUnit.Movement != null && _selectedUnit.Movement.IsMoving)
            {
                _bridge?.SetAttackMode(false, 0);
                _bridge?.SetSelectedAndReachable(_selectedUnit.CurrentCoord, _reachableCells);
                _moveCostOverlay?.Clear();
                return;
            }

            if (_currentMode == GridInputMode.Movement)
            {
                _bridge?.SetAttackMode(false, 0);

                if (!_selectedUnit.CanMove || _selectedUnit.RemainingMovePoints <= 0)
                {
                    _moveCostOverlay?.Clear();
                    if (_selectedUnit.CanAct)
                        _bridge?.SetSelectedOnly(_selectedUnit.CurrentCoord);
                    else
                        _bridge?.SetSelectedAndReachable(_selectedUnit.CurrentCoord, _reachableCells);
                    return;
                }

                var reachableWithCosts = GridManager.Instance.GetReachableCellsWithCosts(
                    _selectedUnit.CurrentCoord,
                    _selectedUnit.RemainingMovePoints,
                    excludeOccupied: true,
                    startingDiagCount: _selectedUnit.Movement.DiagCount);

                _reachableCells = new List<GridCell>(reachableWithCosts.Keys);
                _bridge?.SetSelectedAndReachable(_selectedUnit.CurrentCoord, _reachableCells);
                _moveCostOverlay?.ShowCosts(reachableWithCosts, _selectedUnit.RemainingMovePoints);
            }
            else
            {
                _bridge?.SetAttackMode(true, _selectedUnit.Stats.AttackRange);
                _moveCostOverlay?.Clear();

                if (!_selectedUnit.CanAct)
                {
                    _bridge?.SetSelectedOnly(_selectedUnit.CurrentCoord);
                    return;
                }

                int range = _selectedUnit.Stats.AttackRange;
                for (int x = -range; x <= range; x++)
                {
                    for (int z = -range; z <= range; z++)
                    {
                        GridCoord c = _selectedUnit.CurrentCoord + new GridCoord(x, z);

                        if (GetCircularDistance(_selectedUnit.CurrentCoord, c) <= range + 0.5f)
                        {
                            GridCell cell = GridManager.Instance.GetCell(c);

                            if (cell != null && !cell.IsObstructed && cell.IsWalkable)
                            {
                                bool isFriendlyUnit = cell.IsOccupied && cell.Occupant != null && cell.Occupant.Team == UnitTeam.Player;
                                if (!isFriendlyUnit)
                                {
                                    _reachableCells.Add(cell);
                                }
                            }
                        }
                    }
                }

                _bridge?.SetSelectedAndReachable(_selectedUnit.CurrentCoord, _reachableCells);
            }
        }

        private void IssueMove(GridCell targetCell)
        {
            if (_selectedUnit == null || !_selectedUnit.CanMove) return;

            _bridge?.SetHoveredPath(null);
            _bridge?.SetSelectedAndReachable(GridCoord.Zero, null);
            _bridge?.SetHoveredCoord(GridCoord.Zero, false);
            _reachableCells.Clear();
            _hasLastHover = false;

            var moveAction = new MoveAction(targetCell);
            StartCoroutine(ExecuteActionCoroutine(moveAction, _selectedUnit));
        }

        private void TryAttack(Unit attacker, Unit defender)
        {
            float dist = GetCircularDistance(attacker.CurrentCoord, defender.CurrentCoord);
            if (dist > attacker.Stats.AttackRange + 0.5f)
            {
                Debug.Log($"[GridInputHandler] Target out of range.");
                return;
            }

            var attackAction = new AttackAction(defender);
            StartCoroutine(ExecuteActionCoroutine(attackAction, attacker));
        }

        private IEnumerator ExecuteActionCoroutine(CombatAction action, Unit actor)
        {
            _isExecutingAction = true;

            bool actionComplete = false;
            StartCoroutine(action.Execute(actor, () => actionComplete = true));
            yield return new WaitUntil(() => actionComplete);

            if (actor != null)
            {
                var movement = actor.Movement;
                if (movement != null)
                    yield return new WaitUntil(() => !movement.IsMoving || !actor.IsAlive);
            }

            _isExecutingAction = false;
            _hasLastHover = false;

            if (actor != null && actor.IsAlive)
                SelectUnit(actor);
            else
                Deselect();
        }
        private void Deselect()
        {
            if (_selectedUnit != null)
                _selectedUnit.Movement.OnCellEntered -= OnUnitCellEntered;

            if (_lastPreviewedUnit != null)
            {
                UnitHealthBarManager.Instance?.ClearDamagePreview(_lastPreviewedUnit);
                _lastPreviewedUnit = null;
            }

            _selectedUnit = null;
            _currentMode = GridInputMode.Movement;
            _reachableCells.Clear();
            _hasLastHover = false;
            _currentHoveredCell = null;

            _bridge?.SetAttackMode(false, 0);
            _bridge?.ClearAllState();
            _bridge?.SetSelectionVisualsSuppressed(false);
            NotifyHoveredUnit(null);

            _moveCostOverlay?.Clear();
            _currentAimTarget = null;
        }


        private void HandleHover()
        {
            _currentHoveredCell = RaycastToCell();

            if (_currentHoveredCell != null &&
                (_currentHoveredCell.IsObstructed || !_currentHoveredCell.IsWalkable))
            {
                _currentHoveredCell = null;
            }

            UpdateCoverHoverTarget();

            Unit hoveredUnit = _currentHoveredCell != null && _currentHoveredCell.IsOccupied
                ? _currentHoveredCell.Occupant
                : null;

            UpdateDamagePreview(hoveredUnit);
            NotifyHoveredUnit(hoveredUnit);

            bool suppressGrid = _isExecutingAction;
            _bridge?.SetSelectionVisualsSuppressed(suppressGrid);

            if (_currentHoveredCell == null)
            {
                if (_hasLastHover)
                {
                    _hasLastHover = false;
                    _bridge?.SetHoveredCoord(GridCoord.Zero, false);
                    _bridge?.SetHoveredPath(null);
                }
                return;
            }

            if (_hasLastHover && _currentHoveredCell.Coord == _lastHoveredCoord) return;

            _lastHoveredCoord = _currentHoveredCell.Coord;
            _hasLastHover = true;

            _bridge?.SetHoveredCoord(_currentHoveredCell.Coord, true);

            if (_currentMode == GridInputMode.Movement && !_isExecutingAction && _selectedUnit != null && _selectedUnit.CanMove && _reachableCells.Contains(_currentHoveredCell) && !_currentHoveredCell.IsOccupied)
            {
                var path = Pathfinder.FindPath(
                    _selectedUnit.CurrentCoord,
                    _currentHoveredCell.Coord,
                    GridManager.Instance,
                    blockOccupied: true,
                    startingDiagCount: _selectedUnit.Movement.DiagCount);

                if (path != null && path.Count > 1) _bridge?.SetHoveredPath(path);
                else _bridge?.SetHoveredPath(null);
            }
            else
            {
                _bridge?.SetHoveredPath(null);
            }
        }

        private void UpdateCoverHoverTarget()
        {
            GridCell coverTarget = null;

            if (!_isExecutingAction && _currentHoveredCell != null && (_selectedUnit == null || !_selectedUnit.Movement.IsMoving))
                coverTarget = _currentHoveredCell;

            _bridge?.SetCoverHoverTarget(coverTarget);
        }

        private void UpdateDamagePreview(Unit hoveredUnit)
        {
            if (_currentMode != GridInputMode.Attack || _isExecutingAction)
            {
                if (_lastPreviewedUnit != null)
                {
                    UnitHealthBarManager.Instance?.ClearDamagePreview(_lastPreviewedUnit);
                    _lastPreviewedUnit = null;
                }
                _currentAimTarget = null;
                return;
            }

            if (_lastPreviewedUnit != null && _lastPreviewedUnit != hoveredUnit)
            {
                UnitHealthBarManager.Instance?.ClearDamagePreview(_lastPreviewedUnit);
                _lastPreviewedUnit = null;
            }

            if (hoveredUnit == null || _selectedUnit == null || !_selectedUnit.CanAct)
            {
                _currentAimTarget = null;
                return;
            }

            if (hoveredUnit.Team == UnitTeam.Player || !hoveredUnit.IsAlive)
            {
                _currentAimTarget = null;
                return;
            }

            float dist = GetCircularDistance(_selectedUnit.CurrentCoord, hoveredUnit.CurrentCoord);
            if (dist > _selectedUnit.Stats.AttackRange + 0.5f)
            {
                _currentAimTarget = null;
                return;
            }

            if (CombatManager.Instance != null)
            {
                if (!CombatManager.Instance.HasLineOfSight(_selectedUnit, hoveredUnit))
                {
                    _currentAimTarget = null;
                    return;
                }

                _currentAimTarget = hoveredUnit;

                CombatManager.Instance.PreviewDamage(
                    _selectedUnit, hoveredUnit, out int shieldDmg, out int hpDmg);

                float hitChance = CombatManager.Instance.PreviewHitChance(_selectedUnit, hoveredUnit);

                UnitHealthBarManager.Instance?.ShowDamagePreview(
                    hoveredUnit, hpDmg, shieldDmg, hitChance);

                _lastPreviewedUnit = hoveredUnit;
            }
        }

        private void NotifyHoveredUnit(Unit unit)
        {
            if (_lastNotifiedHoveredUnit == unit) return;
            _lastNotifiedHoveredUnit = unit;
            UnitHealthBarManager.Instance?.NotifyHoveredUnit(unit);
        }

        private void OnUnitCellEntered(GridCell cell) => _bridge?.NotifyUnitEnteredCell(cell.Coord);

        private GridCell RaycastToCell()
        {
            if (GridManager.Instance == null) return null;
            Ray ray = _camera.ScreenPointToRay(Input.mousePosition);

            if (!Physics.Raycast(ray, out RaycastHit hit, _raycastDistance, _gridLayerMask))
                return null;

            Unit unit = hit.collider.GetComponentInParent<Unit>()
                     ?? hit.transform.root.GetComponentInChildren<Unit>();
            if (unit != null && unit.IsAlive) return unit.CurrentCell;

            float gridFloorY = GridManager.Instance.Settings.OriginPosition.y;
            float heightGuard = GridManager.Instance.Settings.CellSize * 0.6f;
            if (hit.point.y - gridFloorY > heightGuard)
                return null;

            return GridManager.Instance.GetCellAtWorldPos(hit.point);
        }
    }
}