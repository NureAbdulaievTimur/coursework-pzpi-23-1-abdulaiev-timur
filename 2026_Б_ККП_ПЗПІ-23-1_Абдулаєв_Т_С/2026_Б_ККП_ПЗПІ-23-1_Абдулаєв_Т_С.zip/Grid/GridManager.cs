using System;
using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    public class GridManager : MonoBehaviour
    {
        public static GridManager Instance { get; private set; }

        [Header("Configuration")]
        [SerializeField] private GridSettings _settings;
        public GridSettings Settings => _settings;

        private GridCell[,] _cells;
        public bool IsInitialized { get; private set; }

        public event Action OnGridInitialized;
        public event Action<GridCell> OnCellChanged;

        private void Awake()
        {
            if (Instance != null && Instance != this)
            {
                Debug.LogWarning("[GridManager] Duplicate instance destroyed.", this);
                Destroy(gameObject);
                return;
            }
            Instance = this;

            if (_settings == null)
            {
                Debug.LogError("[GridManager] GridSettings not assigned!", this);
                return;
            }
            InitializeGrid();
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public void InitializeGrid()
        {
            _cells = new GridCell[_settings.Width, _settings.Height];
            for (int x = 0; x < _settings.Width; x++)
                for (int z = 0; z < _settings.Height; z++)
                {
                    var coord = new GridCoord(x, z);
                    var cell = new GridCell(coord, _settings.CoordToWorld(coord));
                    cell.OnCellStateChanged += HandleCellStateChanged;
                    _cells[x, z] = cell;
                }
            IsInitialized = true;
            OnGridInitialized?.Invoke();
            Debug.Log($"[GridManager] {_settings.Width}x{_settings.Height} grid ready.");
        }

        public GridCell GetCell(GridCoord coord)
        {
            if (!_settings.IsValidCoord(coord)) return null;
            return _cells[coord.X, coord.Z];
        }

        public GridCell GetCellAtWorldPos(Vector3 worldPos)
            => GetCell(_settings.WorldToCoord(worldPos));

        public bool TryGetCell(GridCoord coord, out GridCell cell)
        {
            cell = GetCell(coord);
            return cell != null;
        }

        public List<GridCell> GetWalkableNeighbors(
            GridCell cell,
            bool includeDiagonals = true,
            bool blockOccupied = false,
            GridCoord occupiedExemptCoord = default)
        {
            var neighbors = new List<GridCell>(8);

            foreach (var dir in GridCoord.CardinalDirections)
            {
                var n = GetCell(cell.Coord + dir);
                if (n != null && !n.IsBlocking && IsPassable(n, blockOccupied, occupiedExemptCoord))
                    neighbors.Add(n);
            }

            if (includeDiagonals && _settings.AllowDiagonalMovement)
            {
                foreach (var dir in GridCoord.DiagonalDirections)
                {
                    var n = GetCell(cell.Coord + dir);
                    if (n == null || n.IsBlocking) continue;
                    if (_settings.BlockDiagonalCornering && IsDiagonalCornerBlocked(cell.Coord, dir, blockOccupied, occupiedExemptCoord))
                        continue;
                    if (!IsPassable(n, blockOccupied, occupiedExemptCoord))
                        continue;
                    neighbors.Add(n);
                }
            }

            return neighbors;
        }

        private bool IsPassable(GridCell cell, bool blockOccupied, GridCoord exemptCoord)
        {
            if (!blockOccupied) return true;
            if (!cell.IsOccupied) return true;
            return cell.Coord == exemptCoord;
        }

        private bool IsDiagonalCornerBlocked(GridCoord from, GridCoord diagonalDir,
                                              bool blockOccupied = false, GridCoord exemptCoord = default)
        {
            var a = GetCell(from + new GridCoord(diagonalDir.X, 0));
            var b = GetCell(from + new GridCoord(0, diagonalDir.Z));
            return (a == null || a.IsBlocking || (blockOccupied && a.IsOccupied && a.Coord != exemptCoord))
                || (b == null || b.IsBlocking || (blockOccupied && b.IsOccupied && b.Coord != exemptCoord));
        }

        public List<GridCell> GetReachableCells(GridCoord origin, int movePointsBudget, bool excludeOccupied = true, int startingDiagCount = 0)
        {
            var reachableWithCosts = GetReachableCellsWithCosts(origin, movePointsBudget, excludeOccupied, startingDiagCount);
            return new List<GridCell>(reachableWithCosts.Keys);
        }

        public Dictionary<GridCell, int> GetReachableCellsWithCosts(GridCoord origin, int movePointsBudget, bool excludeOccupied = true, int startingDiagCount = 0)
        {
            var reachable = new Dictionary<GridCell, int>();
            if (movePointsBudget <= 0) return reachable;

            var visited = new Dictionary<(GridCoord, int), int>();
            var pq = new ReachabilityHeap();

            int startParity = startingDiagCount % 2;
            pq.Insert(0, startParity, origin);
            visited[(origin, startParity)] = 0;

            while (pq.Count > 0)
            {
                var (currentCost, currentParity, current) = pq.ExtractMin();

                if (visited.TryGetValue((current, currentParity), out int bestCost) && currentCost > bestCost)
                    continue;

                foreach (var dir in GridCoord.AllDirections)
                {
                    if (!_settings.AllowDiagonalMovement && IsDiagonalDir(dir)) continue;

                    var nc = current + dir;
                    if (!_settings.IsValidCoord(nc)) continue;

                    var cell = GetCell(nc);
                    if (cell == null || cell.IsBlocking || (cell.IsOccupied && nc != origin)) continue;
                    if (_settings.BlockDiagonalCornering && IsDiagonalDir(dir) && IsDiagonalCornerBlocked(current, dir, true, nc)) continue;

                    bool isDiag = IsDiagonalDir(dir);
                    int nextParity = isDiag ? (1 - currentParity) : currentParity;

                    int stepBase = isDiag ? (currentParity == 0 ? 1 : 2) : 1;
                    int stepCost = stepBase * _settings.StraightMoveCost;
                    int totalCost = currentCost + Mathf.RoundToInt(stepCost * cell.MoveCostModifier);

                    if (totalCost > movePointsBudget) continue;

                    if (!visited.TryGetValue((nc, nextParity), out int prevCost) || totalCost < prevCost)
                    {
                        visited[(nc, nextParity)] = totalCost;
                        pq.Insert(totalCost, nextParity, nc);

                        if (!excludeOccupied || !cell.IsOccupied)
                        {
                            if (!reachable.TryGetValue(cell, out var known) || totalCost < known)
                                reachable[cell] = totalCost;
                        }
                    }
                }
            }
            return reachable;
        }

        private sealed class ReachabilityHeap
        {
            private readonly List<(int cost, int parity, GridCoord coord)> _data = new();
            public int Count => _data.Count;
            public void Insert(int cost, int parity, GridCoord coord) { _data.Add((cost, parity, coord)); SiftUp(_data.Count - 1); }
            public (int cost, int parity, GridCoord coord) ExtractMin() { var min = _data[0]; int last = _data.Count - 1; _data[0] = _data[last]; _data.RemoveAt(last); if (_data.Count > 0) SiftDown(0); return min; }
            private void SiftUp(int i) { while (i > 0) { int p = (i - 1) / 2; if (_data[i].cost < _data[p].cost) Swap(i, p); else break; i = p; } }
            private void SiftDown(int i) { while (true) { int l = 2 * i + 1, r = 2 * i + 2, s = i; if (l < _data.Count && _data[l].cost < _data[s].cost) s = l; if (r < _data.Count && _data[r].cost < _data[s].cost) s = r; if (s == i) break; Swap(i, s); i = s; } }
            private void Swap(int a, int b) => (_data[a], _data[b]) = (_data[b], _data[a]);
        }

        private static bool IsDiagonalDir(GridCoord d) => d.X != 0 && d.Z != 0;


        public CoverType GetCoverBetween(GridCoord unitCoord, GridCoord attackerCoord)
        {
            var unitCell = GetCell(unitCoord);

            if (unitCell == null || unitCell.CoverSlots == null || unitCell.CoverSlots.Count == 0)
                return CoverType.None;

            Vector2 dirToAttacker = new Vector2(
                attackerCoord.X - unitCoord.X,
                attackerCoord.Z - unitCoord.Z
            ).normalized;

            CoverType bestCover = CoverType.None;

            float intersectionThreshold = Mathf.Cos(40f * Mathf.Deg2Rad);

            foreach (var slot in unitCell.CoverSlots)
            {
                Vector2 dirToCover = new Vector2(slot.Key.X, slot.Key.Z).normalized;

                float dotProduct = Vector2.Dot(dirToAttacker, dirToCover);

                if (dotProduct >= intersectionThreshold)
                {
                    if (slot.Value == CoverType.Full)
                    {
                        return CoverType.Full;
                    }

                    bestCover = CoverType.Half;
                }
            }

            return bestCover;
        }

        public IReadOnlyDictionary<GridCoord, CoverType> GetCoverSlots(GridCoord coord)
            => GetCell(coord)?.CoverSlots;
        public void RegisterObstruction(IEnumerable<GridCoord> coords)
        {
            foreach (var c in coords) GetCell(c)?.AddObstruction();
        }

        public void UnregisterObstruction(IEnumerable<GridCoord> coords)
        {
            foreach (var c in coords) GetCell(c)?.RemoveObstruction();
        }
        public void RegisterCoverSlot(GridCoord cellCoord, GridCoord dirToObstacle, CoverType type)
            => GetCell(cellCoord)?.AddCoverSlot(dirToObstacle, type);

        public void UnregisterCoverSlot(GridCoord cellCoord, GridCoord dirToObstacle)
            => GetCell(cellCoord)?.RemoveCoverSlot(dirToObstacle);
        public Vector3 CoordToWorld(GridCoord coord) => _settings.CoordToWorld(coord);
        public GridCoord WorldToCoord(Vector3 worldPos) => _settings.WorldToCoord(worldPos);
        public void ClearAllHighlights()
        {
            if (_cells == null) return;
            foreach (var cell in _cells) cell.ClearHighlights();
        }

        public void SetRectangleUnwalkable(GridCoord min, GridCoord max)
        {
            for (int x = min.X; x <= max.X; x++)
                for (int z = min.Z; z <= max.Z; z++)
                    GetCell(new GridCoord(x, z))?.SetWalkable(false);
        }
        private void HandleCellStateChanged(GridCell cell) => OnCellChanged?.Invoke(cell);

#if UNITY_EDITOR
        private void OnDrawGizmos()
        {
            if (_settings == null || !_settings.ShowGridGizmos) return;

            float cs = _settings.CellSize;
            Vector3 origin = _settings.OriginPosition + Vector3.up * _settings.CellHeightOffset;

            for (int x = 0; x < _settings.Width; x++)
                for (int z = 0; z < _settings.Height; z++)
                {
                    Vector3 center = origin + new Vector3(x * cs + cs * 0.5f, 0f, z * cs + cs * 0.5f);
                    GridCell cell = _cells?[x, z];

                    Color fill = cell == null ? Color.gray
                               : cell.IsObstructed ? new Color(0.8f, 0.4f, 0f, 0.4f)
                               : !cell.IsWalkable ? _settings.UnwalkableColor
                                                       : _settings.WalkableColor;
                    Gizmos.color = fill;
                    Gizmos.DrawCube(center, new Vector3(cs * 0.95f, 0.01f, cs * 0.95f));

                    Gizmos.color = _settings.GridLineColor;
                    Gizmos.DrawWireCube(center, new Vector3(cs, 0.02f, cs));

                    if (cell != null && cell.HasAnyCover)
                    {
                        foreach (var slot in cell.CoverSlots)
                        {
                            Gizmos.color = slot.Value == CoverType.Full
                                ? new Color(0f, 1f, 0f, 0.8f)
                                : new Color(1f, 1f, 0f, 0.8f);
                            Vector3 arrowEnd = center + new Vector3(slot.Key.X, 0, slot.Key.Z) * (cs * 0.4f);
                            Gizmos.DrawLine(center, arrowEnd);
                            Gizmos.DrawSphere(arrowEnd, cs * 0.06f);
                        }
                    }
                }
        }
#endif
    }
}