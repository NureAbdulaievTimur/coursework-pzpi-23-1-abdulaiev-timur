using System;
using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    [CreateAssetMenu(fileName = "AIBehaviorProfile", menuName = "CombatGrid/AI Behavior Profile")]
    public class AIBehaviorProfile : ScriptableObject
    {
        [Header("Preset")]
        [Tooltip("Selecting a preset overwrites the weights below at runtime.")]
        public AIPreset Preset = AIPreset.Aggressive;

        [Tooltip("Automatically apply the selected preset when this asset is loaded / enabled.")]
        public bool AutoApplyPreset = true;

        [Header("Weights")]
        public AIWeights Weights = new();

        [Header("Phase Overrides")]
        [Tooltip("Conditional weight changes applied during combat.")]
        public List<AIPhaseOverride> PhaseOverrides = new();

        [Header("Timing")]
        [Tooltip("Seconds to pause between individual unit actions during this team's phase.")]
        [Min(0f)] public float DelayBetweenUnitActions = 0.4f;

        [Tooltip("Seconds to pause between individual steps within one unit's turn.")]
        [Min(0f)] public float DelayBetweenSteps = 0.3f;

        [NonSerialized] private AIWeights _effectiveWeights;
        public AIWeights EffectiveWeights => _effectiveWeights ?? Weights;

        private void OnEnable()
        {
            ResetOverrides();
            if (AutoApplyPreset && Preset != AIPreset.Custom)
                ApplyPreset(Preset);
            _effectiveWeights = Weights;
        }

        public void ApplyPreset(AIPreset preset)
        {
            Preset = preset;
            Weights = AIWeights.BuildPreset(preset);
            _effectiveWeights = Weights;
        }

        public AIWeights EvaluateOverrides(Unit self, UnitTeam selfTeam)
        {
            _effectiveWeights = Weights;

            if (TurnManager.Instance == null) return _effectiveWeights;

            foreach (var ov in PhaseOverrides)
            {
                if (ov.Persistent && ov.HasTriggered)
                {
                    _effectiveWeights = ApplyOverride(_effectiveWeights, ov);
                    continue;
                }

                if (CheckCondition(ov, self, selfTeam))
                {
                    ov.HasTriggered = true;
                    _effectiveWeights = ApplyOverride(_effectiveWeights, ov);
                }
            }

            return _effectiveWeights;
        }

        public void ResetOverrides()
        {
            foreach (var ov in PhaseOverrides)
                ov.HasTriggered = false;
            _effectiveWeights = Weights;
        }

        private static AIWeights ApplyOverride(AIWeights base_, AIPhaseOverride ov)
        {
            if (ov.SwitchToPreset != AIPreset.Custom)
                return AIWeights.BuildPreset(ov.SwitchToPreset);
            return base_ + ov.WeightDeltas;
        }

        private static bool CheckCondition(AIPhaseOverride ov, Unit self, UnitTeam selfTeam)
        {
            var tm = TurnManager.Instance;
            switch (ov.Condition)
            {
                case AIPhaseCondition.SelfBelowHPPercent:
                    return self.HealthPercent < ov.ConditionThreshold;

                case AIPhaseCondition.AllyBelowHPPercent:
                    foreach (var ally in tm.GetUnits(selfTeam))
                        if (ally.IsAlive && ally.HealthPercent < ov.ConditionThreshold)
                            return true;
                    return false;

                case AIPhaseCondition.AllyCountBelow:
                    return tm.GetUnits(selfTeam).Count < (int)ov.ConditionThreshold;

                case AIPhaseCondition.EnemyCountBelow:
                    int enemies = 0;
                    foreach (UnitTeam t in Enum.GetValues(typeof(UnitTeam)))
                        if (t != selfTeam) enemies += tm.GetUnits(t).Count;
                    return enemies < (int)ov.ConditionThreshold;

                case AIPhaseCondition.RoundGreaterThan:
                    return tm.CurrentRound > (int)ov.ConditionThreshold;

                default: return false;
            }
        }
    }
}