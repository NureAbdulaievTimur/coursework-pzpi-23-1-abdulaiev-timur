using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    public class UnitMovement : MonoBehaviour
    {
        [Header("Speed Control")]
        [SerializeField] private bool _useStatsSpeed = false;
        [SerializeField] private float _customMaxSpeed = 6.0f;
        [SerializeField] private float _minSpeed = 1.5f;
        [SerializeField] private float _accelerationDistance = 1.0f;
        [SerializeField] private float _decelerationDistance = 1.5f;
        [SerializeField] private AnimationCurve _speedEaseCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

        [Header("Corner Slowdown")]
        [SerializeField] private bool _slowAtCorners = true;
        [SerializeField] private float _cornerSlowdownDistance = 0.5f;
        [Range(0.1f, 1f)][SerializeField] private float _cornerSpeedMultiplier = 0.4f;
        [SerializeField] private float _maxTurnAngle = 90f;

        [Header("Step Oscillation")]
        [SerializeField] private bool _useStepOscillation = true;
        [SerializeField] private float _stepRate = 2.5f;
        [Range(0f, 1f)][SerializeField] private float _stepOscillationStrength = 0.6f;
        [SerializeField]
        private AnimationCurve _stepVelocityCurve = new AnimationCurve(
            new Keyframe(0f, 1f), new Keyframe(0.2f, 1.25f), new Keyframe(0.5f, 1f),
            new Keyframe(0.8f, 0.8f), new Keyframe(1f, 1f));

        [Header("Animation")]
        [SerializeField] private Animator _animator;
        [SerializeField] private float _startMoveDelay = 0.2f;
        [SerializeField] private float _earlyStopDistance = 1.2f;

        [Header("Movement Rotation (While Running)")]
        [SerializeField] private bool _faceMovementDirection = true;
        [SerializeField] private float _moveMinRotationSpeed = 360f;
        [SerializeField] private float _moveMaxRotationSpeed = 720f;
        [SerializeField] private float _moveMaxRotationSpeedAngle = 180f;
        [SerializeField] private AnimationCurve _moveRotationEaseCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);

        [Header("Stationary Rotation (Aiming/Shooting)")]
        [SerializeField] private float _aimMinRotationSpeed = 180f;
        [SerializeField] private float _aimMaxRotationSpeed = 540f;
        [SerializeField] private float _aimMaxRotationSpeedAngle = 180f;
        [SerializeField] private AnimationCurve _aimRotationEaseCurve = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);
        [SerializeField] private float _turnAnimPreDelay = 0.15f;

        [Header("Cover Shooting")]
        [SerializeField] private float _standUpDelay = 0.4f;

        private Unit _unit;
        private Coroutine _moveCoroutine;
        private Coroutine _rotationCoroutine;
        private float _stepCycleProgress = 0f;

        private int _diagCount = 0;
        public int DiagCount => _diagCount;

        private static readonly int IsMovingHash = Animator.StringToHash("IsMoving");
        private static readonly int IsCrouchingHash = Animator.StringToHash("IsCrouching");
        private static readonly int HitHash = Animator.StringToHash("Hit");
        private static readonly int CrouchHitHash = Animator.StringToHash("CrouchHit");
        private static readonly int DieHash = Animator.StringToHash("Die");
        private static readonly int DodgeHash = Animator.StringToHash("Dodge");

        public bool IsMoving => _moveCoroutine != null;
        public List<GridCell> CurrentPath { get; private set; }

        public float StandUpDelay => _standUpDelay;
        public bool IsCrouching => _animator != null && _animator.GetBool(IsCrouchingHash);

        public event Action<List<GridCell>> OnMoveStarted;
        public event Action<GridCell> OnCellEntered;
        public event Action<GridCoord> OnMoveCompleted;
        public event Action<GridCoord> OnPathNotFound;
        public event Action OnMoveStopping;

        private void Awake()
        {
            _unit = GetComponent<Unit>();
            if (_animator == null) _animator = GetComponentInChildren<Animator>();
        }

        private void OnEnable()
        {
            if (_unit == null) _unit = GetComponent<Unit>();

            _unit.OnHPDamageTaken += HandleHPDamage;
            _unit.OnShieldDamageTaken += HandleShieldDamage;
            _unit.OnUnitDied += HandleDeath;
            _unit.OnAttackEvaded += HandleAttackEvaded;
        }

        private void OnDisable()
        {
            if (_unit != null)
            {
                _unit.OnHPDamageTaken -= HandleHPDamage;
                _unit.OnShieldDamageTaken -= HandleShieldDamage;
                _unit.OnUnitDied -= HandleDeath;
                _unit.OnAttackEvaded -= HandleAttackEvaded;
            }
        }

        private void HandleHPDamage(Unit unit, int damage)
        {
            if (_animator == null || !unit.IsAlive) return;

            int triggerToUse = IsCrouching ? CrouchHitHash : HitHash;
            _animator.SetTrigger(triggerToUse);

            StartCoroutine(ResetTriggerAfterDelay(triggerToUse, 0.5f));

            Debug.Log($"[UnitMovement] {unit.name} played Hit reaction (Crouched: {IsCrouching})");
        }

        private void HandleShieldDamage(Unit unit, int damage)
        {
            PlayShieldEffect();
        }

        private void PlayShieldEffect()
        {
            Debug.Log($"[UnitMovement] {gameObject.name} Shield absorbed damage - VFX Placeholder");
        }

        private void HandleDeath(Unit unit)
        {
            if (_animator == null) return;

            if (_moveCoroutine != null)
            {
                StopCoroutine(_moveCoroutine);
                _moveCoroutine = null;
            }

            RagdollManager ragdoll = GetComponent<RagdollManager>();
            if (ragdoll != null && ragdoll.useRagdollOnDeath)
            {
                ragdoll.ToggleRagdoll(true);
            }
            else
            {
                _animator.SetTrigger(DieHash);
                _animator.SetBool(IsMovingHash, false);
            }

            Debug.Log($"[UnitMovement] {unit.name} died.");
        }

        private void HandleAttackEvaded(Unit unit)
        {
            if (_animator == null || IsCrouching) return;

            _animator.SetTrigger(DodgeHash);
            StartCoroutine(ResetTriggerAfterDelay(DodgeHash, 0.5f));
        }

        private IEnumerator ResetTriggerAfterDelay(int triggerHash, float delay)
        {
            yield return new WaitForSeconds(delay);
            if (_animator != null) _animator.ResetTrigger(triggerHash);
        }

        public void ResetDiagCount() => _diagCount = 0;

        public bool MoveTo(GridCoord targetCoord)
        {
            if (!ValidateCanMove()) return false;

            var grid = GridManager.Instance;
            List<GridCell> path = Pathfinder.FindPath(_unit.CurrentCoord, targetCoord, grid, blockOccupied: true, startingDiagCount: _diagCount);

            int pathCost = Pathfinder.CalculatePathCost(path, grid.Settings, _diagCount);

            if (path == null || path.Count <= 1 || pathCost > _unit.RemainingMovePoints)
            {
                OnPathNotFound?.Invoke(targetCoord);
                return false;
            }

            StartMovement(path, pathCost);
            return true;
        }

        public bool MoveAlongPath(List<GridCell> path)
        {
            if (!ValidateCanMove()) return false;
            if (path == null || path.Count <= 1) return false;

            int pathCost = Pathfinder.CalculatePathCost(path, GridManager.Instance.Settings, _diagCount);
            StartMovement(path, pathCost);
            return true;
        }

        public void CancelMovement()
        {
            if (_moveCoroutine == null) return;
            StopCoroutine(_moveCoroutine);
            _moveCoroutine = null;
            CurrentPath = null;

            if (_animator != null) _animator.SetBool(IsMovingHash, false);

            RestoreCoverStance();
            _unit.SetState(UnitState.Idle);
            OnMoveCompleted?.Invoke(_unit.CurrentCoord);
        }

        public void SetCrouching(bool isCrouching)
        {
            if (_animator != null) _animator.SetBool(IsCrouchingHash, isCrouching);
        }

        public void RestoreCoverStance()
        {
            if (GridManager.Instance == null || _unit == null) return;
            var coverSlots = GridManager.Instance.GetCoverSlots(_unit.CurrentCoord);
            SetCrouching(coverSlots != null && coverSlots.Count > 0);
        }

        private bool ValidateCanMove()
        {
            return GridManager.Instance != null && _unit.IsAlive && !IsMoving && _unit.CanMove;
        }

        private void StartMovement(List<GridCell> path, int pathCost)
        {
            CurrentPath = path;
            _stepCycleProgress = 0f;

            _unit.TrySpendMovePoints(pathCost);

            for (int i = 1; i < path.Count; i++)
            {
                if (GridCoord.IsDiagonal(path[i - 1].Coord, path[i].Coord))
                    _diagCount++;
            }

            _unit.SetState(UnitState.Moving);
            OnMoveStarted?.Invoke(path);
            _moveCoroutine = StartCoroutine(MoveCoroutine(path));
        }

        private void SetCrouchingForDestination(GridCoord destCoord)
        {
            if (GridManager.Instance == null) return;
            var coverSlots = GridManager.Instance.GetCoverSlots(destCoord);
            SetCrouching(coverSlots != null && coverSlots.Count > 0);
        }

        private IEnumerator MoveCoroutine(List<GridCell> path)
        {
            float totalPathDistance = 0f;
            for (int i = 0; i < path.Count - 1; i++)
                totalPathDistance += Vector3.Distance(path[i].WorldPos, path[i + 1].WorldPos);

            float actualEarlyStopDistance = Mathf.Min(_earlyStopDistance, totalPathDistance * 0.4f);
            GridCoord finalDestCoord = path[path.Count - 1].Coord;

            int stopTriggerSegment = 1;
            float stopTriggerFraction = 0f;
            {
                float remaining = actualEarlyStopDistance;
                for (int i = path.Count - 1; i >= 1; i--)
                {
                    float segLen = Vector3.Distance(path[i - 1].WorldPos, path[i].WorldPos);
                    if (remaining <= segLen)
                    {
                        stopTriggerSegment = i;
                        stopTriggerFraction = 1f - (remaining / segLen);
                        break;
                    }
                    remaining -= segLen;
                }
            }

            if (_animator != null) _animator.SetBool(IsMovingHash, true);

            if (_faceMovementDirection && path.Count > 1)
            {
                Vector3 firstDir = (path[1].WorldPos - transform.position).normalized;
                if (_rotationCoroutine != null) StopCoroutine(_rotationCoroutine);
                _rotationCoroutine = StartCoroutine(RotateTowards(firstDir));
            }

            yield return new WaitForSeconds(_startMoveDelay);

            GridSettings settings = GridManager.Instance.Settings;
            float maxSpeed = _useStatsSpeed ? _unit.Stats.MoveSpeed : _customMaxSpeed;
            float distanceTraveled = 0f;
            bool hasTriggeredStop = false;
            float previousCornerMultiplier = 1f;

            for (int i = 1; i < path.Count; i++)
            {
                GridCell nextCell = path[i];

                _unit.CurrentCell?.ClearOccupant();
                nextCell.SetOccupant(_unit);
                _unit.SetCurrentCoord(nextCell.Coord);

                Vector3 startPos = transform.position;
                Vector3 targetPos = nextCell.WorldPos;
                float segmentDistance = Vector3.Distance(startPos, targetPos);
                float segmentTraveled = 0f;

                float nextCornerMultiplier = 1f;
                if (_slowAtCorners && i < path.Count - 1)
                {
                    Vector3 currentDir = (path[i].WorldPos - path[i - 1].WorldPos).normalized;
                    Vector3 nextDir = (path[i + 1].WorldPos - path[i].WorldPos).normalized;
                    float turnSeverity = Mathf.Clamp01(Vector3.Angle(currentDir, nextDir) / _maxTurnAngle);
                    nextCornerMultiplier = Mathf.Lerp(1f, _cornerSpeedMultiplier, turnSeverity);
                }

                if (_faceMovementDirection)
                {
                    Vector3 dir = (targetPos - transform.position).normalized;
                    if (dir != Vector3.zero)
                    {
                        if (_rotationCoroutine != null) StopCoroutine(_rotationCoroutine);
                        _rotationCoroutine = StartCoroutine(RotateTowards(dir));
                    }
                }

                while (segmentTraveled < segmentDistance)
                {
                    if (!hasTriggeredStop)
                    {
                        bool onTriggerSegment = i == stopTriggerSegment;
                        bool pastTriggerSegment = i > stopTriggerSegment;
                        bool reachedFraction = onTriggerSegment && segmentDistance > 0f &&
                                                 (segmentTraveled / segmentDistance) >= stopTriggerFraction;

                        if (reachedFraction || pastTriggerSegment)
                        {
                            hasTriggeredStop = true;
                            if (_animator != null) _animator.SetBool(IsMovingHash, false);
                            SetCrouchingForDestination(finalDestCoord);
                            OnMoveStopping?.Invoke();
                        }
                    }

                    float distanceToEnd = totalPathDistance - distanceTraveled;
                    float speedMult = 1f;

                    if (_accelerationDistance > 0f && distanceTraveled < _accelerationDistance)
                        speedMult = _speedEaseCurve.Evaluate(distanceTraveled / _accelerationDistance);
                    else if (_decelerationDistance > 0f && distanceToEnd < _decelerationDistance)
                        speedMult = _speedEaseCurve.Evaluate(distanceToEnd / _decelerationDistance);

                    float cornerMult = 1f;
                    if (_slowAtCorners)
                    {
                        float distanceToNextCorner = segmentDistance - segmentTraveled;
                        float multFromLastCorner = segmentTraveled < _cornerSlowdownDistance
                            ? Mathf.Lerp(previousCornerMultiplier, 1f, segmentTraveled / _cornerSlowdownDistance) : 1f;
                        float multToNextCorner = distanceToNextCorner < _cornerSlowdownDistance
                            ? Mathf.Lerp(nextCornerMultiplier, 1f, distanceToNextCorner / _cornerSlowdownDistance) : 1f;
                        cornerMult = Mathf.Min(multFromLastCorner, multToNextCorner);
                    }

                    float stepOscMult = 1f;
                    if (_useStepOscillation && _stepRate > 0f)
                    {
                        _stepCycleProgress += Time.deltaTime * _stepRate;
                        float curveVal = _stepVelocityCurve.Evaluate(_stepCycleProgress % 1f);
                        stepOscMult = Mathf.Lerp(1f, curveVal, _stepOscillationStrength);
                    }

                    float baseSpeed = Mathf.Lerp(_minSpeed, maxSpeed, speedMult);
                    float currentSpeed = Mathf.Max(baseSpeed * cornerMult * stepOscMult, _minSpeed * 0.5f);
                    float step = Mathf.Min(currentSpeed * Time.deltaTime, segmentDistance - segmentTraveled);

                    transform.position = Vector3.MoveTowards(transform.position, targetPos, step);
                    segmentTraveled += step;
                    distanceTraveled += step;

                    yield return null;
                }

                transform.position = targetPos;
                OnCellEntered?.Invoke(nextCell);
                previousCornerMultiplier = nextCornerMultiplier;
            }

            if (!hasTriggeredStop)
            {
                if (_animator != null) _animator.SetBool(IsMovingHash, false);
                SetCrouchingForDestination(finalDestCoord);
                OnMoveStopping?.Invoke();
            }

            _moveCoroutine = null;
            CurrentPath = null;
            _unit.SetState(UnitState.Idle);
            OnMoveCompleted?.Invoke(_unit.CurrentCoord);
        }

        private IEnumerator RotateTowards(Vector3 direction)
        {
            direction.y = 0;
            if (direction == Vector3.zero) yield break;

            Quaternion startRot = transform.rotation;
            Quaternion targetRot = Quaternion.LookRotation(direction, Vector3.up);

            float totalAngle = Quaternion.Angle(startRot, targetRot);
            if (totalAngle < 0.1f) yield break;

            float angleRatio = Mathf.Clamp01(totalAngle / _moveMaxRotationSpeedAngle);
            float dynamicRotationSpeed = Mathf.Lerp(_moveMinRotationSpeed, _moveMaxRotationSpeed, angleRatio);
            float duration = totalAngle / dynamicRotationSpeed;
            float elapsed = 0f;

            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float curveT = _moveRotationEaseCurve.Evaluate(Mathf.Clamp01(elapsed / duration));
                transform.rotation = Quaternion.SlerpUnclamped(startRot, targetRot, curveT);
                yield return null;
            }

            transform.rotation = targetRot;
        }

        public IEnumerator FaceTargetCoroutine(Vector3 targetWorldPosition)
        {
            Vector3 direction = (targetWorldPosition - transform.position).normalized;
            direction.y = 0;
            if (direction == Vector3.zero) yield break;

            Quaternion startRot = transform.rotation;
            Quaternion targetRot = Quaternion.LookRotation(direction, Vector3.up);

            float angleToTarget = Vector3.SignedAngle(transform.forward, direction, Vector3.up);
            float absoluteAngle = Mathf.Abs(angleToTarget);

            if (absoluteAngle > 15f && _animator != null)
            {
                if (angleToTarget > 0) _animator.SetTrigger("TurnRight");
                else _animator.SetTrigger("TurnLeft");

                if (_turnAnimPreDelay > 0f)
                {
                    yield return new WaitForSeconds(_turnAnimPreDelay);
                    startRot = transform.rotation;
                    absoluteAngle = Quaternion.Angle(startRot, targetRot);
                }
            }

            if (absoluteAngle > 0.1f)
            {
                float angleRatio = Mathf.Clamp01(absoluteAngle / _aimMaxRotationSpeedAngle);
                float dynamicRotationSpeed = Mathf.Lerp(_aimMinRotationSpeed, _aimMaxRotationSpeed, angleRatio);
                float duration = absoluteAngle / dynamicRotationSpeed;
                float elapsed = 0f;

                while (elapsed < duration)
                {
                    elapsed += Time.deltaTime;
                    float curveT = _aimRotationEaseCurve.Evaluate(Mathf.Clamp01(elapsed / duration));
                    transform.rotation = Quaternion.SlerpUnclamped(startRot, targetRot, curveT);
                    yield return null;
                }
            }

            transform.rotation = targetRot;
            yield return new WaitForSeconds(0.1f);
        }
    }
}