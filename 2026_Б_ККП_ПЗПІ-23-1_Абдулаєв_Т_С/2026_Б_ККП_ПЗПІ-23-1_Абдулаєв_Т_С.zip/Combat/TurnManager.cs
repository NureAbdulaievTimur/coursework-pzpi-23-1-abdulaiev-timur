using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

namespace CombatGrid
{
    public class TurnManager : MonoBehaviour
    {
        public static TurnManager Instance { get; private set; }

        [Header("Configuration")]
        [SerializeField] private TurnSettings _settings;
        public TurnSettings Settings => _settings;

        [SerializeField] private bool _autoStartOnAwake = true;

        [Header("UI")]
        [SerializeField] private TextMeshProUGUI _turnIndicatorText;

        public bool IsCombatActive { get; private set; }
        public int CurrentRound { get; private set; }
        public int CurrentPhaseIndex { get; private set; }
        public UnitTeam ActiveTeam => _settings != null && _settings.TeamOrder.Count > 0
                                          ? _settings.TeamOrder[CurrentPhaseIndex]
                                          : UnitTeam.Player;

        public bool IsPlayerPhase => ActiveTeam == UnitTeam.Player;
        public bool IsTransitioning { get; private set; }

        private readonly Dictionary<UnitTeam, List<Unit>> _unitsByTeam = new();

        public IReadOnlyList<Unit> GetUnits(UnitTeam team)
            => _unitsByTeam.TryGetValue(team, out var list) ? list : Array.Empty<Unit>();

        public IEnumerable<Unit> AllUnits
            => _unitsByTeam.Values.SelectMany(l => l);

        public event Action OnCombatStarted;
        public event Action<int> OnRoundStarted;
        public event Action<UnitTeam, int> OnPhaseStarted;
        public event Action<UnitTeam, int> OnPhaseEnded;
        public event Action<int> OnRoundEnded;
        public event Action<UnitTeam?> OnCombatEnded;
        public event Action<ReactionOpportunity> OnReactionWindowOpened;

        private Coroutine _phaseCoroutine;
        private bool _phaseEndRequested;
        private int _phaseHolds = 0;

        private void Awake()
        {
            if (Instance != null && Instance != this) { Destroy(gameObject); return; }
            Instance = this;

            if (_settings == null)
                Debug.LogWarning("[TurnManager] No TurnSettings assigned - defaults may behave unexpectedly.", this);

            foreach (UnitTeam team in Enum.GetValues(typeof(UnitTeam)))
                _unitsByTeam[team] = new List<Unit>();
        }

        private void Start()
        {
            if (_autoStartOnAwake)
                StartCombat();
        }

        private void Update()
        {
            if (_turnIndicatorText == null) return;

            if (!IsCombatActive)
            {
                _turnIndicatorText.enabled = false;
                return;
            }

            _turnIndicatorText.enabled = true;
            _turnIndicatorText.text = $"Round {CurrentRound}  |  {ActiveTeam} Phase";
            _turnIndicatorText.fontSize = 18;
            _turnIndicatorText.color = ActiveTeam == UnitTeam.Player ? Color.cyan
                                     : ActiveTeam == UnitTeam.Enemy ? Color.red
                                     : Color.yellow;
        }

        private void OnDestroy()
        {
            if (Instance == this) Instance = null;
        }

        public void RegisterUnit(Unit unit)
        {
            if (unit == null) return;
            if (!_unitsByTeam.TryGetValue(unit.Team, out var list))
            {
                list = new List<Unit>();
                _unitsByTeam[unit.Team] = list;
            }
            if (!list.Contains(unit))
            {
                list.Add(unit);
                unit.OnUnitDied += OnUnitDied;
                Debug.Log($"[TurnManager] Registered {unit.name} ({unit.Team}).");
            }
        }

        public void UnregisterUnit(Unit unit)
        {
            if (unit == null) return;
            if (_unitsByTeam.TryGetValue(unit.Team, out var list))
                list.Remove(unit);
            unit.OnUnitDied -= OnUnitDied;
        }

        private void OnUnitDied(Unit unit)
        {
            UnregisterUnit(unit);
            if (_settings != null && _settings.AutoCheckVictory)
                CheckVictoryCondition();
        }

        public void AddPhaseHold() => _phaseHolds++;
        public void RemovePhaseHold() => _phaseHolds = Mathf.Max(0, _phaseHolds - 1);
        public bool IsPhaseHeld => _phaseHolds > 0;

        public void StartCombat()
        {
            if (IsCombatActive)
            {
                Debug.LogWarning("[TurnManager] StartCombat called but combat is already active.");
                return;
            }
            IsCombatActive = true;
            CurrentRound = 0;
            CurrentPhaseIndex = 0;
            _phaseEndRequested = false;
            _phaseHolds = 0;

            if (_phaseCoroutine != null) StopCoroutine(_phaseCoroutine);
            _phaseCoroutine = StartCoroutine(CombatLoop());

            OnCombatStarted?.Invoke();
            Debug.Log("[TurnManager] Combat started.");
        }

        public void StopCombat()
        {
            IsCombatActive = false;
            if (_phaseCoroutine != null)
            {
                StopCoroutine(_phaseCoroutine);
                _phaseCoroutine = null;
            }
            Debug.Log("[TurnManager] Combat stopped.");
        }

        public void EndPhase()
        {
            if (!IsCombatActive) return;
            _phaseEndRequested = true;
        }

        public void GrantReactionWindow(ReactionOpportunity opportunity)
        {
            if (!IsCombatActive) return;
            OnReactionWindowOpened?.Invoke(opportunity);
        }

        private IEnumerator CombatLoop()
        {
            if (_settings != null && _settings.CombatStartDelay > 0f)
                yield return new WaitForSeconds(_settings.CombatStartDelay);

            while (IsCombatActive)
            {
                CurrentRound++;
                Debug.Log($"[TurnManager] -- Round {CurrentRound} --");
                OnRoundStarted?.Invoke(CurrentRound);

                if (_settings == null || _settings.RefreshReactionPointsEachRound)
                    foreach (var unit in AllUnits.ToList())
                        unit.RefreshReactionPoints();

                List<UnitTeam> order = _settings?.TeamOrder ?? new List<UnitTeam> { UnitTeam.Player, UnitTeam.Enemy };

                for (int i = 0; i < order.Count; i++)
                {
                    CurrentPhaseIndex = i;
                    UnitTeam team = order[i];

                    if (!_unitsByTeam.TryGetValue(team, out var units) || units.Count == 0)
                    {
                        Debug.Log($"[TurnManager] Skipping {team} phase (no units).");
                        continue;
                    }

                    IsTransitioning = false;
                    _phaseEndRequested = false;

                    foreach (var unit in units.ToList())
                    {
                        unit.StartTurn();
                        if (_settings != null && !_settings.RefreshReactionPointsEachRound)
                            unit.RefreshReactionPoints();
                    }

                    Debug.Log($"[TurnManager] Phase started - {team} (Round {CurrentRound}).");
                    OnPhaseStarted?.Invoke(team, CurrentRound);

                    bool autoEnd = _settings != null &&
                                   _settings.AutoEndWhenExhausted.Contains(team);

                    yield return new WaitUntil(() =>
                        _phaseEndRequested || (autoEnd && AllUnitsExhausted(team) && !IsPhaseHeld));

                    IsTransitioning = true;
                    Debug.Log($"[TurnManager] Phase ended - {team} (Round {CurrentRound}).");
                    OnPhaseEnded?.Invoke(team, CurrentRound);

                    if (_settings != null && _settings.PhaseTransitionDelay > 0f)
                        yield return new WaitForSeconds(_settings.PhaseTransitionDelay);
                }

                Debug.Log($"[TurnManager] Round {CurrentRound} ended.");
                OnRoundEnded?.Invoke(CurrentRound);

                if (_settings != null && _settings.AutoCheckVictory)
                    CheckVictoryCondition();
            }
        }

        private bool AllUnitsExhausted(UnitTeam team)
        {
            if (!_unitsByTeam.TryGetValue(team, out var units) || units.Count == 0)
                return true;

            foreach (var unit in units)
            {
                if (!unit.IsAlive) continue;
                if (unit.CanMove || unit.CanAct) return false;
                if (unit.Movement.IsMoving) return false;
            }

            return true;
        }

        private void CheckVictoryCondition()
        {
            List<UnitTeam> teamsAlive = _unitsByTeam
                .Where(kv => kv.Value.Count > 0)
                .Select(kv => kv.Key)
                .ToList();

            if (teamsAlive.Count == 0)
                EndCombatWithResult(null);
            else if (teamsAlive.Count == 1)
                EndCombatWithResult(teamsAlive[0]);
        }

        private void EndCombatWithResult(UnitTeam? winner)
        {
            if (!IsCombatActive) return;
            StopCombat();
            string result = winner.HasValue ? $"{winner.Value} wins" : "Draw / all units dead";
            Debug.Log($"[TurnManager] Combat ended - {result}.");
            OnCombatEnded?.Invoke(winner);
        }
    }
}