using System;
using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{


    public struct PositionThreatInfo
    {
        public CoverType BestCover;
        public CoverType WorstCover;
        public int ExposedThreatCount;
        public int HalfCoveredCount;
        public int FullCoveredCount;
        public int EnemiesInRangeCount;
        public int NearestEnemyDist;
        public Unit NearestEnemy;
        public int TotalEnemies;

        public float AggregateCoverScore(AIWeights w)
        {
            if (TotalEnemies == 0) return 0f;

            float sum = 0f;
            sum += FullCoveredCount * w.FullCoverReward;
            sum += HalfCoveredCount * w.HalfCoverReward;
            sum += ExposedThreatCount * w.ExposurePenaltyPerThreat;

            float perEnemy = sum / TotalEnemies;
            float scale = 1f + Mathf.Log(TotalEnemies, 2f);
            return perEnemy * scale;
        }
    }


    public static class AIActionScorer
    {
        public static List<CombatAction> GenerateScoredActions(
            Unit actor,
            AIWeights weights,
            List<AbilityAction> extraAbilities = null)
        {
            var actions = new List<CombatAction>();
            if (!actor.IsAlive) return actions;

            var enemies = GetEnemiesOf(actor);

            List<GridCell> reachable = new();
            if (actor.CanMove && GridManager.Instance != null)
                reachable = GridManager.Instance.GetReachableCells(
                    actor.CurrentCoord,
                    actor.RemainingMovePoints,
                    excludeOccupied: true,
                    startingDiagCount: actor.Movement.DiagCount);

            bool useCombinedPlanning = actor.CanAct && !actor.Stats.CanMoveAfterAction;

            PositionThreatInfo currentThreat = AssessPosition(actor.CurrentCoord, enemies);

            if (useCombinedPlanning)
                GenerateCombinedActions(actor, weights, enemies, reachable, actions,
                                        currentThreat, extraAbilities);
            else
                GenerateIndependentActions(actor, weights, enemies, reachable, actions,
                                           currentThreat, extraAbilities);

            actions.Add(new WaitAction { Score = weights.WaitReward + Noise(weights) });
            actions.Sort((a, b) => b.Score.CompareTo(a.Score));
            return actions;
        }

        private static float GetCircularDistance(GridCoord a, GridCoord b)
        {
            float dx = a.X - b.X;
            float dz = a.Z - b.Z;
            return Mathf.Sqrt((dx * dx) + (dz * dz));
        }

        public static PositionThreatInfo AssessPosition(GridCoord position, List<Unit> enemies)
        {
            var info = new PositionThreatInfo
            {
                BestCover = CoverType.None,
                WorstCover = CoverType.Full,
                NearestEnemyDist = int.MaxValue,
            };

            GridManager gm = GridManager.Instance;
            CombatManager cm = CombatManager.Instance;

            Vector3 posWorldPos = gm != null
                ? (gm.GetCell(position)?.WorldPos ?? Vector3.zero)
                : Vector3.zero;

            bool hasVisibleEnemy = false;

            foreach (var enemy in enemies)
            {
                if (!enemy.IsAlive) continue;

                int dist = GridCoord.ChebyshevDistance(position, enemy.CurrentCoord);

                
                if (dist < info.NearestEnemyDist)
                {
                    info.NearestEnemyDist = dist;
                    info.NearestEnemy = enemy;
                }


                if (cm != null && !cm.HasLineOfSight(posWorldPos, enemy.transform.position))
                    continue;

                hasVisibleEnemy = true;
                info.TotalEnemies++;

                float circDist = GetCircularDistance(position, enemy.CurrentCoord);
                if (circDist <= enemy.Stats.AttackRange + 0.5f)
                    info.EnemiesInRangeCount++;

                if (gm != null)
                {
                    CoverType c = gm.GetCoverBetween(position, enemy.CurrentCoord);
                    if (c > info.BestCover) info.BestCover = c;
                    if (c < info.WorstCover) info.WorstCover = c;

                    switch (c)
                    {
                        case CoverType.None: info.ExposedThreatCount++; break;
                        case CoverType.Half: info.HalfCoveredCount++; break;
                        case CoverType.Full: info.FullCoveredCount++; break;
                    }
                }
                else
                {
                    info.ExposedThreatCount++;
                }
            }


            if (!hasVisibleEnemy)
                info.WorstCover = CoverType.None;

            return info;
        }

        private static int CoverTier(CoverType c) => c switch
        {
            CoverType.Half => 1,
            CoverType.Full => 2,
            _ => 0
        };


        private static void GenerateCombinedActions(
            Unit actor,
            AIWeights weights,
            List<Unit> enemies,
            List<GridCell> reachable,
            List<CombatAction> actions,
            PositionThreatInfo currentThreat,
            List<AbilityAction> extraAbilities)
        {
            CombatManager cm = CombatManager.Instance;

            float currentPositionScore = ScorePositionFull(
                actor, actor.CurrentCoord, currentThreat, weights, enemies);

            float currentPostActionThreat = currentThreat.EnemiesInRangeCount
                                          * currentThreat.ExposedThreatCount
                                          * weights.PostActionExposurePenalty;


            if (actor.CanAct)
            {
                foreach (var enemy in enemies)
                {
                    if (!enemy.IsAlive) continue;
                    if (GetCircularDistance(actor.CurrentCoord, enemy.CurrentCoord) > actor.Stats.AttackRange + 0.5f)
                        continue;


                    if (cm != null && !cm.HasLineOfSight(actor, enemy))
                        continue;

                    float attackScore = ScoreAttack(actor, enemy, weights,
                                                    actor.CurrentCoord, addNoise: false);
                    float total = currentPositionScore + currentPostActionThreat
                                + attackScore + Noise(weights);

                    actions.Add(new AttackAction(enemy) { Score = total });
                }


                if (extraAbilities != null)
                {
                    foreach (var ability in extraAbilities)
                    {
                        float s = ability.Evaluate(actor, weights);
                        if (!float.IsNegativeInfinity(s))
                            actions.Add(ability);
                    }
                }
            }


            if (actor.CanMove)
            {
                foreach (var cell in reachable)
                {
                    PositionThreatInfo destThreat = AssessPosition(cell.Coord, enemies);

                    float destPositionScore = ScorePositionFull(
                        actor, cell.Coord, destThreat, weights, enemies);

                    int coverLoss = CoverTier(currentThreat.BestCover)
                                  - CoverTier(destThreat.BestCover);
                    float coverLossPenalty = coverLoss > 0
                        ? coverLoss * weights.CoverLossPenaltyPerTier : 0f;

                    float proximityDelta = 0f;
                    if (destThreat.NearestEnemy != null && currentThreat.NearestEnemy != null)
                    {
                        int oldDist = currentThreat.NearestEnemyDist;
                        int newDist = destThreat.NearestEnemyDist;
                        bool retreating = actor.HealthPercent < weights.RetreatHPThreshold;
                        float proxWeight = retreating
                            ? weights.RetreatProximityRewardPerCell
                            : weights.ProximityRewardPerCell;
                        proximityDelta = (oldDist - newDist) * proxWeight;
                    }

                    float postActionThreat = destThreat.EnemiesInRangeCount
                                           * destThreat.ExposedThreatCount
                                           * weights.PostActionExposurePenalty;

                    float moveBase = destPositionScore + coverLossPenalty
                                   + proximityDelta + postActionThreat;


                    if (actor.CanAct)
                    {
                        Unit bestAttackTarget = null;
                        float bestAttackScore = float.NegativeInfinity;

                        foreach (var enemy in enemies)
                        {
                            if (!enemy.IsAlive) continue;
                            if (GetCircularDistance(cell.Coord, enemy.CurrentCoord) > actor.Stats.AttackRange + 0.5f)
                                continue;


                            if (cm != null && !cm.HasLineOfSight(cell.WorldPos, enemy.transform.position))
                                continue;

                            float attackScore = ScoreAttack(actor, enemy, weights,
                                                            cell.Coord, addNoise: false);
                            if (attackScore > bestAttackScore)
                            {
                                bestAttackScore = attackScore;
                                bestAttackTarget = enemy;
                            }
                        }

                        if (bestAttackTarget != null)
                        {
                            float total = moveBase + bestAttackScore + Noise(weights);

                            actions.Add(new SequenceAction(
                                new MoveAction(cell),
                                new AttackAction(bestAttackTarget))
                            { Score = total });
                        }


                        AbilityAction bestAbility = null;
                        if (extraAbilities != null)
                        {
                            float bestAbilityScore = float.NegativeInfinity;

                            foreach (var ability in extraAbilities)
                            {

                                float s = ability.EvaluateFromPosition(actor, cell.Coord, weights);
                                if (float.IsNegativeInfinity(s)) continue;
                                if (s > bestAbilityScore)
                                {
                                    bestAbilityScore = s;
                                    bestAbility = ability;
                                }
                            }

                            if (bestAbility != null)
                            {
                                float total = moveBase + bestAbilityScore + Noise(weights);
                                actions.Add(new SequenceAction(
                                    new MoveAction(cell),
                                    bestAbility)
                                { Score = total });
                            }
                        }

                        bool anyActionFromCell = bestAttackTarget != null || bestAbility != null;

                        if (!anyActionFromCell)
                        {

                            float attackOppBonus = ScoreApproachOpportunity(actor, cell.Coord, enemies, weights);

                            float pureMoveScore = moveBase + attackOppBonus
                                                + weights.WaitReward + Noise(weights);
                            actions.Add(new MoveAction(cell) { Score = pureMoveScore });
                        }
                    }
                    else
                    {
                        float pureMoveScore = moveBase + weights.WaitReward + Noise(weights);
                        actions.Add(new MoveAction(cell) { Score = pureMoveScore });
                    }
                }
            }
        }

        private static void GenerateIndependentActions(
            Unit actor,
            AIWeights weights,
            List<Unit> enemies,
            List<GridCell> reachable,
            List<CombatAction> actions,
            PositionThreatInfo currentThreat,
            List<AbilityAction> extraAbilities)
        {
            CombatManager cm = CombatManager.Instance;

            float stayBonus = 0f;
            if (currentThreat.BestCover >= CoverType.Half)
                stayBonus += weights.StayInCoverBonus * 0.5f;

            foreach (var cell in reachable)
            {
                PositionThreatInfo destThreat = AssessPosition(cell.Coord, enemies);
                float baseMoveScore = ScoreMoveFull(actor, cell, weights, enemies,
                                                    currentThreat, destThreat);

                float bestFollowUpAttack = 0f;

                if (actor.CanAct)
                {
                    foreach (var enemy in enemies)
                    {
                        if (!enemy.IsAlive) continue;
                        if (GetCircularDistance(cell.Coord, enemy.CurrentCoord) > actor.Stats.AttackRange + 0.5f)
                            continue;

                        if (cm != null && !cm.HasLineOfSight(cell.WorldPos, enemy.transform.position))
                            continue;

                        float attackScore = ScoreAttack(actor, enemy, weights,
                                                        cell.Coord, addNoise: false);
                        if (attackScore > bestFollowUpAttack)
                            bestFollowUpAttack = attackScore;
                    }
                }

                actions.Add(new MoveAction(cell)
                {
                    Score = baseMoveScore + bestFollowUpAttack + Noise(weights)
                });
            }

            if (actor.CanAct)
            {
                float bestFollowUpMove = 0f;

                if (actor.CanMove)
                {
                    foreach (var cell in reachable)
                    {
                        PositionThreatInfo destThreat = AssessPosition(cell.Coord, enemies);
                        float moveScore = ScoreMoveFull(actor, cell, weights, enemies,
                                                        currentThreat, destThreat);
                        if (moveScore > bestFollowUpMove) bestFollowUpMove = moveScore;
                    }
                }

                foreach (var enemy in enemies)
                {
                    if (!enemy.IsAlive) continue;
                    if (GetCircularDistance(actor.CurrentCoord, enemy.CurrentCoord) > actor.Stats.AttackRange + 0.5f)
                        continue;

                    if (cm != null && !cm.HasLineOfSight(actor, enemy))
                        continue;

                    float baseAttackScore = stayBonus + ScoreAttack(actor, enemy, weights,
                                                                     actor.CurrentCoord,
                                                                     addNoise: false);
                    actions.Add(new AttackAction(enemy)
                    {
                        Score = baseAttackScore + bestFollowUpMove + Noise(weights)
                    });
                }

                if (extraAbilities != null)
                {
                    foreach (var ability in extraAbilities)
                    {
                        float s = ability.Evaluate(actor, weights);
                        if (!float.IsNegativeInfinity(s))
                            actions.Add(ability);
                    }
                }
            }
        }

        private static float ScorePositionFull(
            Unit actor,
            GridCoord position,
            PositionThreatInfo threat,
            AIWeights w,
            List<Unit> enemies)
        {
            float score = 0f;
            GridManager gm = GridManager.Instance;
            if (gm == null) return score;

            score += threat.AggregateCoverScore(w);

            foreach (var enemy in enemies)
            {
                if (!enemy.IsAlive) continue;
                if (gm.GetCoverBetween(enemy.CurrentCoord, position) == CoverType.None)
                {
                    score += w.FlankPositionReward;
                    break;
                }
            }

            if (TurnManager.Instance != null)
            {
                int nearbyAllies = 0;
                foreach (var ally in TurnManager.Instance.GetUnits(actor.Team))
                {
                    if (ally == actor || !ally.IsAlive) continue;
                    if (GridCoord.ChebyshevDistance(position, ally.CurrentCoord) <= 1)
                        nearbyAllies++;
                }
                score += nearbyAllies * w.AllyClusterPenalty;
            }

            return score;
        }

        private static float ScoreMoveFull(
            Unit actor,
            GridCell dest,
            AIWeights w,
            List<Unit> enemies,
            PositionThreatInfo currentThreat,
            PositionThreatInfo destThreat)
        {
            float score = w.BaseMoveReward;

            score += ScorePositionFull(actor, dest.Coord, destThreat, w, enemies);

            if (destThreat.NearestEnemy != null && currentThreat.NearestEnemy != null)
            {
                bool retreating = actor.HealthPercent < w.RetreatHPThreshold;
                float proxWeight = retreating
                    ? w.RetreatProximityRewardPerCell
                    : w.ProximityRewardPerCell;

                int oldDist = currentThreat.NearestEnemyDist;
                int newDist = destThreat.NearestEnemyDist;
                score += (oldDist - newDist) * proxWeight;
            }

            int coverLoss = CoverTier(currentThreat.BestCover) - CoverTier(destThreat.BestCover);
            if (coverLoss > 0)
                score += coverLoss * w.CoverLossPenaltyPerTier;

            score += destThreat.EnemiesInRangeCount
                   * destThreat.ExposedThreatCount
                   * w.PostActionExposurePenalty;

            score += ScoreApproachOpportunity(actor, dest.Coord, enemies, w);

            score += Noise(w);
            return score;
        }

        public static float ScoreAttack(Unit attacker, Unit target, AIWeights w, GridCoord fromCoord, bool addNoise = true)
        {
            float hitChance;
            if (fromCoord == attacker.CurrentCoord && CombatManager.Instance != null)
                hitChance = CombatManager.Instance.PreviewHitChance(attacker, target);
            else
                hitChance = Mathf.Clamp01(attacker.Stats.BaseHitChance - target.Stats.Evasion);

            float score = w.BaseAttackReward;

            float missingHPPct = (1f - target.HealthPercent) * 100f;
            score += missingHPPct * w.WoundedTargetBonusPerPct;

            int dmg = attacker.Stats.AttackDamage;
            bool canKill = (target.CurrentEnergyShield == 0
                            && dmg - target.Stats.Armor >= target.CurrentHP)
                        || (target.CurrentEnergyShield > 0
                            && dmg >= target.CurrentEnergyShield + target.CurrentHP);
            if (canKill) score += w.KillShotBonus;

            if (target.CurrentEnergyShield <= 0 && target.HasEnergyShield)
                score += w.ShieldDepletedBonus;
            else if (target.HasEnergyShield && target.EnergyShieldPercent >= 1f)
                score += w.FullShieldPenalty;

            CoverType cover = GridManager.Instance != null
                ? GridManager.Instance.GetCoverBetween(target.CurrentCoord, fromCoord)
                : CoverType.None;

            score += cover switch
            {
                CoverType.None => w.TargetExposedBonus,
                CoverType.Half => w.TargetHalfCoverPenalty,
                CoverType.Full => w.TargetFullCoverPenalty,
                _ => 0f
            };

            score *= Mathf.Lerp(1f, hitChance, w.HitChanceInfluence);

            if (addNoise) score += Noise(w);
            return score;
        }

        public static float ScoreAttack(Unit attacker, Unit target, AIWeights w)
            => ScoreAttack(attacker, target, w, attacker.CurrentCoord, addNoise: true);

        public static float ScoreMove(Unit actor, GridCell dest, AIWeights w, List<Unit> enemies)
        {
            var currentThreat = AssessPosition(actor.CurrentCoord, enemies);
            var destThreat = AssessPosition(dest.Coord, enemies);
            return ScoreMoveFull(actor, dest, w, enemies, currentThreat, destThreat);
        }

        private static float ScoreApproachOpportunity(
            Unit actor, GridCoord from, List<Unit> enemies, AIWeights w)
        {
            float best = 0f;
            CombatManager cm = CombatManager.Instance;
            GridCell fromCell = GridManager.Instance?.GetCell(from);

            foreach (var enemy in enemies)
            {
                if (!enemy.IsAlive) continue;

                float dist = GetCircularDistance(from, enemy.CurrentCoord);
                float distToRange = Mathf.Max(0f, dist - (actor.Stats.AttackRange + 0.5f));

                float score;
                if (distToRange <= 0f)
                {
                    bool hasLos = cm == null || fromCell == null ||
                                  cm.HasLineOfSight(fromCell.WorldPos, enemy.transform.position);
                    score = hasLos
                        ? w.AttackOpportunityReward
                        : w.AttackOpportunityReward * 0.4f;
                }
                else
                {
                    float turnsAway = (float)distToRange /
                                      Mathf.Max(1, actor.Stats.MovePointsPerTurn);
                    score = w.AttackOpportunityReward / (1f + turnsAway);
                }

                if (score > best) best = score;
            }
            return best;
        }

        public static List<Unit> GetEnemiesOf(Unit actor)
        {
            var result = new List<Unit>();
            if (TurnManager.Instance == null) return result;

            foreach (UnitTeam team in Enum.GetValues(typeof(UnitTeam)))
            {
                if (team == actor.Team) continue;
                foreach (var u in TurnManager.Instance.GetUnits(team))
                    if (u.IsAlive) result.Add(u);
            }
            return result;
        }

        private static float Noise(AIWeights w)
            => w.ScoreNoise > 0f
                ? UnityEngine.Random.Range(-w.ScoreNoise, w.ScoreNoise)
                : 0f;
    }
}