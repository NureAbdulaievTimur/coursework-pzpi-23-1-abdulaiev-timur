using UnityEngine;

namespace CombatGrid
{
    [CreateAssetMenu(fileName = "UnitStats", menuName = "CombatGrid/UnitStats")]
    public class UnitStats : ScriptableObject
    {
        [Header("Identity")]
        public string UnitName = "Unnamed Unit";

        [Header("Health")]
        [Min(1)] public int MaxHP = 10;

        [Header("Energy Shield")]
        [Tooltip("Absorbs damage before HP is reduced. 0 = no shield.")]
        [Min(0)] public int MaxEnergyShield = 0;

        [Tooltip("Shield points restored at the start of each turn. 0 = no regen.")]
        [Min(0)] public int ShieldRegenPerTurn = 0;

        [Header("Armor")]
        [Tooltip("Flat damage reduction applied to HP damage after shield is gone.")]
        [Min(0)] public int Armor = 0;

        [Header("Defense")]
        [Tooltip("Base dodge chance (0-1). Cover bonuses are added on top.")]
        [Range(0f, 1f)] public float Evasion = 0f;

        [Header("Movement")]
        [Tooltip("Movement points per turn.")]
        [Min(1)] public int MovePointsPerTurn = 6;

        [Tooltip("Visual movement speed in world units/second.")]
        [Min(0.1f)] public float MoveSpeed = 5f;

        [Header("Action Economy")]
        [Tooltip("Actions (e.g. attacks) available per turn.")]
        [Min(1)] public int ActionPointsPerTurn = 1;

        [Tooltip("If false (XCOM-style), spending an action point zeroes move points.")]
        public bool CanMoveAfterAction = false;

        [Header("Reactions")]
        [Tooltip("Out-of-turn reaction points per round. 0 = unit cannot react.")]
        [Min(0)] public int ReactionPointsPerRound = 1;

        [Header("Offense")]
        [Min(0)] public int AttackDamage = 4;
        [Min(0)] public int AttackRange = 5;

        [Tooltip("Base hit probability. finalHit = BaseHitChance - target.Evasion - coverBonus.")]
        [Range(0f, 1f)] public float BaseHitChance = 0.75f;

        public bool HasEnergyShield => MaxEnergyShield > 0;
    }
}