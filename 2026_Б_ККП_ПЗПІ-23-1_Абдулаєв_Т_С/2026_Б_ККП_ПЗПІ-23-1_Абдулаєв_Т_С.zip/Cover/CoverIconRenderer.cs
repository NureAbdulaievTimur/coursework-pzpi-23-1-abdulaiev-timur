using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    public class CoverIconRenderer : MonoBehaviour
    {
        private static readonly int Prop_FillLevel = Shader.PropertyToID("_FillLevel");
        private static readonly int Prop_ProtectedCellPos = Shader.PropertyToID("_ProtectedCellPos");
        private static readonly int Prop_HighlightColor = Shader.PropertyToID("_HighlightColor");
        private static readonly int Prop_HighlightScale = Shader.PropertyToID("_HighlightScale");
        private static readonly int Prop_HighlightRadius = Shader.PropertyToID("_HighlightRadius");

        private static readonly int Prop_ShieldColor = Shader.PropertyToID("_ShieldColor");
        private static readonly int Prop_GlowColor = Shader.PropertyToID("_GlowColor");
        private static readonly int Prop_HDR = Shader.PropertyToID("_HDR");
        private static readonly int Prop_PulseSpeed = Shader.PropertyToID("_PulseSpeed");
        private static readonly int Prop_PulseDepth = Shader.PropertyToID("_PulseDepth");

        private readonly List<GameObject> _icons = new();

        public void AddIcon(Vector3 edgeCenter, Vector3 facingDirection, Vector3 protectedCellWorldPos,
                            CoverType coverType, CoverIconSettings s)
        {
            if (s?.IconMaterial == null || coverType == CoverType.None) return;

            var go = new GameObject($"CoverIcon_{coverType}");

            Vector3 pos = edgeCenter + Vector3.up * s.GroundOffset + facingDirection * s.ForwardBias;
            go.transform.position = pos;

            if (facingDirection != Vector3.zero)
                go.transform.rotation = Quaternion.LookRotation(facingDirection, Vector3.up);

            go.transform.localScale = new Vector3(s.Width, s.Height, 1f);

            go.transform.SetParent(transform, worldPositionStays: true);

            var mf = go.AddComponent<MeshFilter>();
            var mr = go.AddComponent<MeshRenderer>();
            mf.sharedMesh = BuildQuadMesh();

            var mpb = new MaterialPropertyBlock();
            mr.sharedMaterial = s.IconMaterial;

            mpb.SetFloat(Prop_FillLevel, coverType == CoverType.Full ? 1f : 0.5f);

            mpb.SetVector(Prop_ProtectedCellPos, new Vector4(protectedCellWorldPos.x, protectedCellWorldPos.y, protectedCellWorldPos.z, 1f));

            float safeScale = s.HighlightScale <= 0.01f ? 1.25f : s.HighlightScale;
            float safeRadius = s.HighlightRadius <= 0.01f ? 0.8f : s.HighlightRadius;
            Color safeColor = s.HighlightColor.a == 0 ? new Color(0.2f, 1.0f, 0.3f, 1f) : s.HighlightColor;

            mpb.SetColor(Prop_HighlightColor, safeColor);
            mpb.SetFloat(Prop_HighlightScale, safeScale);
            mpb.SetFloat(Prop_HighlightRadius, safeRadius);

            mpb.SetColor(Prop_ShieldColor, s.ShieldColor);
            mpb.SetColor(Prop_GlowColor, s.GlowColor);
            mpb.SetFloat(Prop_HDR, s.HDRMultiplier);
            mpb.SetFloat(Prop_PulseSpeed, s.PulseSpeed);
            mpb.SetFloat(Prop_PulseDepth, s.PulseDepth);

            mr.SetPropertyBlock(mpb);
            _icons.Add(go);
        }

        public void ClearIcons()
        {
            foreach (var go in _icons)
                if (go != null) Destroy(go);
            _icons.Clear();
        }

        private void OnDestroy() => ClearIcons();

        private static Mesh BuildQuadMesh()
        {
            var m = new Mesh { name = "CoverIconQuad" };
            m.vertices = new Vector3[]
            {
                new(-0.5f, -0.5f, 0f), new(-0.5f,  0.5f, 0f),
                new( 0.5f,  0.5f, 0f), new( 0.5f, -0.5f, 0f)
            };
            m.uv = new Vector2[]
            {
                new(0f, 0f), new(0f, 1f),
                new(1f, 1f), new(1f, 0f)
            };
            m.triangles = new[] { 0, 1, 2, 0, 2, 3 };
            m.RecalculateNormals();
            return m;
        }
    }
}