using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace CombatGrid
{
    [RequireComponent(typeof(RawImage))]
    public class UnitHealthBar : MonoBehaviour
    {
        // =================================================================
        // Inspector
        // =================================================================
        [Header("Text Labels")]
        [SerializeField] private TextMeshProUGUI _nameLabel;
        [SerializeField] private TextMeshProUGUI _hpLabel;
        [SerializeField] private TextMeshProUGUI _shieldLabel;

        [Header("Labels Container")]
        [SerializeField] private RectTransform _labelsContainer;

        [Header("Hover Scale (must match shader _MiniScale)")]
        [SerializeField] private float _hoverMiniScale = 0.55f;

        [Header("Focus State (Preview / Damage)")]
        [Tooltip("The intermediate scale used when damage is previewed or an afterbar is depleting.")]
        [SerializeField] private float _focusScale = 0.75f;
        [Tooltip("How gradually the bar grows to Focus scale and shrinks back to Mini scale.")]
        [SerializeField] private float _focusTransitionSpeed = 3f;

        [Header("Stat Colours")]
        [SerializeField] private bool _colorNameByTeam = false;
        [SerializeField] private Color _defaultNameColor = Color.white;
        [Space]
        [SerializeField] private Color _playerHPTextColor = new Color(0.30f, 1.00f, 0.40f, 1f);
        [SerializeField] private Color _enemyHPTextColor = new Color(1.00f, 0.35f, 0.35f, 1f);
        [SerializeField] private Color _neutralHPTextColor = new Color(1.00f, 0.88f, 0.25f, 1f);
        [SerializeField] private Color _shieldTextColor = new Color(0.35f, 0.65f, 1.00f, 1f);

        [Header("World Positioning")]
        [SerializeField] private Vector3 _worldOffset = new Vector3(0f, 1.8f, 0f);

        [Header("Hover Animation")]
        [SerializeField] private float _hoverAnimSpeed = 6f;
        [SerializeField] private float _labelFadeInSpeed = 5f;
        [SerializeField] private float _labelFadeOutSpeed = 7f;
        [Tooltip("How much the bar pushes up when scaled/hovered. Perfectly synced with scale.")]
        [SerializeField] private float _barPushUpAmount = 20f;

        [Header("Diamond Reveal")]
        [Tooltip("SmoothDamp time for the diamond growing in/out. ~0.3�0.5 s feels good.")]
        [SerializeField] private float _diamondRevealSmoothTime = 0.35f;

        [Header("Damage Trail & Sizing")]
        [SerializeField] private float _trailDelay = 0.45f;
        [SerializeField] private float _trailDuration = 0.35f;
        [SerializeField] private AnimationCurve _trailEase = AnimationCurve.EaseInOut(0f, 0f, 1f, 1f);
        [SerializeField] private float _capacitySmoothTime = 0.25f;

        [SerializeField] private float _shieldFillSmoothTime = 0.22f;

        [Header("Damage Preview Animation")]
        [SerializeField] private float _previewFadeSpeed = 10f;

        [Header("Stat Label Preview Glow & Size")]
        [SerializeField] private Color _hpGlowColor = new Color(1f, 0.10f, 0.10f, 1f);
        [SerializeField] private Color _shieldGlowColor = new Color(1f, 0.10f, 0.10f, 1f);

        [Tooltip("To perfectly match the shader's diamond pulse, set this to match _SepPulseFreq (Default 4)")]
        [SerializeField][Range(0f, 20f)] private float _glowPulseFreq = 4f;

        [SerializeField][Range(0f, 1f)] private float _glowMinIntensity = 0.0f;
        [SerializeField][Range(0f, 1f)] private float _glowMaxIntensity = 0.85f;

        [Tooltip("How much the text scales up and down. Set to match _SepPulseAmt (Default 0.12)")]
        [SerializeField][Range(0f, 0.5f)] private float _textSizePulseAmount = 0.12f;

        [SerializeField] private bool _intensifyNearDepletion = true;
        [SerializeField][Range(1f, 5f)] private float _depletionIntensityMult = 2.5f;

        [Header("Death Animation")]
        [Tooltip("How long it takes for the health bar to shatter and fade out upon death.")]
        [SerializeField] private float _deathFadeDuration = 1.2f;

        // =================================================================
        // Public
        // =================================================================
        public Unit AttachedUnit => _unit;
        public bool IsHovered => _isHovered;

        // =================================================================
        // Private
        // =================================================================
        private Unit _unit;
        private Camera _cam;
        private RawImage _rawImage;
        private Material _mat;

        private bool _hiddenByManager = false;

        // Death tracking
        private bool _isDead = false;
        private Vector3 _lastWorldPos;

        private float _currentScale;
        private float _scaleVelocity;
        private bool _isHovered = false;
        private bool _wasHovered = false;

        private float _labelFadeLinear = 0f;
        private CanvasGroup _labelsCanvasGroup;

        private float _hpFillPts;
        private float _hpTrailPts;
        private float _shieldFillPts;
        private float _shieldTrailPts;
        private float _capacityTargetPts;
        private float _targetCapacity = 1f;
        private float _currentCapacity = 1f;
        private float _capacityVelocity;
        private float _shieldFillTarget;
        private float _shieldFillVelocity;
        private float _diamondRevealProgress = 1f;
        private float _diamondRevealVelocity = 0f;

        private bool _isPreviewing;
        private float _hpPreviewPts;
        private float _shieldPreviewPts;
        private float _previewAlphaCurrent = 0f;
        private float _previewAlphaTarget = 0f;
        private bool _previewShieldBreaks = false;

        private Coroutine _unifiedTrailCo;
        private bool _shieldWasDepleted = false;

        private GlitchTextEffect _nameGlitch;
        private GlitchTextEffect _hpGlitch;
        private GlitchTextEffect _shieldGlitch;

        private Color _baseHPColor;
        private Color _baseShieldColor;

        private float _hpGlowAlpha = 0f;
        private float _shieldGlowAlpha = 0f;

        private float _barPushCurrent = 0f;
        private float _barPushVelocity = 0f;

        // =================================================================
        // Shader property IDs
        // =================================================================
        private static readonly int ID_HoverState = Shader.PropertyToID("_HoverState");
        private static readonly int ID_HPFill = Shader.PropertyToID("_HPFill");
        private static readonly int ID_HPTrail = Shader.PropertyToID("_HPTrail");
        private static readonly int ID_HPPreview = Shader.PropertyToID("_HPPreview");
        private static readonly int ID_ShieldFill = Shader.PropertyToID("_ShieldFill");
        private static readonly int ID_ShieldTrail = Shader.PropertyToID("_ShieldTrail");
        private static readonly int ID_ShieldPreview = Shader.PropertyToID("_ShieldPreview");
        private static readonly int ID_PreviewAlpha = Shader.PropertyToID("_PreviewAlpha");
        private static readonly int ID_PrevShieldBreak = Shader.PropertyToID("_PrevShieldBreak");
        private static readonly int ID_ShieldEnabled = Shader.PropertyToID("_ShieldEnabled");
        private static readonly int ID_SplitRatio = Shader.PropertyToID("_SplitRatio");
        private static readonly int ID_Resolution = Shader.PropertyToID("_Resolution");
        private static readonly int ID_LastDamageTime = Shader.PropertyToID("_LastDamageTime");
        private static readonly int ID_LastHealTime = Shader.PropertyToID("_LastHealTime");
        private static readonly int ID_Team = Shader.PropertyToID("_Team");
        private static readonly int ID_LastShieldDepletedTime = Shader.PropertyToID("_LastShieldDepletedTime");
        private static readonly int ID_ShieldDepleted = Shader.PropertyToID("_ShieldDepleted");
        private static readonly int ID_ShatterCenter = Shader.PropertyToID("_ShatterCenter");
        private static readonly int ID_MasterAlpha = Shader.PropertyToID("_MasterAlpha");
        private static readonly int ID_DeathProgress = Shader.PropertyToID("_DeathProgress");
        private static readonly int ID_DeathRiseSpeed = Shader.PropertyToID("_DeathRiseSpeed");
        private static readonly int ID_DeathFadeSpeed = Shader.PropertyToID("_DeathFadeSpeed");
        private static readonly int ID_DeathBlockRandom = Shader.PropertyToID("_DeathBlockRandom");
        private static readonly int ID_DeathSpread = Shader.PropertyToID("_DeathSpread");
        private static readonly int ID_LastShieldRestoreTime = Shader.PropertyToID("_LastShieldRestoreTime");
        private static readonly int ID_DiamondRevealProgress = Shader.PropertyToID("_DiamondRevealProgress");

        private void Awake()
        {
            _rawImage = GetComponent<RawImage>();
            if (_cam == null) _cam = Camera.main;
            _currentScale = _hoverMiniScale;
        }

        private void OnDestroy()
        {
            UnsubscribeFromUnit();
            if (_mat != null) Destroy(_mat);
        }

        private void LateUpdate()
        {
            if (_cam == null) return;

            if (Mathf.Abs(_shieldFillPts - _shieldFillTarget) > 0.001f)
            {
                _shieldFillPts = Mathf.SmoothDamp(
                    _shieldFillPts, _shieldFillTarget,
                    ref _shieldFillVelocity, _shieldFillSmoothTime);

                if (_shieldFillPts > _shieldTrailPts)
                    _shieldTrailPts = _shieldFillPts;

                _capacityTargetPts = _hpTrailPts + _shieldFillPts;
                PushFillsToShader();
            }

            if (_isDead)
            {
                PositionOverUnit();
                AnimateHover();
                return;
            }

            if (_unit == null) return;
            _lastWorldPos = _unit.transform.position;

            PositionOverUnit();
            AnimateHover();

            if (_currentCapacity < _targetCapacity - 0.001f)
            {
                _currentCapacity = Mathf.SmoothDamp(_currentCapacity, _targetCapacity, ref _capacityVelocity, _capacitySmoothTime);
                PushFillsToShader();
            }

            bool diamondShouldShow = !_shieldWasDepleted
                         && _unit.HasEnergyShield
                         && (_shieldFillPts > 0f || _shieldTrailPts > 0f);
            float targetReveal = diamondShouldShow ? 1f : 0f;

            if (Mathf.Abs(_diamondRevealProgress - targetReveal) > 0.0005f)
            {
                _diamondRevealProgress = Mathf.SmoothDamp(
                    _diamondRevealProgress, targetReveal,
                    ref _diamondRevealVelocity, _diamondRevealSmoothTime);
                _mat.SetFloat(ID_DiamondRevealProgress, _diamondRevealProgress);
            }

            if (Mathf.Abs(_previewAlphaCurrent - _previewAlphaTarget) > 0.001f)
            {
                _previewAlphaCurrent = Mathf.MoveTowards(_previewAlphaCurrent, _previewAlphaTarget, Time.deltaTime * _previewFadeSpeed);

                float easedAlpha = Mathf.SmoothStep(0f, 1f, _previewAlphaCurrent);
                if (_mat != null)
                {
                    _mat.SetFloat(ID_PreviewAlpha, easedAlpha);
                    _mat.SetFloat(ID_PrevShieldBreak, _previewShieldBreaks ? easedAlpha : 0f);
                }

                if (_previewAlphaCurrent <= 0f && _previewAlphaTarget == 0f && _isPreviewing)
                {
                    _isPreviewing = false;
                    UpdateShaderFills();
                }
            }

            UpdatePreviewGlow();
        }

        private void OnRectTransformDimensionsChange()
        {
            if (_mat != null) PushResolution();
        }

        public void Initialize(Unit unit, Camera cam)
        {
            _unit = unit;
            _cam = cam;
            BootMaterial();
            BootLabelsCanvasGroup();
            BindGlitchEffects();
            SubscribeToUnit();
            ForceFullSync();
            _currentScale = _hoverMiniScale;
        }

        public void SetHovered(bool hovered)
        {
            _isHovered = hovered;
            if (_isHovered)
            {
                transform.SetAsLastSibling();
            }
        }
        public void SetHiddenByManager(bool hidden) => _hiddenByManager = hidden;

        public void SetDamagePreview(int hpDamage, int shieldDamage)
        {
            _isPreviewing = true;
            _hpPreviewPts = Mathf.Max(0f, _hpFillPts - hpDamage);
            _shieldPreviewPts = Mathf.Max(0f, _shieldFillPts - shieldDamage);
            _previewShieldBreaks = _unit.HasEnergyShield && _shieldFillPts > 0f && _shieldPreviewPts <= 0f;

            _previewAlphaTarget = 1f;
            UpdateShaderFills();

            transform.SetAsLastSibling();
        }

        public void ClearDamagePreview()
        {
            _previewAlphaTarget = 0f;
        }

        private void BootMaterial()
        {
            _mat = new Material(_rawImage.material);
            _rawImage.material = _mat;
            _mat.SetFloat(ID_LastDamageTime, -9999f);
            _mat.SetFloat(ID_LastHealTime, -9999f);
            _mat.SetFloat(ID_LastShieldDepletedTime, -9999f);
            _mat.SetFloat(ID_LastShieldRestoreTime, -9999f);
            _mat.SetFloat(ID_ShieldDepleted, 0f);
            _mat.SetFloat(ID_MasterAlpha, 1f);
            _mat.SetFloat(ID_DeathProgress, 0f);
            PushResolution();
        }

        private void BootLabelsCanvasGroup()
        {
            if (_labelsContainer == null) return;
            _labelsCanvasGroup = _labelsContainer.GetComponent<CanvasGroup>();
            if (_labelsCanvasGroup == null)
                _labelsCanvasGroup = _labelsContainer.gameObject.AddComponent<CanvasGroup>();
            _labelsCanvasGroup.alpha = 0f;
            _labelFadeLinear = 0f;
        }

        private void PushResolution()
        {
            if (_mat == null) return;
            var rt = (RectTransform)transform;
            _mat.SetVector(ID_Resolution, new Vector4(rt.rect.width, rt.rect.height, 0f, 0f));
        }

        private void BindGlitchEffects()
        {
            if (_nameLabel != null) { _nameGlitch = _nameLabel.GetComponent<GlitchTextEffect>(); _nameGlitch?.SetScrambleOnChange(false); }
            if (_hpLabel != null) { _hpGlitch = _hpLabel.GetComponent<GlitchTextEffect>(); _hpGlitch?.SetScrambleOnChange(true); }
            if (_shieldLabel != null) { _shieldGlitch = _shieldLabel.GetComponent<GlitchTextEffect>(); _shieldGlitch?.SetScrambleOnChange(true); }
        }

        private void SubscribeToUnit()
        {
            if (_unit == null) return;
            _unit.OnHPDamageTaken += HandleHPDamage;
            _unit.OnShieldDamageTaken += HandleShieldDamage;
            _unit.OnUnitDied += HandleUnitDied;
            _unit.OnPointsChanged += HandlePointsChanged;
            _unit.OnTurnStarted += HandleTurnStarted;
        }

        private void UnsubscribeFromUnit()
        {
            if (_unit == null) return;
            _unit.OnHPDamageTaken -= HandleHPDamage;
            _unit.OnShieldDamageTaken -= HandleShieldDamage;
            _unit.OnUnitDied -= HandleUnitDied;
            _unit.OnPointsChanged -= HandlePointsChanged;
            _unit.OnTurnStarted -= HandleTurnStarted;
        }
        private void HandleHPDamage(Unit u, int amount)
        {
            float prevSH = _shieldFillPts;
            float newHP = u.CurrentHP;
            float newSH = u.HasEnergyShield ? u.CurrentEnergyShield : 0f;

            _hpFillPts = newHP;
            _shieldFillPts = newSH;
            _shieldFillTarget = newSH;
            _mat.SetFloat(ID_LastDamageTime, Time.time);

            float startHPTrail = _hpTrailPts;
            float startSHTrail = _shieldTrailPts;

            UpdateShaderFills();
            CheckShieldDepletion(prevSH, newSH);
            RefreshStatLabel();

            _hpGlitch?.TriggerDamage(1.0f);
            _nameGlitch?.TriggerDamage(1.0f);
            if (prevSH > newSH) _shieldGlitch?.TriggerDamage(0.85f);

            StartUnifiedTrail(startHPTrail, startSHTrail, newHP, newSH);
        }

        private void HandleShieldDamage(Unit u, int amount) => HandleHPDamage(u, amount);

        private void HandleUnitDied(Unit u)
        {
            UnsubscribeFromUnit();
            _isDead = true;

            RefreshStatLabel();

            if (_nameGlitch != null) { _nameGlitch.GlitchOut(); _nameGlitch.enabled = false; }
            if (_hpGlitch != null) { _hpGlitch.GlitchOut(); _hpGlitch.enabled = false; }
            if (_shieldGlitch != null) { _shieldGlitch.GlitchOut(); _shieldGlitch.enabled = false; }

            if (_unifiedTrailCo != null) StopCoroutine(_unifiedTrailCo);

            _hpFillPts = 0f;
            _shieldFillPts = 0f;
            _shieldFillTarget = 0f;
            _shieldFillVelocity = 0f;
            _shieldTrailPts = 0f;
            _hpTrailPts = _targetCapacity;
            _capacityTargetPts = _targetCapacity;
            UpdateShaderFills();

            if (gameObject.activeInHierarchy)
            {
                StartCoroutine(DeathRoutine(_deathFadeDuration));
            }
            else
            {
                Destroy(gameObject);
            }
        }

        private IEnumerator DeathRoutine(float duration)
        {
            if (duration <= 0f)
            {
                Destroy(gameObject);
                yield break;
            }

            _rawImage.enabled = true;
            if (_labelsContainer != null) _labelsContainer.gameObject.SetActive(true);

            if (_mat != null) _mat.SetFloat(ID_LastDamageTime, Time.time);

            float riseSpeed = _mat != null ? _mat.GetFloat(ID_DeathRiseSpeed) : 0.18f;
            float fadeSpeed = _mat != null ? _mat.GetFloat(ID_DeathFadeSpeed) : 1.5f;
            float blockRandom = _mat != null ? _mat.GetFloat(ID_DeathBlockRandom) : 0.4f;
            float spread = _mat != null ? _mat.GetFloat(ID_DeathSpread) : 0.06f;

            if (_nameLabel != null && _nameLabel.gameObject.activeInHierarchy)
                StartCoroutine(AnimateTextDeathEffect(_nameLabel, duration, riseSpeed, fadeSpeed, blockRandom, spread));
            if (_hpLabel != null && _hpLabel.gameObject.activeInHierarchy)
                StartCoroutine(AnimateTextDeathEffect(_hpLabel, duration, riseSpeed, fadeSpeed, blockRandom, spread));
            if (_shieldLabel != null && _shieldLabel.gameObject.activeInHierarchy)
                StartCoroutine(AnimateTextDeathEffect(_shieldLabel, duration, riseSpeed, fadeSpeed, blockRandom, spread));

            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / duration);
                float deathProg = Mathf.Sin(t * Mathf.PI * 0.5f);

                if (_mat != null)
                    _mat.SetFloat(ID_DeathProgress, deathProg);

                yield return null;
            }

            Destroy(gameObject);
        }

        private IEnumerator AnimateTextDeathEffect(TextMeshProUGUI label, float duration,
            float riseSpeed, float fadeSpeed, float blockRandom, float spread)
        {
            if (label == null) yield break;

            label.ForceMeshUpdate();
            TMP_TextInfo textInfo = label.textInfo;
            int charCount = textInfo.characterCount;
            if (charCount == 0) yield break;

            Rect labelRect = label.rectTransform.rect;
            float rectH = Mathf.Max(labelRect.height, 1f);

            int meshCount = textInfo.meshInfo.Length;
            Vector3[][] origVerts = new Vector3[meshCount][];
            Color32[][] origColors = new Color32[meshCount][];
            for (int m = 0; m < meshCount; m++)
            {
                origVerts[m] = (Vector3[])textInfo.meshInfo[m].vertices.Clone();
                origColors[m] = (Color32[])textInfo.meshInfo[m].colors32.Clone();
            }

            float[] charNoise = new float[charCount];
            for (int i = 0; i < charCount; i++)
            {
                TMP_CharacterInfo ci = textInfo.characterInfo[i];
                float hx = ci.isVisible
                    ? origVerts[ci.materialReferenceIndex][ci.vertexIndex].x
                    : i * 13.7f;
                charNoise[i] = Mathf.Abs(Mathf.Sin(hx * 157.3f + i * 311.7f) * 43758.5453f) % 1f;
            }

            float elapsed = 0f;
            while (elapsed < duration)
            {
                elapsed += Time.deltaTime;
                float t = Mathf.Clamp01(elapsed / duration);

                float deathProg = Mathf.Sin(t * Mathf.PI * 0.5f);
                float wipeThreshold = 1.5f - deathProg * 2f;

                for (int m = 0; m < meshCount; m++)
                {
                    System.Array.Copy(origVerts[m], textInfo.meshInfo[m].vertices, origVerts[m].Length);
                    System.Array.Copy(origColors[m], textInfo.meshInfo[m].colors32, origColors[m].Length);
                }

                for (int i = 0; i < charCount; i++)
                {
                    TMP_CharacterInfo ci = textInfo.characterInfo[i];
                    if (!ci.isVisible) continue;

                    int meshIdx = ci.materialReferenceIndex;
                    int vertIdx = ci.vertexIndex;
                    Vector3[] verts = textInfo.meshInfo[meshIdx].vertices;
                    Color32[] colors = textInfo.meshInfo[meshIdx].colors32;

                    float cy = (origVerts[meshIdx][vertIdx].y + origVerts[meshIdx][vertIdx + 2].y) * 0.5f;
                    float normY = Mathf.Clamp01((cy - labelRect.yMin) / rectH);

                    float n = charNoise[i];
                    float dist = normY - wipeThreshold + n * blockRandom;
                    if (dist <= 0f) continue;

                    float deathAge = dist;
                    float rise = deathAge * riseSpeed * rectH;
                    float lateral = (n - 0.5f) * deathAge * spread * rectH;
                    float alpha = Mathf.Max(0f, 1f - deathAge * fadeSpeed);

                    Vector3 offset = new Vector3(lateral, rise, 0f);
                    for (int v = 0; v < 4; v++)
                    {
                        verts[vertIdx + v] += offset;
                        Color32 c = colors[vertIdx + v];
                        c.a = (byte)(c.a * alpha);
                        colors[vertIdx + v] = c;
                    }
                }

                for (int m = 0; m < meshCount; m++)
                {
                    Mesh subMesh = textInfo.meshInfo[m].mesh;
                    subMesh.vertices = textInfo.meshInfo[m].vertices;
                    subMesh.colors32 = textInfo.meshInfo[m].colors32;
                    label.UpdateGeometry(subMesh, m);
                }

                yield return null;
            }

            label.gameObject.SetActive(false);
        }

        private void HandlePointsChanged(Unit u)
        {
            float newHP = u.CurrentHP;
            float newSH = u.HasEnergyShield ? u.CurrentEnergyShield : 0f;
            bool changed = false;

            bool isShieldGain = false;

            if (Mathf.Abs(newHP - _hpFillPts) > 0.001f)
            {
                bool isHeal = newHP > _hpFillPts;
                _hpFillPts = newHP;
                if (isHeal) { _hpTrailPts = newHP; _mat.SetFloat(ID_LastHealTime, Time.time); }
                changed = true;
            }

            if (u.HasEnergyShield && Mathf.Abs(newSH - _shieldFillPts) > 0.001f)
            {
                bool justRestored = _shieldWasDepleted && newSH > 0f;
                if (justRestored)
                {
                    _shieldWasDepleted = false;
                    _mat.SetFloat(ID_ShieldDepleted, 0f);
                    _mat.SetFloat(ID_LastShieldRestoreTime, Time.time);
                }

                isShieldGain = newSH > _shieldFillPts;
                if (isShieldGain)
                {
                    _shieldFillTarget = newSH;
                    _shieldTrailPts = _shieldFillPts;
                    _capacityTargetPts = _hpTrailPts + newSH;
                    _mat.SetFloat(ID_LastShieldRestoreTime, Time.time);
                    _shieldGlitch?.TriggerDamage(0.6f);
                }
                else
                {
                    _shieldFillPts = newSH;
                    _shieldFillTarget = newSH;
                    _shieldFillVelocity = 0f;
                    _shieldTrailPts = Mathf.Max(_shieldTrailPts, _shieldFillPts);
                }
                changed = true;
            }

            if (changed)
            {
                if (!isShieldGain)
                {
                    _capacityTargetPts = _hpTrailPts + _shieldTrailPts;
                }

                UpdateShaderFills();
                RefreshStatLabel();
            }
        }

        private void HandleTurnStarted(Unit u) => HandlePointsChanged(u);

        private void CheckShieldDepletion(float prevSH, float newSH)
        {
            if (prevSH <= 0f || newSH > 0f || !_unit.HasEnergyShield) return;
            _shieldWasDepleted = true;
            _mat.SetFloat(ID_ShieldDepleted, 1f);
            _mat.SetFloat(ID_LastShieldDepletedTime, Time.time);
            float cap = Mathf.Max(1f, _currentCapacity);
            _mat.SetFloat(ID_ShatterCenter, _hpTrailPts / cap);
            _diamondRevealProgress = 0f;
            _diamondRevealVelocity = 0f;
            _mat.SetFloat(ID_DiamondRevealProgress, 0f);
        }
        private void UpdateShaderFills()
        {
            if (_mat == null || _unit == null || _unit.Stats == null) return;

            float maxHP = _unit.Stats.MaxHP;
            float currentTotal = _hpFillPts + _shieldFillPts;

            _targetCapacity = Mathf.Max(maxHP, currentTotal, _capacityTargetPts);
            if (_currentCapacity <= 0f) _currentCapacity = _targetCapacity;
            if (_targetCapacity < _currentCapacity) { _currentCapacity = _targetCapacity; _capacityVelocity = 0f; }

            PushFillsToShader();
        }

        private void PushFillsToShader()
        {
            if (_mat == null) return;
            float cap = Mathf.Max(1f, _currentCapacity);

            _mat.SetFloat(ID_HPFill, _hpFillPts / cap);
            _mat.SetFloat(ID_HPTrail, _hpTrailPts / cap);
            _mat.SetFloat(ID_HPPreview, (_isPreviewing ? _hpPreviewPts : _hpFillPts) / cap);
            _mat.SetFloat(ID_ShieldFill, _shieldFillPts / cap);
            _mat.SetFloat(ID_ShieldTrail, _shieldTrailPts / cap);
            _mat.SetFloat(ID_ShieldPreview, (_isPreviewing ? _shieldPreviewPts : _shieldFillPts) / cap);
            _mat.SetFloat(ID_SplitRatio, _hpTrailPts / cap);

            bool shVis = (_shieldFillPts > 0f || _shieldTrailPts > 0f) && _unit.HasEnergyShield;
            _mat.SetFloat(ID_ShieldEnabled, shVis ? 1f : 0f);
        }

        private void StartUnifiedTrail(float fromHP, float fromSH, float toHP, float toSH)
        {
            if (!gameObject.activeInHierarchy)
            {
                _hpTrailPts = toHP;
                _shieldTrailPts = toSH;
                _capacityTargetPts = toHP + toSH;
                UpdateShaderFills();
                return;
            }

            if (_unifiedTrailCo != null) StopCoroutine(_unifiedTrailCo);
            _unifiedTrailCo = StartCoroutine(
                UnifiedTrailRoutine(fromHP, fromSH, toHP, toSH,
                                    _capacityTargetPts, toHP + toSH));
        }

        private IEnumerator UnifiedTrailRoutine(float fromHP, float fromSH, float toHP, float toSH,
                                                float fromCap, float toCap)
        {
            yield return new WaitForSeconds(_trailDelay);
            float elapsed = 0f;
            while (elapsed < _trailDuration)
            {
                elapsed += Time.deltaTime;
                float e = _trailEase.Evaluate(Mathf.Clamp01(elapsed / _trailDuration));
                _hpTrailPts = Mathf.Lerp(fromHP, toHP, e);
                _shieldTrailPts = Mathf.Lerp(fromSH, toSH, e);
                _capacityTargetPts = Mathf.Lerp(fromCap, toCap, e);
                UpdateShaderFills();
                yield return null;
            }
            _hpTrailPts = toHP; _shieldTrailPts = toSH; _capacityTargetPts = toCap;
            UpdateShaderFills();
        }

        private void ForceFullSync()
        {
            if (_unit == null || _unit.Stats == null) return;
            bool hasShield = _unit.HasEnergyShield;
            int curShield = hasShield ? _unit.CurrentEnergyShield : 0;

            _hpFillPts = _hpTrailPts = _unit.CurrentHP;
            _shieldFillPts = _shieldTrailPts = curShield;
            _capacityTargetPts = _hpFillPts + _shieldFillPts;
            _targetCapacity = Mathf.Max(_unit.Stats.MaxHP, _capacityTargetPts);
            _currentCapacity = _targetCapacity;

            _shieldFillTarget = _shieldFillPts;

            UpdateShaderFills();
            if (_mat != null) _mat.SetFloat(ID_Team, TeamToFloat(_unit.Team));
            _shieldWasDepleted = hasShield && curShield <= 0;
            if (_mat != null) _mat.SetFloat(ID_ShieldDepleted, _shieldWasDepleted ? 1f : 0f);

            _diamondRevealProgress = (hasShield && !_shieldWasDepleted) ? 1f : 0f;
            _diamondRevealVelocity = 0f;
            _mat.SetFloat(ID_DiamondRevealProgress, _diamondRevealProgress);

            ApplyLabelBaseColors();

            if (_nameLabel != null)
            {
                _nameLabel.text = _unit.Stats?.UnitName ?? _unit.name;
                _nameGlitch?.Initialize(startVisible: false);
                _nameGlitch?.UpdateValue(_nameLabel.text, immediate: true);
            }
            if (_hpLabel != null)
            {
                _hpGlitch?.Initialize(startVisible: false);
                _hpGlitch?.UpdateValue(_unit.CurrentHP.ToString(), immediate: true);
            }
            if (_shieldLabel != null)
            {
                _shieldGlitch?.Initialize(startVisible: false);
                string sh = (hasShield && curShield > 0) ? curShield.ToString() : "";
                _shieldGlitch?.UpdateValue(sh, immediate: true);
            }
        }

        private void RefreshStatLabel()
        {
            if (_unit == null) return;
            string hpStr = _unit.CurrentHP.ToString();
            string shStr = (_unit.HasEnergyShield && _unit.CurrentEnergyShield > 0)
                           ? _unit.CurrentEnergyShield.ToString() : "";

            bool immediateUpdate = !_isHovered;

            if (_hpGlitch != null) _hpGlitch.UpdateValue(hpStr, immediate: immediateUpdate);
            else if (_hpLabel != null) _hpLabel.SetText(hpStr);

            if (_shieldGlitch != null) _shieldGlitch.UpdateValue(shStr, immediate: immediateUpdate);
            else if (_shieldLabel != null) _shieldLabel.SetText(shStr);
            if (_hpLabel != null) _hpLabel.SetText(hpStr);
            if (_shieldLabel != null) _shieldLabel.SetText(shStr);
        }

        private void ApplyLabelBaseColors()
        {
            Color hpColor = _unit.Team switch
            {
                UnitTeam.Player => _playerHPTextColor,
                UnitTeam.Enemy => _enemyHPTextColor,
                UnitTeam.Neutral => _neutralHPTextColor,
                _ => _playerHPTextColor
            };
            hpColor.a = 1f;

            Color shieldColor = _shieldTextColor; shieldColor.a = 1f;
            Color nameFaceColor = _colorNameByTeam ? hpColor : _defaultNameColor; nameFaceColor.a = 1f;

            _baseHPColor = hpColor;
            _baseShieldColor = shieldColor;

            if (_nameLabel != null) _nameLabel.color = nameFaceColor;
            if (_hpLabel != null) _hpLabel.color = hpColor;
            if (_shieldLabel != null) _shieldLabel.color = shieldColor;

            _nameGlitch?.SetThemeColor(hpColor);
            _hpGlitch?.SetThemeColor(hpColor);
            _shieldGlitch?.SetThemeColor(shieldColor);
        }

        private void UpdatePreviewGlow()
        {
            float rawSine = Mathf.Sin(Time.time * _glowPulseFreq);
            float pulse01 = 0.5f + 0.5f * rawSine;

            bool isPreviewActive = _isPreviewing && _previewAlphaTarget > 0f;

            if (_hpLabel != null)
            {
                bool affected = isPreviewActive && (_hpFillPts - _hpPreviewPts) > 0.5f;
                float targetAlpha = affected ? 1f : 0f;
                float fadeSpeed = affected ? _previewFadeSpeed : 4f;

                _hpGlowAlpha = Mathf.MoveTowards(_hpGlowAlpha, targetAlpha, Time.deltaTime * fadeSpeed);

                float currentHPScale = 1f + (rawSine * _textSizePulseAmount * _hpGlowAlpha);
                _hpLabel.transform.localScale = new Vector3(currentHPScale, currentHPScale, 1f);

                if (_hpGlowAlpha > 0.001f)
                {
                    float g = Mathf.Lerp(_glowMinIntensity, _glowMaxIntensity, pulse01);
                    if (_intensifyNearDepletion && _hpFillPts > 0.001f)
                        g = Mathf.Clamp01(g * Mathf.Lerp(1f, _depletionIntensityMult, 1f - _hpPreviewPts / _hpFillPts));

                    float finalGlow = g * _hpGlowAlpha;
                    Color col = Color.Lerp(_baseHPColor, _hpGlowColor, finalGlow);
                    col.a = _hpLabel.color.a;
                    _hpLabel.color = col;
                    _hpGlitch?.SetThemeColor(col);
                }
                else if (_hpLabel.color != _baseHPColor)
                {
                    Color col = _baseHPColor;
                    col.a = _hpLabel.color.a;
                    _hpLabel.color = col;
                    _hpGlitch?.SetThemeColor(col);
                }
            }

            if (_shieldLabel != null)
            {
                bool affected = isPreviewActive && _unit != null && _unit.HasEnergyShield && (_shieldFillPts - _shieldPreviewPts) > 0.5f;
                float targetAlpha = affected ? 1f : 0f;
                float fadeSpeed = affected ? _previewFadeSpeed : 4f;

                _shieldGlowAlpha = Mathf.MoveTowards(_shieldGlowAlpha, targetAlpha, Time.deltaTime * fadeSpeed);

                float currentShieldScale = 1f + (rawSine * _textSizePulseAmount * _shieldGlowAlpha);
                _shieldLabel.transform.localScale = new Vector3(currentShieldScale, currentShieldScale, 1f);

                if (_shieldGlowAlpha > 0.001f)
                {
                    float g = Mathf.Lerp(_glowMinIntensity, _glowMaxIntensity, pulse01);
                    if (_intensifyNearDepletion && _shieldFillPts > 0.001f)
                        g = Mathf.Clamp01(g * Mathf.Lerp(1f, _depletionIntensityMult, 1f - _shieldPreviewPts / _shieldFillPts));

                    float finalGlow = g * _shieldGlowAlpha;
                    Color col = Color.Lerp(_baseShieldColor, _shieldGlowColor, finalGlow);
                    col.a = _shieldLabel.color.a;
                    _shieldLabel.color = col;
                    _shieldGlitch?.SetThemeColor(col);
                }
                else if (_shieldLabel.color != _baseShieldColor)
                {
                    Color col = _baseShieldColor;
                    col.a = _shieldLabel.color.a;
                    _shieldLabel.color = col;
                    _shieldGlitch?.SetThemeColor(col);
                }
            }
        }

        private void AnimateHover()
        {
            bool isFocusActive = (_previewAlphaTarget > 0f) ||
                                 (_hpTrailPts > _hpFillPts + 0.001f) ||
                                 (_shieldTrailPts > _shieldFillPts + 0.001f);

            float targetScale;
            float targetPush;
            float scaleSpeed;

            if (_isHovered)
            {
                targetScale = 1f;
                targetPush = _barPushUpAmount;
                scaleSpeed = _hoverAnimSpeed;
            }
            else if (isFocusActive)
            {
                targetScale = _focusScale;
                targetPush = _barPushUpAmount;
                scaleSpeed = (_currentScale > _focusScale) ? _hoverAnimSpeed : _focusTransitionSpeed;
            }
            else
            {
                targetScale = _hoverMiniScale;
                targetPush = 0f;
                scaleSpeed = (_currentScale > _focusScale + 0.01f) ? _hoverAnimSpeed : _focusTransitionSpeed;
            }

            float smoothTime = 1f / scaleSpeed;

            _currentScale = Mathf.SmoothDamp(_currentScale, targetScale, ref _scaleVelocity, smoothTime);
            _barPushCurrent = Mathf.SmoothDamp(_barPushCurrent, targetPush, ref _barPushVelocity, smoothTime);

            float qteAlphaMultiplier = 1f;
            if (QTEManager.Instance != null && QTEManager.Instance.IsSpotlightActive)
            {
                if (QTEManager.Instance.SpotlightUnitA != _unit && QTEManager.Instance.SpotlightUnitB != _unit)
                {
                    qteAlphaMultiplier = 1f - QTEManager.Instance.CurrentDimmingAlpha;
                }
            }

            float shaderHoverState = Mathf.InverseLerp(_hoverMiniScale, 1f, _currentScale);
            if (_mat != null)
            {
                _mat.SetFloat(ID_HoverState, shaderHoverState);
                _mat.SetFloat(ID_MasterAlpha, qteAlphaMultiplier);
            }

            if (_labelsContainer != null)
            {
                _labelsContainer.localScale = new Vector3(_currentScale, _currentScale, 1f);
            }

            float targetAlpha = _isHovered ? 1f : 0f;
            float alphaSpeed = _isHovered ? _labelFadeInSpeed : _labelFadeOutSpeed;
            float prevFade = _labelFadeLinear;

            _labelFadeLinear = Mathf.MoveTowards(_labelFadeLinear, targetAlpha, Time.deltaTime * alphaSpeed);
            float easedLabelAlpha = Mathf.SmoothStep(0f, 1f, _labelFadeLinear);

            float finalCombinedTextAlpha = easedLabelAlpha * qteAlphaMultiplier;

            if (_labelsCanvasGroup != null) _labelsCanvasGroup.alpha = finalCombinedTextAlpha;

            if (!_isDead)
            {
                _nameGlitch?.SetEffectAlpha(finalCombinedTextAlpha);
                _hpGlitch?.SetEffectAlpha(finalCombinedTextAlpha);
                _shieldGlitch?.SetEffectAlpha(finalCombinedTextAlpha);

                if (_isHovered && !_wasHovered) OnHoverEnter();
                if (!_isHovered && _wasHovered) OnHoverExit();
            }

            if (prevFade > 0f && _labelFadeLinear <= 0f && !_isDead)
            {
                ForceLabelsImmediate();
            }

            _wasHovered = _isHovered;
        }

        private void OnHoverEnter()
        {
            _nameGlitch?.ResetSweepTimer(); _nameGlitch?.GlitchIn();
            _hpGlitch?.ResetSweepTimer(); _hpGlitch?.GlitchIn();
            if (_unit != null && _unit.HasEnergyShield && _unit.CurrentEnergyShield > 0)
            { _shieldGlitch?.ResetSweepTimer(); _shieldGlitch?.GlitchIn(); }
        }

        private void OnHoverExit()
        {
            _nameGlitch?.GlitchOut(); _hpGlitch?.GlitchOut(); _shieldGlitch?.GlitchOut();
        }

        private void ForceLabelsImmediate()
        {
            if (_unit == null) return;
            string hpStr = _unit.CurrentHP.ToString();
            string shStr = (_unit.HasEnergyShield && _unit.CurrentEnergyShield > 0)
                           ? _unit.CurrentEnergyShield.ToString() : "";

            _nameGlitch?.UpdateValue(_unit.Stats?.UnitName ?? _unit.name, immediate: true);
            _hpGlitch?.UpdateValue(hpStr, immediate: true);
            _shieldGlitch?.UpdateValue(shStr, immediate: true);

            if (_hpLabel != null) _hpLabel.SetText(hpStr);
            if (_shieldLabel != null) _shieldLabel.SetText(shStr);
        }

        private void PositionOverUnit()
        {
            Vector3 targetWorldPos = _isDead ? _lastWorldPos : _unit.transform.position;
            Vector3 worldPos = targetWorldPos + _worldOffset;
            Vector3 screenPos = _cam.WorldToScreenPoint(worldPos);

            bool offScreen = screenPos.z < 0f;
            bool shouldBeVisible = !offScreen && (_isDead || !_hiddenByManager);

            if (_rawImage.enabled != shouldBeVisible)
            {
                _rawImage.enabled = shouldBeVisible;
            }

            if (_labelsContainer != null && _labelsContainer.gameObject.activeSelf != shouldBeVisible)
            {
                _labelsContainer.gameObject.SetActive(shouldBeVisible);
            }

            if (offScreen) return;

            Canvas canvas = GetComponentInParent<Canvas>();
            Camera uiCam = canvas != null && canvas.renderMode != RenderMode.ScreenSpaceOverlay
                            ? canvas.worldCamera : null;

            if (RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    (RectTransform)transform.parent, screenPos, uiCam, out Vector2 local))
            {
                local.y += _barPushCurrent;
                ((RectTransform)transform).anchoredPosition = local;
            }
        }

        private static float TeamToFloat(UnitTeam team) => team switch
        {
            UnitTeam.Player => 0f,
            UnitTeam.Enemy => 1f,
            UnitTeam.Neutral => 2f,
            _ => 0f
        };
    }
}