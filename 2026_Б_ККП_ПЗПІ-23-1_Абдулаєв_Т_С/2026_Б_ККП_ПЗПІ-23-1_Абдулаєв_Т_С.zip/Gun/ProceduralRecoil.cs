using System.Collections.Generic;
using UnityEngine;

public class ProceduralRecoil : MonoBehaviour
{
    [System.Serializable]
    public class RecoilBone
    {
        public string name;
        [Tooltip("The IK Target transform (e.g. RightHandIK_Target)")]
        public Transform boneTransform;
        [Range(0f, 2f)] public float positionInfluence = 1f;
        [Range(0f, 2f)] public float rotationInfluence = 1f;
    }

    [Header("Configuration")]
    [Tooltip("How much force is applied backward per shot.")]
    [SerializeField] private float recoilKickBack = 0.2f;
    [Tooltip("How much the gun rotates up per shot (muzzle climb).")]
    [SerializeField] private float recoilRotation = 10f;

    [Header("Feel")]
    [Tooltip("How fast it snaps to the recoil point. Higher = snappier.")]
    [SerializeField] private float snappiness = 20f;
    [Tooltip("How fast it returns to rest. Higher = lighter gun feel.")]
    [SerializeField] private float returnSpeed = 10f;

    [Header("Targets")]
    [Tooltip("IK Targets to affect (Right Hand, Left Hand, Spine Aim Target, etc.)")]
    [SerializeField] private List<RecoilBone> affectedBones = new List<RecoilBone>();

    private Vector3 _targetPosition;
    private Vector3 _currentPosition;
    private Vector3 _targetRotation;
    private Vector3 _currentRotation;

    private void Update()
    {
        _targetPosition = Vector3.Lerp(_targetPosition, Vector3.zero, returnSpeed * Time.deltaTime);
        _targetRotation = Vector3.Lerp(_targetRotation, Vector3.zero, returnSpeed * Time.deltaTime);

        _currentPosition = Vector3.Lerp(_currentPosition, _targetPosition, snappiness * Time.deltaTime);
        _currentRotation = Vector3.Lerp(_currentRotation, _targetRotation, snappiness * Time.deltaTime);
    }

    private void LateUpdate()
    {
        if (affectedBones.Count == 0) return;

        foreach (var bone in affectedBones)
        {
            if (bone.boneTransform == null) continue;

            bone.boneTransform.position += _currentPosition * bone.positionInfluence;
            bone.boneTransform.localRotation *= Quaternion.Euler(_currentRotation * bone.rotationInfluence);
        }
    }

    public void TriggerRecoil(Vector3 fireDirection)
    {
        _targetPosition += -fireDirection.normalized * recoilKickBack;

        float randomTilt = Random.Range(-0.5f, 0.5f) * recoilRotation;
        _targetRotation += new Vector3(-recoilRotation, randomTilt, 0f);
    }
}