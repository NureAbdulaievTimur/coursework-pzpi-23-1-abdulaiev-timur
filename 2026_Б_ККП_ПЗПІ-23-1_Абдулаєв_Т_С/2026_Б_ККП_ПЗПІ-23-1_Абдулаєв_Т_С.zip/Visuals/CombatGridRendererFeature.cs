using UnityEngine;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace CombatGrid
{
    public class CombatGridRenderFeature : ScriptableRendererFeature
    {
        [System.Serializable]
        public class Settings
        {
            [Tooltip("Material using the CombatGridOverlay shader.")]
            public Material OverlayMaterial;

            [Tooltip("When to inject the pass relative to other effects.")]
            public RenderPassEvent InjectionPoint = RenderPassEvent.AfterRenderingPostProcessing;
        }

        public Settings settings = new();

        private CombatGridOverlayPass _pass;

        public override void Create()
        {
            _pass = new CombatGridOverlayPass(settings);
        }

        public override void AddRenderPasses(ScriptableRenderer renderer, ref RenderingData renderingData)
        {
            if (settings.OverlayMaterial == null) return;

            var cameraType = renderingData.cameraData.cameraType;
            if (cameraType == CameraType.Preview || cameraType == CameraType.Reflection)
                return;

            renderer.EnqueuePass(_pass);
        }

        private class CombatGridOverlayPass : ScriptableRenderPass
        {
            private static readonly int BlitTextureID = Shader.PropertyToID("_BlitTexture");
            private static readonly int BlitScaleBiasID = Shader.PropertyToID("_BlitScaleBias");

            private readonly Settings _settings;
            private RTHandle _tempRT;

            public CombatGridOverlayPass(Settings settings)
            {
                _settings = settings;
                renderPassEvent = settings.InjectionPoint;
                profilingSampler = new ProfilingSampler("CombatGridOverlay");
            }

            public override void OnCameraSetup(CommandBuffer cmd, ref RenderingData renderingData)
            {
                var descriptor = renderingData.cameraData.cameraTargetDescriptor;
                descriptor.depthBufferBits = 0;
                RenderingUtils.ReAllocateIfNeeded(
                    ref _tempRT, descriptor, FilterMode.Bilinear,
                    TextureWrapMode.Clamp, name: "_CombatGridTemp");
            }

            public override void Execute(ScriptableRenderContext context, ref RenderingData renderingData)
            {
                if (_settings.OverlayMaterial == null) return;

                CommandBuffer cmd = CommandBufferPool.Get("CombatGridOverlay");

                using (new ProfilingScope(cmd, profilingSampler))
                {
                    var renderer = renderingData.cameraData.renderer;
                    var source = renderer.cameraColorTargetHandle;

                    Blitter.BlitCameraTexture(cmd, source, source, _settings.OverlayMaterial, 0);
                }

                context.ExecuteCommandBuffer(cmd);
                CommandBufferPool.Release(cmd);
            }

            public override void OnCameraCleanup(CommandBuffer cmd)
            {
            }

            public void Dispose()
            {
                _tempRT?.Release();
            }
        }

        protected override void Dispose(bool disposing)
        {
            _pass?.Dispose();
        }
    }
}