using UnityEngine;

public enum SurfaceType { Default, Flesh, Shield, Wood, Metal, Stone }

public class SurfaceIdentity : MonoBehaviour
{
    [SerializeField] private SurfaceType surfaceType = SurfaceType.Default;

    public SurfaceType GetSurfaceType()
    {
        return surfaceType;
    }
}