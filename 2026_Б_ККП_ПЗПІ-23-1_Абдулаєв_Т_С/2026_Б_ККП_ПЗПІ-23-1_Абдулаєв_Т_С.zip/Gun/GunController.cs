using System;
using System.Collections;
using UnityEngine;
using UnityEngine.Animations.Rigging;
using CombatGrid;

public class GunController : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Transform bulletSpawnPoint;
    [SerializeField] private ParticleSystem muzzleFlash;

    [Header("Hand IK - Left Hand")]
    [SerializeField] private Rig leftHandLoweredRig;
    [SerializeField] private Rig leftHandAimingRig;

    [Header("Hand IK - Right Hand")]
    [SerializeField] private Rig rightHandLoweredRig;
    [SerializeField] private Rig rightHandAimingRig;

    [Header("Hand IK - Blending")]
    [SerializeField] private float ikBlendSpeed = 10f;
    [SerializeField] private bool snapToAim = false;
    [Range(0f, 1f)]
    [SerializeField] private float raisedCrouchWeight = 0.75f;

    [Header("Impact Settings")]
    [SerializeField] private SurfaceEffectConfig surfaceEffects;

    [Header("Penetration & Exit Wounds")]
    [SerializeField] private float penetrationDepth = 1.0f;
    [SerializeField] private float decalOffset = 0.01f;

    [Header("Recoil")]
    [SerializeField] private ProceduralRecoil proceduralRecoil;

    [Header("Weapon Stats")]
    [SerializeField] private float range = 100f;
    [SerializeField] private LayerMask hitMask;
    [SerializeField] private LayerMask environmentOnlyMask;
    [SerializeField] private float spread = 0.01f;

    [Header("Physics Impact")]
    [SerializeField] private float bulletImpactForce = 100f;
    [SerializeField] private float deathImpulseMultiplier = 15f;

    [Header("Visuals")]
    [SerializeField] private bool useBulletTrail = true;
    [SerializeField] private TrailRenderer bulletTrailPrefab;
    [SerializeField] private float bulletSpeed = 200f;

    [SerializeField] private GameObject bulletCasingPrefab;
    [SerializeField] private Transform ejectPort;
    [SerializeField] private float ejectForce = 2f;
    [SerializeField] private float ejectUpwardForce = 1.0f;
    [SerializeField] private float ejectSidewaysForce = 1.0f;
    [SerializeField] private float ejectBackwardForce = 0.3f;

    private float _aimWeight = 0f;
    private float _currentAimWeight = 0f;
    private UnitMovement _unitMovement;

    private Vector3 _debugLastShotOrigin;
    private Vector3 _debugLastShotDirection;
    private Vector3 _debugEntry;
    private Vector3 _debugExit;
    private bool _debugDidHit;
    private bool _debugDidExit;

    private void Start()
    {
        _unitMovement = GetComponentInParent<UnitMovement>();
        _aimWeight = 1f;
        _currentAimWeight = 1f;
        ApplyIKWeights(_currentAimWeight);
    }

    private void Update()
    {
        if (Mathf.Approximately(_currentAimWeight, _aimWeight)) return;

        _currentAimWeight = snapToAim
            ? _aimWeight
            : Mathf.MoveTowards(_currentAimWeight, _aimWeight, ikBlendSpeed * Time.deltaTime);

        ApplyIKWeights(_currentAimWeight);
    }

    public void SetAiming(bool isAiming)
    {
        _aimWeight = isAiming ? 1f : 0f;
    }

    private void ApplyIKWeights(float aimWeight)
    {
        float loweredWeight = 1f - aimWeight;

        bool isCrouching = _unitMovement != null && _unitMovement.IsCrouching;
        float effectiveAimWeight = isCrouching
            ? Mathf.Min(aimWeight, raisedCrouchWeight)
            : aimWeight;

        if (leftHandLoweredRig != null) leftHandLoweredRig.weight = loweredWeight;
        if (leftHandAimingRig != null) leftHandAimingRig.weight = effectiveAimWeight;
        if (rightHandLoweredRig != null) rightHandLoweredRig.weight = loweredWeight;
        if (rightHandAimingRig != null) rightHandAimingRig.weight = effectiveAimWeight;
    }

    public void Shoot(Vector3 aimPoint, LayerMask maskToUse, Unit intendedTarget = null,
                  SurfaceType? primarySurface = null, SurfaceType? secondarySurface = null,
                  bool triggerFlinch = false, bool shieldBroke = false, bool isLogicalHit = false)
    {
        if (RobotScannerManager.Instance != null)
            RobotScannerManager.Instance.Scan(transform.position + new Vector3(0, 0.1f, 0));

        if (muzzleFlash != null) muzzleFlash.Play();
        EjectCasing();

        Vector3 direction = (aimPoint - bulletSpawnPoint.position).normalized;

        if (proceduralRecoil != null)
            proceduralRecoil.TriggerRecoil(direction);

        direction += UnityEngine.Random.insideUnitSphere * spread;
        direction.Normalize();

        _debugLastShotOrigin = bulletSpawnPoint.position;
        _debugLastShotDirection = direction;
        _debugDidExit = false;

        RaycastHit[] hits = Physics.RaycastAll(bulletSpawnPoint.position, direction, range, maskToUse);

        Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));

        bool foundValidHit = false;
        RaycastHit entryHit = default;

        if (isLogicalHit && intendedTarget != null)
        {
            foreach (RaycastHit hit in hits)
            {
                Unit hitUnit = hit.collider.GetComponentInParent<Unit>();
                if (hitUnit == intendedTarget)
                {
                    entryHit = hit;
                    foundValidHit = true;
                    break;
                }
            }
        }

        if (!foundValidHit)
        {
            foreach (RaycastHit hit in hits)
            {
                Unit hitUnit = hit.collider.GetComponentInParent<Unit>();

                if (hitUnit != null && intendedTarget != null && hitUnit != intendedTarget)
                {
                    continue;
                }

                entryHit = hit;
                foundValidHit = true;
                break;
            }
        }

        if (foundValidHit)
        {
            _debugDidHit = true;
            _debugEntry = entryHit.point;

            var config1 = primarySurface.HasValue
                ? surfaceEffects.GetEffect(primarySurface.Value)
                : GetSurfaceConfig(entryHit.collider);

            var config2 = secondarySurface.HasValue
                ? surfaceEffects.GetEffect(secondarySurface.Value)
                : null;

            Vector3? shieldSurfacePos = null;
            bool c1IsShield = config1 != null && config1.surfaceType == SurfaceType.Shield;
            bool c2IsShield = config2 != null && config2.surfaceType == SurfaceType.Shield;

            if ((c1IsShield || c2IsShield || shieldBroke) && intendedTarget != null)
            {
                ShieldVisuals shieldVis = intendedTarget.GetComponentInChildren<ShieldVisuals>();
                if (shieldVis != null)
                {
                    Bounds b = shieldVis.GetShieldBounds();
                    Vector3 centerToHit = (entryHit.point - b.center).normalized;
                    Vector3 worldImpactDir = (centerToHit - direction).normalized;
                    float radius = Mathf.Max(b.extents.x, b.extents.y, b.extents.z);
                    shieldSurfacePos = b.center + worldImpactDir * radius;
                }
            }

            HandleSurfaceImpact(entryHit, direction, false, config1, c1IsShield ? shieldSurfacePos : null);
            if (config2 != null) HandleSurfaceImpact(entryHit, direction, false, config2, c2IsShield ? shieldSurfacePos : null);

            Unit targetUnit = entryHit.collider.GetComponentInParent<Unit>();

            if (intendedTarget != null && (isLogicalHit || targetUnit == intendedTarget))
            {
                ShieldVisuals shieldVis = intendedTarget.GetComponentInChildren<ShieldVisuals>();
                if (shieldVis != null)
                {
                    if (shieldBroke)
                        shieldVis.RegisterHit(entryHit.point, direction, true);
                    else if (primarySurface == SurfaceType.Shield || secondarySurface == SurfaceType.Shield)
                        shieldVis.RegisterHit(entryHit.point, direction, false);
                }
            }

            if (targetUnit != null)
            {
                if (!targetUnit.IsAlive)
                {
                    RagdollManager ragdoll = targetUnit.GetComponent<RagdollManager>();
                    if (ragdoll != null && ragdoll.useRagdollOnDeath)
                    {
                        Rigidbody hitPart = entryHit.collider.GetComponent<Rigidbody>();
                        ragdoll.TriggerDeath(direction * deathImpulseMultiplier, entryHit.point, hitPart);
                    }
                }
                else if (triggerFlinch)
                {
                    ImpactReceiver receiver = entryHit.collider.GetComponent<ImpactReceiver>();
                    if (receiver == null) receiver = entryHit.collider.GetComponentInParent<ImpactReceiver>();
                    if (receiver != null) receiver.AddImpact(direction, bulletImpactForce);
                }
            }

            if (config1 != null && config1.isPenetrable)
            {
                Vector3 backTraceOrigin = entryHit.point + direction * penetrationDepth;
                RaycastHit[] backHits = Physics.RaycastAll(backTraceOrigin, -direction, penetrationDepth, hitMask);

                foreach (RaycastHit backHit in backHits)
                {
                    if (backHit.collider == entryHit.collider &&
                        Vector3.Distance(entryHit.point, backHit.point) > 0.05f)
                    {
                        _debugExit = backHit.point;
                        _debugDidExit = true;
                        HandleSurfaceImpact(backHit, direction, isExit: true, config1);
                        break;
                    }
                }
            }

            if (useBulletTrail && bulletTrailPrefab != null)
                StartCoroutine(SpawnTrail(entryHit.point));
        }
        else
        {
            _debugDidHit = false;
            if (useBulletTrail && bulletTrailPrefab != null)
                StartCoroutine(SpawnTrail(bulletSpawnPoint.position + direction * range));
        }
    }

    public void ShootAtTarget(Unit intendedTarget, Vector3 targetPoint, Vector3 targetRight, AttackResult result)
    {
        SurfaceType? primarySurface = null;
        SurfaceType? secondarySurface = null;
        bool triggerFlinch = false;
        LayerMask maskToUse = hitMask;

        bool shieldBroke = result.ShieldDamageDealt > 0
                           && intendedTarget != null
                           && intendedTarget.CurrentEnergyShield <= 0;

        if (result.DidHit)
        {
            targetPoint += UnityEngine.Random.insideUnitSphere * 0.12f;

            if (result.ShieldDamageDealt > 0 && result.HPDamageDealt > 0)
            {
                primarySurface = SurfaceType.Flesh;
                triggerFlinch = true;
            }
            else if (result.HPDamageDealt > 0)
            {
                primarySurface = SurfaceType.Flesh;
                triggerFlinch = true;
            }
            else if (result.ShieldDamageDealt > 0 && !shieldBroke)
            {
                primarySurface = SurfaceType.Shield;
                triggerFlinch = false;
            }
        }
        else
        {
            float missDir = (UnityEngine.Random.value > 0.5f) ? 1f : -1f;
            targetPoint += (targetRight * missDir * 0.8f) + (UnityEngine.Random.insideUnitSphere * 0.3f);
            maskToUse = environmentOnlyMask;
            triggerFlinch = false;
        }

        Shoot(targetPoint, maskToUse, intendedTarget, primarySurface, secondarySurface, triggerFlinch, shieldBroke, result.DidHit);
    }

    private SurfaceEffectConfig.SurfaceEffectEntry GetSurfaceConfig(Collider col)
    {
        if (surfaceEffects == null) return null;

        SurfaceType type = SurfaceType.Default;
        if (col.TryGetComponent<SurfaceIdentity>(out var identity))
            type = identity.GetSurfaceType();

        return surfaceEffects.GetEffect(type);
    }

    private void HandleSurfaceImpact(RaycastHit hit, Vector3 bulletDirection, bool isExit,
                                 SurfaceEffectConfig.SurfaceEffectEntry config,
                                 Vector3? spawnPosOverride = null)
    {
        if (config == null) return;

        Vector3 effectOrigin = spawnPosOverride ?? hit.point;

        GameObject particlePrefab = isExit ? config.exitImpactParticles : config.entryImpactParticles;
        GameObject decalPrefab = isExit ? config.exitHolePrefab : config.entryHolePrefab;

        if (particlePrefab != null)
        {
            Quaternion rot = isExit
                ? Quaternion.LookRotation(bulletDirection)
                : Quaternion.LookRotation(-bulletDirection);
            Instantiate(particlePrefab, effectOrigin, rot);
        }

        if (decalPrefab != null)
        {
            Vector3 spawnPos;
            Quaternion decalRot;

            if (config.surfaceType == SurfaceType.Flesh)
            {
                spawnPos = effectOrigin;
                decalRot = Quaternion.LookRotation(bulletDirection);
            }
            else
            {
                bool isShieldSurface = config.surfaceType == SurfaceType.Shield;
                spawnPos = effectOrigin + (isShieldSurface ? bulletDirection : hit.normal) * decalOffset;
                decalRot = Quaternion.LookRotation(isShieldSurface ? -bulletDirection : -hit.normal);
            }

            GameObject hole = Instantiate(decalPrefab, spawnPos, decalRot);

            SurfaceIdentity identity = hit.collider.GetComponent<SurfaceIdentity>();
            if (config.surfaceType == SurfaceType.Flesh && identity != null && identity.GetSurfaceType() == SurfaceType.Shield)
            {
                Unit targetU = hit.collider.GetComponentInParent<Unit>();
                hole.transform.SetParent(targetU != null ? targetU.transform : hit.transform);
            }
            else
            {
                hole.transform.SetParent(hit.transform);
            }
        }
    }

    private void EjectCasing()
    {
        if (bulletCasingPrefab == null || ejectPort == null) return;

        GameObject casing = Instantiate(bulletCasingPrefab, ejectPort.position, ejectPort.rotation);
        if (casing.TryGetComponent<Rigidbody>(out Rigidbody rb))
        {
            Vector3 forceDir = (ejectPort.up * ejectUpwardForce +
                                ejectPort.right * ejectSidewaysForce +
                               -ejectPort.forward * ejectBackwardForce).normalized;

            rb.AddForce(forceDir * ejectForce, ForceMode.Impulse);
            rb.AddTorque(UnityEngine.Random.insideUnitSphere * 0.5f, ForceMode.Impulse);
        }
    }

    private IEnumerator SpawnTrail(Vector3 destination)
    {
        TrailRenderer trail = Instantiate(bulletTrailPrefab, bulletSpawnPoint.position, Quaternion.identity);
        Vector3 startPosition = trail.transform.position;
        float distance = Vector3.Distance(startPosition, destination);
        float duration = distance / bulletSpeed;
        float time = 0f;

        while (time < duration)
        {
            trail.transform.position = Vector3.Lerp(startPosition, destination, time / duration);
            time += Time.deltaTime;
            yield return null;
        }

        trail.transform.position = destination;
        Destroy(trail.gameObject, trail.time);
    }

    private void OnDrawGizmosSelected()
    {
        if (!Application.isPlaying) return;

        Gizmos.color = _debugDidHit ? Color.green : Color.red;
        Vector3 endPoint = _debugDidHit
            ? _debugEntry
            : _debugLastShotOrigin + _debugLastShotDirection * range;
        Gizmos.DrawLine(_debugLastShotOrigin, endPoint);

        if (_debugDidHit)
        {
            Gizmos.color = Color.yellow;
            Gizmos.DrawWireSphere(_debugEntry, 0.1f);

            if (_debugDidExit)
            {
                Gizmos.color = Color.magenta;
                Gizmos.DrawWireSphere(_debugExit, 0.1f);
                Gizmos.DrawLine(_debugEntry, _debugExit);
            }
        }
    }
}