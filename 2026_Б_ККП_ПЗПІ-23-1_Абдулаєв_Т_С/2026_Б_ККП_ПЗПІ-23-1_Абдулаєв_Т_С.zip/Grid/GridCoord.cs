using System;
using UnityEngine;

namespace CombatGrid
{
    [Serializable]
    public struct GridCoord : IEquatable<GridCoord>
    {
        public int X;
        public int Z;

        public GridCoord(int x, int z)
        {
            X = x;
            Z = z;
        }

        public static readonly GridCoord Zero = new(0, 0);
        public static readonly GridCoord North = new(0, 1);
        public static readonly GridCoord South = new(0, -1);
        public static readonly GridCoord East = new(1, 0);
        public static readonly GridCoord West = new(-1, 0);

        public static readonly GridCoord NorthEast = new(1, 1);
        public static readonly GridCoord NorthWest = new(-1, 1);
        public static readonly GridCoord SouthEast = new(1, -1);
        public static readonly GridCoord SouthWest = new(-1, -1);

        public static readonly GridCoord[] CardinalDirections =
        {
            North, South, East, West
        };

        public static readonly GridCoord[] DiagonalDirections =
        {
            NorthEast, NorthWest, SouthEast, SouthWest
        };

        public static readonly GridCoord[] AllDirections =
        {
            North, South, East, West,
            NorthEast, NorthWest, SouthEast, SouthWest
        };

        public static int ChebyshevDistance(GridCoord a, GridCoord b)
            => Mathf.Max(Mathf.Abs(a.X - b.X), Mathf.Abs(a.Z - b.Z));

        public static int ManhattanDistance(GridCoord a, GridCoord b)
            => Mathf.Abs(a.X - b.X) + Mathf.Abs(a.Z - b.Z);

        public static bool IsDiagonal(GridCoord from, GridCoord to)
        {
            int dx = Mathf.Abs(to.X - from.X);
            int dz = Mathf.Abs(to.Z - from.Z);
            return dx == 1 && dz == 1;
        }
        public static GridCoord operator +(GridCoord a, GridCoord b) => new(a.X + b.X, a.Z + b.Z);
        public static GridCoord operator -(GridCoord a, GridCoord b) => new(a.X - b.X, a.Z - b.Z);
        public static GridCoord operator *(GridCoord a, int scalar) => new(a.X * scalar, a.Z * scalar);
        public static bool operator ==(GridCoord a, GridCoord b) => a.X == b.X && a.Z == b.Z;
        public static bool operator !=(GridCoord a, GridCoord b) => !(a == b);

        public bool Equals(GridCoord other) => X == other.X && Z == other.Z;
        public override bool Equals(object obj) => obj is GridCoord c && Equals(c);
        public override int GetHashCode() => HashCode.Combine(X, Z);
        public override string ToString() => $"({X}, {Z})";

        public Vector2Int ToVector2Int() => new(X, Z);
        public static GridCoord FromVector2Int(Vector2Int v) => new(v.x, v.y);
    }
}