using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    [RequireComponent(typeof(CoverIconRenderer))]
    public class CoverObject : GridObstacle
    {
        [Header("Cover")]
        [SerializeField] private CoverType _coverType = CoverType.Half;
        [SerializeField] private List<CoverDirection> _exposedSides = new();

        [Header("Icon Settings")]
        [SerializeField] private CoverIconSettings _iconSettings;

        private readonly List<(GridCoord cell, GridCoord dir)> _registeredSlots = new();
        private CoverIconRenderer _iconRenderer;

        protected override void Start()
        {
            _iconRenderer = GetComponent<CoverIconRenderer>();
            base.Start();
            RegisterCoverSlots();
        }

        protected override void OnDestroy()
        {
            UnregisterCoverSlots();
            base.OnDestroy();
        }

        private void RegisterCoverSlots()
        {
            if (GridManager.Instance == null || _coverType == CoverType.None) return;

            _registeredSlots.Clear();
            var toCheck = GetExposedDirections();

            foreach (GridCoord obstacleCoord in OccupiedCoords)
            {
                foreach (GridCoord dir in toCheck)
                {
                    GridCoord adjacentCoord = obstacleCoord + dir;
                    GridCell adjacent = GridManager.Instance.GetCell(adjacentCoord);

                    if (adjacent == null || adjacent.IsBlocking) continue;

                    GridCoord dirToObstacle = new(-dir.X, -dir.Z);
                    GridManager.Instance.RegisterCoverSlot(adjacentCoord, dirToObstacle, _coverType);
                    _registeredSlots.Add((adjacentCoord, dirToObstacle));

                    if (_iconRenderer != null && _iconSettings != null)
                    {
                        Vector3 obstacleWorld = GridManager.Instance.CoordToWorld(obstacleCoord);
                        Vector3 adjacentWorld = GridManager.Instance.CoordToWorld(adjacentCoord);

                        Vector3 edgeCenter = (obstacleWorld + adjacentWorld) * 0.5f;
                        Vector3 facingDir = (adjacentWorld - obstacleWorld).normalized;

                        _iconRenderer.AddIcon(edgeCenter, facingDir, adjacentWorld, _coverType, _iconSettings);
                    }
                }
            }
        }

        private void UnregisterCoverSlots()
        {
            if (GridManager.Instance == null) return;

            foreach (var (cell, dir) in _registeredSlots)
                GridManager.Instance.UnregisterCoverSlot(cell, dir);

            _registeredSlots.Clear();
            _iconRenderer?.ClearIcons();
        }

        private List<GridCoord> GetExposedDirections()
        {
            if (_exposedSides == null || _exposedSides.Count == 0)
            {
                return new List<GridCoord> { GridCoord.North, GridCoord.South, GridCoord.East, GridCoord.West };
            }

            var dirs = new List<GridCoord>(_exposedSides.Count);
            foreach (var side in _exposedSides) dirs.Add(CoverDirectionToCoord(side));
            return dirs;
        }

        private static GridCoord CoverDirectionToCoord(CoverDirection d) => d switch
        {
            CoverDirection.North => GridCoord.North,
            CoverDirection.South => GridCoord.South,
            CoverDirection.East => GridCoord.East,
            CoverDirection.West => GridCoord.West,
            _ => GridCoord.North
        };

        public CoverType CoverType => _coverType;

        public void SetCoverType(CoverType newType)
        {
            if (_coverType == newType) return;
            _coverType = newType;
            UnregisterCoverSlots();
            RegisterCoverSlots();
        }

        public void RefreshCover()
        {
            UnregisterCoverSlots();
            RegisterCoverSlots();
        }

#if UNITY_EDITOR
        private void OnValidate()
        {
            if (Application.isPlaying && _iconRenderer != null)
            {
                UnityEditor.EditorApplication.delayCall += () =>
                {
                    if (this != null)
                    {
                        UnregisterCoverSlots();
                        RegisterCoverSlots();
                    }
                };
            }
        }
#endif
    }

    public enum CoverDirection { North, South, East, West }
}