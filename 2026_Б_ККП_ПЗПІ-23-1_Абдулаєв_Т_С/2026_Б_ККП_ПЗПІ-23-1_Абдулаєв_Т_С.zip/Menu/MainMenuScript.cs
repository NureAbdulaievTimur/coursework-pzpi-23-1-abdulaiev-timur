using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenuScript : MonoBehaviour
{
    public void PlayGame()
    {
        SceneTransitionManager.Instance.LoadScene("GameScene");
    }

    public void QuitGame()
    {
        SceneTransitionManager.Instance.QuitGameWithTransition();
    }
}