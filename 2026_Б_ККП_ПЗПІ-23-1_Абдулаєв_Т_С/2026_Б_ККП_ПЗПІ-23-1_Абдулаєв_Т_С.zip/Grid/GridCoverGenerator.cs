using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CombatGrid
{
    public class GridCoverGenerator : MonoBehaviour
    {
        [Header("Prefabs")]
        [Tooltip("Prefab with the CoverObject script set to Half Cover.")]
        [SerializeField] private GameObject _halfCoverPrefab;
        [Tooltip("Prefab with the CoverObject script set to Full Cover.")]
        [SerializeField] private GameObject _fullCoverPrefab;
        [Tooltip("Parent transform to hold spawned walls (optional).")]
        [SerializeField] private Transform _environmentParent;

        [Header("Generation Settings")]
        [Tooltip("Approximate percentage of the grid that should be covered by walls (0.0 to 1.0).")]
        [Range(0.05f, 0.5f)]
        [SerializeField] private float _targetDensity = 0.15f;

        [Tooltip("Chance that a placed cover block will be FULL cover instead of HALF cover.")]
        [Range(0f, 1f)]
        [SerializeField] private float _fullCoverRatio = 0.4f;

        [Tooltip("Minimum length of a wall segment (in cells).")]
        [SerializeField, Min(1)] private int _minWallLength = 1;

        [Tooltip("Maximum length of a wall segment (in cells).")]
        [SerializeField, Min(1)] private int _maxWallLength = 4;

        [Tooltip("Guaranteed empty cells around EVERY wall. 1 guarantees units can always walk between walls.")]
        [SerializeField, Min(1)] private int _gapPadding = 1;

        [Header("Exclusion Zones")]
        [Tooltip("Grid coordinates where walls should NEVER spawn (e.g., Unit deployment zones).")]
        [SerializeField] private RectInt[] _safeZones;

        private bool[,] _occupiedMap;
        private List<GameObject> _spawnedWalls = new();

        private void Start()
        {
            if (GridManager.Instance != null && GridManager.Instance.IsInitialized)
            {
                StartCoroutine(GenerateCoverRoutine());
            }
            else if (GridManager.Instance != null)
            {
                GridManager.Instance.OnGridInitialized += () => StartCoroutine(GenerateCoverRoutine());
            }
        }

        [ContextMenu("Regenerate Cover")]
        public void TriggerRegeneration()
        {
            if (Application.isPlaying)
            {
                StartCoroutine(GenerateCoverRoutine());
            }
        }

        private IEnumerator GenerateCoverRoutine()
        {
            ClearExistingCover();

            GridSettings settings = GridManager.Instance.Settings;
            _occupiedMap = new bool[settings.Width, settings.Height];

            int totalCells = settings.Width * settings.Height;
            int targetWallCells = Mathf.RoundToInt(totalCells * _targetDensity);
            int currentWallCells = 0;

            int maxAttempts = 2000;
            int attempts = 0;

            while (currentWallCells < targetWallCells && attempts < maxAttempts)
            {
                attempts++;

                GridCoord start = new GridCoord(
                    Random.Range(0, settings.Width),
                    Random.Range(0, settings.Height)
                );

                int length = Random.Range(_minWallLength, _maxWallLength + 1);
                bool isHorizontal = Random.value > 0.5f;

                if (CanPlaceWall(start, isHorizontal, length))
                {
                    PlaceWallSegment(start, isHorizontal, length);
                    currentWallCells += length;
                }
            }

            yield return null;

            foreach (var wall in _spawnedWalls)
            {
                if (wall.TryGetComponent<CoverObject>(out var coverObj))
                {
                    coverObj.RefreshCover();
                }
            }

            Debug.Log($"[CoverGenerator] Map generated with {currentWallCells} cover blocks.");
        }

        private bool CanPlaceWall(GridCoord start, bool isHorizontal, int length)
        {
            GridSettings settings = GridManager.Instance.Settings;

            int endX = start.X + (isHorizontal ? length - 1 : 0);
            int endZ = start.Z + (isHorizontal ? 0 : length - 1);

            if (endX >= settings.Width || endZ >= settings.Height) return false;

            int minX = start.X - _gapPadding;
            int maxX = endX + _gapPadding;
            int minZ = start.Z - _gapPadding;
            int maxZ = endZ + _gapPadding;

            for (int x = minX; x <= maxX; x++)
            {
                for (int z = minZ; z <= maxZ; z++)
                {
                    if (x >= 0 && x < settings.Width && z >= 0 && z < settings.Height)
                    {
                        if (_occupiedMap[x, z]) return false;

                        if (_safeZones != null)
                        {
                            foreach (var safeZone in _safeZones)
                            {
                                if (safeZone.Contains(new Vector2Int(x, z))) return false;
                            }
                        }
                    }
                }
            }
            return true;
        }

        private void PlaceWallSegment(GridCoord start, bool isHorizontal, int length)
        {
            GridSettings settings = GridManager.Instance.Settings;

            for (int i = 0; i < length; i++)
            {
                GridCoord cell = new GridCoord(
                    start.X + (isHorizontal ? i : 0),
                    start.Z + (isHorizontal ? 0 : i)
                );

                _occupiedMap[cell.X, cell.Z] = true;

                bool isFullCover = Random.value <= _fullCoverRatio;
                GameObject prefabToUse = isFullCover ? _fullCoverPrefab : _halfCoverPrefab;

                Vector3 worldPos = settings.CoordToWorld(cell);

                worldPos.y += prefabToUse.transform.position.y;

                GameObject wallInstance = Instantiate(prefabToUse, worldPos, Quaternion.identity, _environmentParent);

                _spawnedWalls.Add(wallInstance);
            }
        }

        private void ClearExistingCover()
        {
            foreach (var wall in _spawnedWalls)
            {
                if (wall != null) Destroy(wall);
            }
            _spawnedWalls.Clear();
        }
    }
}